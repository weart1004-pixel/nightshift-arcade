import { integer, sqliteTable, text, index } from "drizzle-orm/sqlite-core";

export const duelRooms = sqliteTable("duel_rooms", {
  code: text("code").primaryKey(),
  host: text("host").notNull(),
  guest: text("guest"),
  open: integer("open").notNull().default(1),
  hostSeen: integer("host_seen").notNull(),
  guestSeen: integer("guest_seen").notNull().default(0),
  inbox: text("inbox").notNull().default("[]"),
  ack: integer("ack").notNull().default(0),
  packet: text("packet").notNull().default(""),
}, table => [index("duel_last_host").on(table.hostSeen)]);

export const commsMessages = sqliteTable("comms_messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  requestId: text("request_id").notNull().unique(),
  channel: text("channel").notNull(),
  nickname: text("nickname").notNull(),
  message: text("message").notNull(),
  created: integer("created").notNull(),
}, table => [index("comms_channel_id").on(table.channel, table.id)]);

export const voiceCalls = sqliteTable("voice_calls", {
  code: text("code").primaryKey(),
  host: text("host").notNull(),
  guest: text("guest"),
  offer: text("offer").notNull(),
  answer: text("answer"),
  hostSeen: integer("host_seen").notNull(),
  guestSeen: integer("guest_seen").notNull().default(0),
});

export const friendProfiles = sqliteTable("friend_profiles", {
  code: text("code").primaryKey(),
  credential: text("credential").notNull().unique(),
  nickname: text("nickname").notNull(),
});
export const friendLinks = sqliteTable("friend_links", {
  pair: text("pair").primaryKey(),
  sender: text("sender").notNull(),
  recipient: text("recipient").notNull(),
  accepted: integer("accepted").notNull().default(0),
}, table => [index("friend_sender").on(table.sender), index("friend_recipient").on(table.recipient)]);
