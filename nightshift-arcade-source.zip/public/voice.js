(() => {
  const el=name=>document.getElementById('voice-'+name);
  let current=null;
  const status=text=>{el('status').textContent=text;};
  function showPanel(open){
    el('panel').hidden=!open;
    el('open').setAttribute('aria-expanded',String(open));
  }
  el('open').onclick=()=>showPanel(el('panel').hidden);
  async function request(call,action,extra={}){
    const res=await fetch('/api/voice',{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({action,code:call.code,token:call.token,...extra}),keepalive:action==='end'});
    const data=await res.json();
    if(!res.ok)throw Object.assign(new Error(data.error||'Call unavailable.'),{terminal:[400,403,409,410].includes(res.status)});
    return data;
  }
  function finish(call,message){
    if(current!==call)return;
    current=null;clearTimeout(call.timer);clearTimeout(call.deadline);
    if(call.pc){call.pc.onconnectionstatechange=null;call.pc.close();}
    call.stream?.getTracks().forEach(t=>t.stop());
    el('audio').srcObject=null;el('idle').hidden=false;el('active').hidden=true;
    el('open').textContent='Voice call';status(message);
    if(call.registered)request(call,'end').catch(()=>{});
  }
  async function description(call,type){
    const pc=call.pc;
    await pc.setLocalDescription(type==='offer'?await pc.createOffer():await pc.createAnswer());
    if(pc.iceGatheringState!=='complete')await new Promise(resolve=>{
      function done(){clearTimeout(timer);pc.removeEventListener('icegatheringstatechange',changed);resolve();}
      function changed(){if(pc.iceGatheringState==='complete'||pc.signalingState==='closed')done();}
      const timer=setTimeout(done,8500);pc.addEventListener('icegatheringstatechange',changed);changed();
    });
    if(call!==current)throw Error('Call ended.');
    return pc.localDescription.sdp;
  }
  function connectionDeadline(call){
    clearTimeout(call.deadline);
    call.deadline=setTimeout(()=>finish(call,'Audio could not connect. Try another network or start a new call.'),45000);
  }
  async function poll(call){
    if(call!==current)return;
    try{
      const result=await request(call,'poll');
      if(call!==current)return;
      if(call.host&&result.joined&&!call.joined){call.joined=true;status('Friend joined. Connecting audio…');connectionDeadline(call);}
      if(call.host&&result.answer&&!call.pc.remoteDescription)await call.pc.setRemoteDescription({type:'answer',sdp:result.answer});
      call.lastOK=Date.now();
    }catch(e){
      if(call!==current)return;
      if(e.terminal||Date.now()-call.lastOK>75000){finish(call,e.terminal?e.message:'Call service disconnected.');return;}
    }
    if(call===current)call.timer=setTimeout(()=>poll(call),call.pc.connectionState==='connected'?5000:1300);
  }
  async function begin(host){
    if(current)return;
    const code=host?crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase():el('code').value.trim().toUpperCase();
    if(!/^[0-9A-F]{12}$/.test(code)){status('Enter the 12-character code your friend shared.');el('code').focus();return;}
    if(!navigator.mediaDevices?.getUserMedia||!window.RTCPeerConnection){status('Open this page in a browser that supports microphone calls.');return;}
    const call={code,host,token:crypto.randomUUID(),lastOK:Date.now()};current=call;
    el('idle').hidden=true;el('active').hidden=false;el('copy').hidden=true;el('listen').hidden=true;
    el('mute').disabled=true;el('mute').textContent='Mute mic';el('mute').setAttribute('aria-pressed','false');
    el('invite').textContent='';status('Allow microphone access to join voice.');el('open').textContent='Call controls';
    try{
      const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
      if(call!==current){stream.getTracks().forEach(t=>t.stop());return;}
      call.stream=stream;el('mute').disabled=false;
      const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});call.pc=pc;
      stream.getAudioTracks().forEach(track=>pc.addTrack(track,stream));
      pc.ontrack=e=>{if(call!==current)return;el('audio').srcObject=e.streams[0]||new MediaStream([e.track]);el('audio').play().catch(()=>{if(call===current)el('listen').hidden=false;});};
      pc.onconnectionstatechange=()=>{
        if(current!==call)return;
        if(pc.connectionState==='connected'){clearTimeout(call.deadline);status('Voice connected');}
        if(pc.connectionState==='disconnected'){status('Reconnecting audio…');connectionDeadline(call);}
        if(pc.connectionState==='failed')finish(call,'Audio connection failed. Try another network.');
      };
      status(host?'Starting call…':'Joining call…');
      if(host){
        const sdp=await description(call,'offer');
        await request(call,'create',{sdp});
      }else{
        const data=await request(call,'join');call.registered=true;
        if(call!==current){request(call,'end').catch(()=>{});return;}
        await pc.setRemoteDescription({type:'offer',sdp:data.offer});
        const sdp=await description(call,'answer');await request(call,'answer',{sdp});
      }
      call.registered=true;
      if(call!==current){request(call,'end').catch(()=>{});return;}
      if(host){el('invite').textContent='Code '+code;el('copy').hidden=false;status('Share this code with one friend. Waiting for them to join…');}
      else if(pc.connectionState!=='connected'){status('Connecting audio…');connectionDeadline(call);}
      poll(call);
    }catch(e){finish(call,e.name==='NotAllowedError'?'Microphone permission was declined. Enable it in your browser to call.':e.name==='NotFoundError'?'No microphone found. Connect one and try again.':e.message||'Could not start the call.');}
  }
  el('start').onclick=()=>begin(true);el('join').onclick=()=>begin(false);
  el('end').onclick=()=>{if(current)finish(current,'Call ended.');};
  el('copy').onclick=async()=>{if(!current)return;const call=current;try{await navigator.clipboard.writeText(call.code);if(current===call)status('Call code copied.');}catch{status('Share the code shown above.');}};
  el('listen').onclick=()=>el('audio').play().then(()=>el('listen').hidden=true).catch(()=>status('Audio playback is blocked by this browser.'));
  el('mute').onclick=()=>{const tracks=current?.stream?.getAudioTracks();if(!tracks?.length)return;const muted=tracks[0].enabled;tracks.forEach(t=>t.enabled=!muted);el('mute').textContent=muted?'Unmute mic':'Mute mic';el('mute').setAttribute('aria-pressed',String(muted));};
  window.addEventListener('pagehide',()=>{if(current)finish(current,'Call ended.');});
})();
