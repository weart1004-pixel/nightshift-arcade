import { horror } from './horror.js';
import { rhythm } from './rhythm.js';
import { physics } from './physics.js';
import { action } from './action.js';
import { tycoon } from './tycoon.js';
import { puzzle } from './puzzle.js';
import { retro } from './retro.js';
import { sports } from './sports.js';

export const modes = { ...horror, ...rhythm, ...physics, ...action, ...tycoon, ...puzzle, ...retro, ...sports };
