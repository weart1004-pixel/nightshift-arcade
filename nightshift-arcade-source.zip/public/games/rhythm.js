import { W, H, TAU, clamp, mix, distance, inRect } from './engine.js';
import { mode, directions, horizontal } from './controls.js';

const pink = '#fb6ceb';
const aqua = '#77ffe8';

function runner(g, flipping) {
  const floor = 457, ceiling = 100, px = 151, r = 18;
  const count = 17 + g.level * 3;
  const speed = (flipping ? 300 : 326) + g.level * 18;
  const tint = flipping ? '#7de8ff' : '#eda2ff';
  const barriers = [];
  let cursor = 570;
  for (let i = 0; i < count; i++) {
    const kind = flipping ? (g.random() > .5 ? 'top' : 'bottom') : (i && i % 5 === 3 ? 'gap' : 'spikes');
    barriers.push({ x: cursor, w: kind === 'gap' ? g.rand(68, 112) : g.rand(28, 59) + (g.level >= 3 ? 9 : 0), kind, height: 30 + g.random() * 21 });
    cursor += g.rand(flipping ? 242 : 235, flipping ? 335 : 320) + g.level * 7;
  }
  let x = 0, y = floor - r, vy = 0, gravity = 1, rotation = 0, grounded = true, flash = 0;
  const trail = [];
  let trailClock = 0;
  return dt => {
    if (g.action() || g.pressed('up') || g.pointer.tap) {
      if (flipping) {
        gravity *= -1;
        grounded = false;
        if (vy * gravity < 0) vy *= .28;
        flash = .25;
        g.beep(gravity > 0 ? 340 : 520, .12, 'triangle', .04);
      } else if (grounded) {
        vy = -605;
        grounded = false;
        g.beep(350, .09, 'square', .029);
      }
    }
    x += dt * speed;
    const p = x + px;
    const gap = !flipping && barriers.some(b => b.kind === 'gap' && p > b.x + 4 && p < b.x + b.w - 4);
    vy += dt * (flipping ? 2350 : 1720) * gravity;
    y += vy * dt;
    if (!gap && y > floor - r && y < floor + r * .38 && vy > 0) { y = floor - r; vy = 0; grounded = true; }
    if (flipping && y < ceiling + r) { y = ceiling + r; vy = 0; grounded = true; }
    if (gap) grounded = false;
    if (!grounded) rotation += dt * 5.2 * gravity;
    else rotation = Math.round(rotation / (Math.PI / 2)) * (Math.PI / 2);
    g.score = x / 7;

    const collides = barriers.some(b => b.kind !== 'gap' &&
      p + r * .67 > b.x && p - r * .67 < b.x + b.w &&
      (b.kind === 'top' ? y - r * .72 < ceiling + b.height + 11 : y + r * .72 > floor - b.height));
    g.image(flipping ? '#101a31' : '#1b1040', '#09071b');
    g.starlight(8);
    g.grid(47, '#be93f518', -x * .32);
    for (let i = 0; i < 12; i++) {
      const bx = ((i * 103 - x * .2) % 1236 + 1236) % 1236 - 80;
      const bh = 65 + i * 67 % 173;
      g.box(bx, floor - bh, 63, bh, '#25154466', 3);
      for (let j = 1; j < bh / 22; j++) g.box(bx + 11 + (j % 2) * 18, floor - j * 22, 24, 2, '#c996ff24');
    }
    g.box(0, floor, W, H - floor, '#241641');
    g.glow(tint, 11, () => g.line(0, floor, W, floor, tint, 3));
    if (flipping) {
      g.box(0, 0, W, ceiling, '#102942');
      g.line(0, ceiling, W, ceiling, tint, 3);
    }
    for (const b of barriers) {
      const bx = b.x - x;
      if (bx > W + 50 || bx + b.w < 0) continue;
      if (b.kind === 'gap') {
        g.box(bx, floor - 2, b.w, H - floor + 2, '#0b0921');
        g.line(bx, floor + 2, bx, H, '#955bd4', 2);
        g.line(bx + b.w, floor + 2, bx + b.w, H, '#955bd4', 2);
      } else if (flipping) {
        const by = b.kind === 'top' ? ceiling : floor - b.height;
        g.glow('#ff577e', 14, () => g.box(bx, by, b.w, b.height, '#6d2154', 4, '#ff7eb3'));
        g.line(bx + 7, by + b.height / 2, bx + b.w - 7, by + b.height / 2, '#ffbbd7', 2);
      } else {
        g.glow(pink, 11, () => g.poly([[bx, floor], [bx + b.w / 2, floor - b.height], [bx + b.w, floor]], '#892975', '#ffa2ff', 2.2));
      }
    }
    if (cursor - x < W) {
      g.box(cursor - x, 102, 8, 355, '#8affd6');
      g.label('FINISH', cursor - x - 12, 129, '#8affd6', 19, 'right');
    }
    trailClock += dt;
    if (trailClock > .022) { trail.push({ x: px, y, life: .35 }); trailClock = 0; }
    for (const dot of trail) { dot.life -= dt; dot.x -= speed * dt; if (dot.life > 0) g.dot(dot.x, dot.y, 12 * dot.life / .35, '#ac6aff64'); }
    while (trail[0]?.life <= 0) trail.shift();
    g.ctx.save();
    g.ctx.translate(px, y);
    g.ctx.rotate(rotation);
    g.glow(tint, 21, () => g.box(-r, -r, r * 2, r * 2, '#743cd3', 4, '#e9d2ff'));
    g.box(-10, -10, 20, 20, '#ad7bfa', 2);
    g.box(-6, -4, 3, 5, '#fff1ff', 1);
    g.box(3, -4, 3, 5, '#fff1ff', 1);
    g.ctx.restore();
    g.label(flipping ? (gravity > 0 ? 'GRAVITY DOWN' : 'GRAVITY UP') : 'PULSE RUN', 24, 29, '#eee3fc', 17);
    g.meter(W - 220, 33, 193, p / cursor, tint, `${Math.min(100, Math.floor(p / cursor * 100))}% complete`);
    flash = Math.max(0, flash - dt);
    if (flash) g.box(0, 0, W, H, `rgba(126,231,255,${flash * .16})`);
    if (dt && (collides || y > H + r)) g.end('Run interrupted', `You reached ${Math.floor(p / cursor * 100)}% of the course.`);
    else if (dt && p >= cursor) { g.score += 300; g.end('Track cleared', 'You made it to the finish line.', true); }
  };
}

function tunnel(g) {
  const lanes = 8, cx = W / 2, cy = H / 2 + 7, playerRadius = 201;
  const palette = ['#68e6ff', '#f086ff', '#b48dff'];
  let angle = 0, slot = 0, lives = 3, cleared = 0, flash = 0;
  const delay = 1.26 - g.level * .059;
  const total = 22 + g.level * 4;
  const direction = g.random() > .5 ? 1 : -1;
  const rings = Array.from({ length: total }, (_, i) => ({
    time: 2.7 + i * delay, gap: (Math.floor(i / 2) * direction + 800 + (g.level > 2 ? Math.floor(g.random() * 3) : 0)) % lanes,
    used: false, tint: palette[i % palette.length],
  }));
  const coord = (a, r) => [cx + Math.cos(a) * r, cy + Math.sin(a) * r];

  return dt => {
    if (g.pressed('left') || (g.pointer.tap && g.pointer.x < W / 2)) slot = (slot + lanes - 1) % lanes;
    if (g.pressed('right') || (g.pointer.tap && g.pointer.x >= W / 2)) slot = (slot + 1) % lanes;
    const rotation = slot * TAU / lanes - angle;
    angle += Math.atan2(Math.sin(rotation), Math.cos(rotation)) * Math.min(1, dt * 15);
    g.image('#0b0a20', '#111332');
    g.starlight(9);
    for (let i = 0; i < 8; i++) {
      const a = (i + .5) * TAU / lanes;
      const [x, y] = coord(a, 690);
      g.line(cx, cy, x, y, '#825cce7d', 2);
    }
    for (const ring of rings) {
      const delta = ring.time - g.time;
      if (delta < -.44 || delta > 2.8) continue;
      const r = playerRadius * Math.exp(-delta * 1.55);
      const width = Math.max(4, r * .075);
      for (let i = 0; i < lanes; i++) {
        const safe = i === ring.gap || i === (ring.gap + 1) % lanes;
        const a = (i - .5) * TAU / lanes, b = (i + .5) * TAU / lanes;
        if (safe) {
          g.line(...coord(a, r), ...coord(b, r), '#59ffa748', 2);
        } else {
          g.poly([coord(a, r - width), coord(b, r - width), coord(b, r + width), coord(a, r + width)], ring.tint + '6d', ring.tint, 2);
        }
      }
      if (!ring.used && delta <= 0) {
        ring.used = true;
        if (slot === ring.gap || slot === (ring.gap + 1) % lanes) { cleared++; g.beep(420 + cleared % 6 * 75, .09, 'triangle'); }
        else { lives--; flash = .32; g.beep(110, .23, 'sawtooth', .04); }
      }
    }
    g.dot(cx, cy, playerRadius, null, '#ccb6ff45', 2);
    const [px, py] = coord(angle, playerRadius);
    g.glow(aqua, 23, () => g.dot(px, py, 13, '#8ff9ff', '#f8ffff', 3));
    flash = Math.max(0, flash - dt);
    if (flash) g.box(0, 0, W, H, `rgba(255,85,132,${flash * .62})`);
    g.score = cleared * 120;
    g.label(`Gates ${cleared}/${total}`, 24, 29);
    g.label(`Shields ${lives}`, W - 24, 29, '#d8c8fb', 20, 'right');
    if (lives <= 0) g.end('Shields down', `You cleared ${cleared} gates.`);
    else if (g.time > rings.at(-1).time + .25) g.end('Tunnel cleared', `You cleared ${cleared} gates with ${lives} shields left.`, true);
  };
}

function beatblade(g) {
  const keys = ['f', 'g', 'j', 'k'];
  const colors = ['#a97aff', '#60d5ff', '#78f0c1', '#ff76b8'];
  const noteCount = 33 + g.level * 7;
  const interval = .58 - g.level * .036;
  const timing = .184 - g.level * .008;
  const ox = 165, width = 158, yHit = 428;
  const chart = Array.from({ length: noteCount }, (_, i) => ({
    lane: Math.floor(g.rand(0, 4)), time: 2 + i * interval, used: false, sound: false,
  }));
  const lit = [0, 0, 0, 0];
  let combo = 0, perfect = 0, last = '', lastAt = 0, hit = 0, misses = 0;
  return dt => {
    let laneClick = g.pointer.tap ? Math.floor((g.pointer.x - ox) / width) : -1;
    if (g.pointer.y > H - 8 || g.pointer.y < 54) laneClick = -1;
    for (let i = 0; i < 4; i++) {
      if (!g.pressed(keys[i]) && laneClick !== i) continue;
      lit[i] = g.time + .16;
      const note = chart.find(n => n.lane === i && !n.used && Math.abs(n.time - g.time) < timing);
      if (!note) {
        combo = 0; last = 'Too early or late'; lastAt = g.time; continue;
      }
      note.used = true;
      const exact = Math.abs(note.time - g.time) < timing * .43;
      if (exact) perfect++;
      hit++;
      combo++;
      g.score += (exact ? 120 : 70) + combo * 4;
      last = exact ? 'PERFECT' : 'GOOD';
      lastAt = g.time;
      g.beep([392, 493.88, 587.33, 659.25][i], .14, 'triangle');
    }
    g.image('#141237', '#210d32');
    g.grid(44, '#b395ff15', 0, g.time * 40);
    for (let i = 0; i < 4; i++) {
      const x = ox + i * width;
      g.box(x + 2, 58, width - 4, 442, lit[i] > g.time ? colors[i] + '45' : '#18142d', 6, colors[i] + '52');
      g.box(x + 12, yHit - 12, width - 24, 24, colors[i] + '39', 6, colors[i]);
      g.label(keys[i].toUpperCase(), x + width / 2, 473, colors[i], 31, 'center');
    }
    for (const note of chart) {
      if (!note.sound && g.time >= note.time) { note.sound = true; g.beep(76, .072, 'sine', .032); }
      if (note.used) continue;
      if (g.time - note.time > timing) {
        note.used = true;
        misses++; combo = 0; last = 'MISS'; lastAt = g.time;
        continue;
      }
      const y = yHit - (note.time - g.time) * (264 + g.level * 19);
      if (y < 69) continue;
      const x = ox + note.lane * width + width / 2;
      const color = colors[note.lane];
      g.glow(color, 13, () => g.poly([[x - 36, y], [x, y - 15], [x + 36, y], [x, y + 15]], color, '#fff0ff'));
    }
    g.label(`Combo ×${combo}`, 24, 29);
    g.label(`Hits ${hit}/${noteCount}`, W - 24, 29, '#e4cfff', 20, 'right');
    if (g.time - lastAt < .52 && last) g.label(last, W / 2, 27, last === 'MISS' ? '#ff789a' : '#ffe094', 20, 'center');
    if (dt && hit + misses === noteCount) g.end('Track complete', `${hit} hits, including ${perfect} perfect notes.`, hit >= noteCount * .55);
  };
}

function laserEscape(g) {
  const bars = Array.from({ length: 5 + g.level }, (_, i) => ({
    x: 200 + i * (616 / (4 + g.level)), phase: -.6 + g.random() * 3.4,
    color: i % 2 ? '#fc649f' : '#fa4b78',
  }));
  const player = { x: 75, y: 296 };
  const goal = { x: 899, y: 270 };
  let life = 4, frozen = 0, timer = 42 - g.level, reached = 0;
  return dt => {
    const m = g.move();
    player.x = clamp(player.x + m.x * dt * 185, 41, W - 39);
    player.y = clamp(player.y + m.y * dt * 185, 102, H - 75);
    timer -= dt;
    frozen = Math.max(0, frozen - dt);
    g.image('#160f23', '#241329');
    g.box(34, 86, W - 68, H - 146, '#151426', 10, '#664055');
    g.grid(31, '#e686b516');
    for (const b of bars) {
      const status = (g.time + b.phase + 4.4) % (4.4 - g.level * .10);
      const on = status >= 1.42 - g.level * .064;
      const warning = !on && status > 1.09 - g.level * .064;
      g.box(b.x - 10, 85, 20, 25, '#47243e', 4, '#98566c');
      g.box(b.x - 10, H - 84, 20, 25, '#47243e', 4, '#98566c');
      if (on) g.glow(b.color, 18, () => g.line(b.x, 111, b.x, H - 85, b.color, 5));
      else g.line(b.x, 111, b.x, H - 85, warning ? '#f8b46e' : '#99d6b152', warning ? 3 : 1);
      if (on && !frozen && Math.abs(player.x - b.x) < 14) {
        frozen = 1;
        player.x = b.x - 25;
        life--;
        g.beep(128, .14, 'square', .04);
      }
      if (player.x > b.x + 21 && !b.passed) { b.passed = true; reached++; g.beep(500); }
    }
    g.box(goal.x - 18, 120, 36, 311, '#2796813b', 7, '#6dfdd3');
    g.label('EXIT', goal.x, 272, '#81ffcf', 13, 'center');
    g.glow(aqua, 15, () => g.dot(player.x, player.y, 11, frozen && Math.floor(g.time * 12) % 2 ? '#dd8ea7' : '#69f6e3', '#ebffff'));
    g.score = reached * 100;
    g.label(`Lives ${life}   •   Time ${Math.max(0, Math.ceil(timer))}s`, 24, 29);
    if (dt && (life <= 0 || timer <= 0)) g.end('Vault locked', `You crossed ${reached} laser grids.`);
    else if (dt && player.x >= goal.x - 13) { g.score += Math.ceil(timer) * 13; g.end('Security cleared', 'You reached the exit.', true); }
  };
}

function drift(g) {
  const horizon = 140, bottom = H + 18;
  const phase = g.rand(0, TAU);
  const route = z => Math.sin(z * .0032 + phase) * .58 + Math.sin(z * .0051 + phase * .6) * .24;
  const colors = ['#431151', '#531a69', '#4d245a', '#55214e', '#412863', '#32354f'];
  const city = Array.from({ length: 35 }, (_, i) => ({ x: i * 35 + g.rand(-8, 7), w: g.rand(21, 50), height: g.rand(38, 113), h: i % colors.length }));
  const course = 7400 + g.level * 1000;
  const traffic = Array.from({ length: 10 + g.level * 3 }, (_, i) => ({
    distance: 1130 + i * ((course - 1420) / (10 + g.level * 3)), lane: g.pick([-.63, .06, .62]), passed: false, color: g.pick(['#f7a15f', '#72ebe1', '#7984fa']),
  }));
  let z = 0, lane = 0, velocity = 0, speed = 240, health = 3, scrape = 0, combo = 0, bestCombo = 0, total = 0;
  const sparks = [];
  const trackAt = (t, ahead) => ({
    x: W / 2 + (route(z + ahead) - route(z)) * (155 + t * 56),
    y: mix(horizon, bottom, t),
    width: mix(29, 357, t),
  });

  return dt => {
    const steering = Number(g.key('right')) - Number(g.key('left'));
    const drifting = g.key('space') || g.key('shift');
    const bend = (route(z + 115) - route(z)) * 2.28;
    const maxSpeed = 335 + g.level * 19;
    const carY = 456;
    const carT = (carY - horizon) / (bottom - horizon);
    const carDepth = (1 - carT) ** 2 * 1240;
    const carBase = trackAt(carT, carDepth);
    speed += ((drifting ? maxSpeed * .85 : maxSpeed) - speed) * dt * 1.18;
    velocity += (steering * (drifting ? 1.25 : 1.63) - bend * (drifting ? .48 : .95) - velocity) * Math.min(dt * (drifting ? 2.8 : 6), 1);
    lane += velocity * dt;
    z += speed * dt;
    scrape = Math.max(0, scrape - dt);
    const slide = drifting && (Math.abs(velocity) > .18 || Math.abs(steering) > 0) && Math.abs(lane) < .93;
    if (slide) {
      combo += dt * (1 + Math.abs(bend));
      bestCombo = Math.max(combo, bestCombo);
      total += dt * (48 + 29 * combo);
    } else combo = Math.max(0, combo - dt * 2.7);
    if (Math.abs(lane) > .97) {
      lane = clamp(lane, -.97, .97);
      velocity *= -.48; speed *= .66;
      if (!scrape) { health--; scrape = 1.25; g.beep(116, .22, 'sawtooth'); }
    }
    for (const car of traffic) if (!car.passed && car.distance < z + carDepth) {
      car.passed = true;
      if (Math.abs(lane - car.lane) < .24 && !scrape) {
        health--; scrape = 1.25; speed *= .62; g.beep(126, .22, 'triangle');
      } else total += 25;
    }
    g.score = total + z * .073;
    g.image('#170e34', '#160b22');
    g.starlight(5, '#e5b7ff');
    g.glow('#e26bff', 62, () => g.dot(641, 108, 32, '#c345a4'));
    for (const b of city) {
      const x = ((b.x + bend * 44) % 1190 + 1190) % 1190 - 90;
      g.box(x, horizon - b.height, b.w, b.height + 4, colors[b.h], 2);
      for (let y = horizon - b.height + 11; y < horizon - 7; y += 14) {
        g.box(x + 5, y, b.w * .34, 2, '#fd84cf57');
        g.box(x + b.w - 11, y, 5, 2, '#8ff7ed61');
      }
    }
    for (let i = 0; i < 46; i++) {
      const t = i / 46, u = (i + 1) / 46;
      const a = (1 - t) ** 2 * 1240, b = (1 - u) ** 2 * 1240;
      const p = trackAt(t, a), n = trackAt(u, b);
      const stripe = Math.floor((z + b) / 49) % 2;
      const points = (f, k) => [[p.x + f * p.width, p.y], [p.x + k * p.width, p.y], [n.x + k * n.width, n.y], [n.x + f * n.width, n.y]];
      g.poly([[0, p.y], [W, p.y], [W, n.y + 1], [0, n.y + 1]], stripe ? '#231235' : '#29143f');
      g.poly(points(-1.03, 1.03), stripe ? '#201b35' : '#25203d');
      g.poly(points(-1.05, -.969), stripe ? '#fa51ab' : '#7a42b3');
      g.poly(points(.969, 1.05), stripe ? '#fa51ab' : '#7a42b3');
      if (stripe) for (const pos of [-.33, .33]) g.poly(points(pos - .012, pos + .012), '#d5acfe8a');
      if (i % 4 === 0) g.poly(points(-.82, -.56), '#ad4cba0d');
    }
    for (const car of traffic) {
      const depth = car.distance - z;
      if (depth < 0 || depth > 1200) continue;
      const t = 1 - Math.sqrt(depth / 1240);
      const p = trackAt(t, depth);
      const w = 14 + t * 42, h = w * .62;
      const x = p.x + p.width * car.lane;
      g.box(x - w / 2, p.y - h, w, h, car.color, 3, '#e5b5ee');
      g.line(x - w * .38, p.y - 3, x + w * .38, p.y - 3, '#ff255f', 3);
    }
    const cx = carBase.x + lane * carBase.width;
    if (slide && dt) for (let i = 0; i < 2; i++) sparks.push({
      x: cx + (i - .5) * 61, y: carY + 16, vx: -velocity * 63 + g.rand(-30, 30), life: g.rand(.26, .63),
    });
    for (let i = sparks.length - 1; i >= 0; i--) {
      const p = sparks[i];
      p.life -= dt; p.x += p.vx * dt; p.y += dt * 80;
      if (p.life <= 0) sparks.splice(i, 1);
      else g.dot(p.x, p.y, 23 * p.life, '#de7dff3b');
    }
    if (!(scrape && Math.floor(g.time * 12) % 2)) {
      g.ctx.save();
      g.ctx.translate(cx, carY);
      g.ctx.rotate(velocity * (drifting ? -.28 : .11));
      g.box(-43, -18, 86, 38, '#0d0a14', 7, '#a46bae');
      g.box(-35, -31, 70, 35, '#582759', 7, '#f2a2dc');
      g.poly([[-30, -15], [-23, -28], [23, -28], [30, -15]], '#22182f', '#9d71be');
      g.box(-44, 3, 88, 12, '#292338', 4);
      g.glow('#ff3dac', 15, () => {
        g.box(-35, 5, 25, 5, '#ff5dba', 2);
        g.box(10, 5, 25, 5, '#ff5dba', 2);
      });
      g.ctx.restore();
    }
    g.box(17, 14, 220, 58, '#130a23de', 9, '#845299');
    g.label(`${Math.round(speed * .61)} km/h`, 33, 35, '#ffdaf9', 26);
    g.label(`Car condition  ${'◆'.repeat(Math.max(0, health))}`, 33, 58, '#fca7e0', 14);
    g.meter(716, 46, 210, z / course, '#e566e5', `Route ${Math.min(100, Math.floor(z / course * 100))}%`);
    if (slide) g.label(`DRIFT ×${(1 + combo).toFixed(1)}`, W / 2, 85, '#ffbef7', 28, 'center', 900);
    if (dt && health <= 0) g.end('Run over', `You completed ${Math.floor(z / course * 100)}% of the route.`);
    else if (dt && z >= course) { g.score += 500; g.end('Finish line', `Longest drift ${bestCombo.toFixed(1)} seconds.`, true); }
  };
}

export const rhythm = {
  spikes: mode('Space, ↑, or tap to jump. Clear the spikes and gaps.', g => runner(g, false)),
  tunnel: mode('← / → or tap either side to rotate into the open sections.', tunnel),
  slice: mode('Press F, G, J, K or tap a lane as its note reaches the bright line.', beatblade),
  gravity: mode('Space, ↑, or tap to flip between floor and ceiling.', g => runner(g, true)),
  lasers: mode('Arrows / WASD or onscreen arrows. Cross each laser while it’s off.', laserEscape, directions),
  drift: mode('← / → or onscreen arrows to steer. Hold Space or Drift through corners.', drift, horizontal, [['space', 'Drift']]),
};
