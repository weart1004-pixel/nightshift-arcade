import { W, H, TAU, clamp, distance, drawShip, inRect, unit } from './engine.js';
import { mode, directions } from './controls.js';

function arena(g, tanks) {
  const p = { x: W / 2, y: H / 2 };
  const walls = tanks ? [
    [230, 113, 25, 190], [702, 239, 25, 188], [340, 383, 224, 24], [423, 132, 185, 22],
  ] : [[205, 137 + g.level * 8, 90, 35], [650, 343 - g.level * 10, 100, 42], [320, 385, 45, 94]];
  const shots = [], enemies = [];
  const target = (tanks ? 15 : 30) + g.level * (tanks ? 3 : 7);
  let hp = 5, remaining = target, kills = 0, spawn = 0, fire = 0, immune = 0, angle = 0;
  const wallHit = (q, r = 0) => walls.some(([x, y, w, h]) => inRect(q, x - r, y - r, w + r * 2, h + r * 2));
  function move(q, vx, vy, dt, pad) {
    const x = clamp(q.x + vx * dt, 24, W - 24), y = clamp(q.y + vy * dt, 69, H - 22);
    if (!wallHit({ x, y: q.y }, pad)) q.x = x;
    if (!wallHit({ x: q.x, y }, pad)) q.y = y;
  }
  function shoot(origin, a, enemy = false) {
    const speed = enemy ? 260 + g.level * 14 : tanks ? 485 : 580;
    shots.push({ x: origin.x + Math.cos(a) * 23, y: origin.y + Math.sin(a) * 23,
      vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, enemy, bounces: tanks ? 2 : 0, life: 2.3 });
  }
  function drawUnit(q, a, enemy) {
    const tint = enemy ? tanks ? '#cf7184' : q.hp > 1 ? '#b07c92' : '#659660' : '#74c9cb';
    g.ctx.save(); g.ctx.translate(q.x, q.y); g.ctx.rotate(a);
    if (tanks) {
      g.box(-17, -18, 34, 12, '#181f34', 3, '#677389');
      g.box(-17, 6, 34, 12, '#181f34', 3, '#677389');
      g.box(-17, -11, 34, 22, tint, 4, '#eee3c5');
      g.dot(0, 0, 8, '#293144', '#a3a8b6');
    } else g.dot(0, 0, 15, tint, enemy ? '#c6e8ae' : '#b7faff', 2.5);
    g.line(1, 0, 26, 0, enemy && !tanks ? '#b1b76e' : '#cee9ea', tanks ? 7 : 5);
    g.ctx.restore();
  }
  return dt => {
    const input = g.move(), speed = tanks ? 170 : 215;
    move(p, input.x * speed, input.y * speed, dt, 17);
    const nearest = enemies.reduce((a, b) => !a || distance(p, b) < distance(p, a) ? b : a, null);
    const toward = g.pointer.down || g.pointer.tap ? g.pointer : nearest;
    if (toward) angle = Math.atan2(toward.y - p.y, toward.x - p.x);
    else if (input.x || input.y) angle = Math.atan2(input.y, input.x);
    spawn -= dt; fire -= dt; immune -= dt;
    const waveSize = Math.ceil(target / 3);
    const canSpawn = tanks || target - remaining < Math.min(target, (Math.floor(kills / waveSize) + 1) * waveSize);
    if (dt && canSpawn && spawn <= 0 && remaining > 0 && enemies.length < 16) {
      const edge = remaining % 4;
      enemies.push({ x: edge === 0 ? 29 : edge === 1 ? W - 29 : g.rand(60, W - 55),
        y: edge === 2 ? 73 : edge === 3 ? H - 23 : g.rand(83, H - 52), next: g.rand(1.1, 2.3),
        hp: tanks ? 2 + +(g.level > 2) : remaining % 8 === 0 ? 3 : 1, phase: g.rand(0, TAU) });
      remaining--; spawn = (tanks ? 1.7 : .65) - g.level * .049;
    }
    if (dt && fire <= 0 && (g.key('space') || g.key('enter') || g.pointer.down || g.pointer.tap)) {
      shoot(p, angle); fire = tanks ? .4 : .17; g.beep(tanks ? 127 : 224, .06, 'triangle', .033);
    }
    for (const e of enemies) {
      const a = Math.atan2(p.y - e.y, p.x - e.x);
      const direction = tanks && distance(p, e) < 157 + e.phase * 11 ? -.55 : 1;
      const swing = Math.sin(g.time * 2.2 + e.phase) * (tanks ? 1.04 : .40);
      const s = ((tanks ? 58 : 70) + g.level * 9 + e.phase * 5) * direction;
      move(e, Math.cos(a + swing) * s, Math.sin(a + swing) * s, dt, 15);
      if (tanks && g.time > e.next) { shoot(e, a + g.rand(-.19, .19), true); e.next = g.time + g.rand(1.7, 2.6) - g.level * .08; }
      if (!tanks && immune <= 0 && distance(e, p) < 30) { hp--; immune = 1.1; g.beep(100, .18); }
    }
    for (let i = shots.length - 1; i >= 0; i--) {
      const s = shots[i], x = s.x + s.vx * dt, y = s.y + s.vy * dt;
      s.life -= dt;
      const bx = x < 8 || x > W - 8 || wallHit({ x, y: s.y });
      const by = y < 61 || y > H - 8 || wallHit({ x: s.x, y });
      if (s.life <= 0 || ((bx || by) && s.bounces-- < 1)) { shots.splice(i, 1); continue; }
      if (bx) s.vx *= -1; else s.x = x;
      if (by) s.vy *= -1; else s.y = y;
      if (s.enemy) {
        if (distance(p, s) >= 19) continue;
        if (immune <= 0) { hp--; immune = .9; g.beep(112, .15); }
      } else {
        const index = enemies.findIndex(e => distance(e, s) < 23);
        if (index < 0) continue;
        if (--enemies[index].hp <= 0) { enemies.splice(index, 1); kills++;
          if (!tanks && kills % waveSize === 0) spawn = 1.8;
          g.beep(480, .09, 'triangle', .035); }
      }
      shots.splice(i, 1);
    }
    g.score = kills * 110;
    g.image(tanks ? '#172636' : '#162028', tanks ? '#19283a' : '#243427');
    g.grid(40, tanks ? '#b49acd18' : '#a0c58f18');
    for (const [x, y, w, h] of walls) {
      g.box(x, y, w, h, tanks ? '#475473' : '#34473e', 4, tanks ? '#7e89a0' : '#687e69');
      g.line(x + 6, y + 4, x + w - 6, y + 4, '#bbc0b44a', 2);
    }
    for (const e of enemies) drawUnit(e, Math.atan2(p.y - e.y, p.x - e.x), true);
    for (const s of shots) g.dot(s.x, s.y, tanks ? 5 : 3.8, s.enemy ? '#ff8f9d' : '#ffe3a3');
    if (immune <= 0 || Math.floor(g.time * 14) % 2) drawUnit(p, angle, false);
    if (g.pointer.active && !g.pointer.down) g.dot(g.pointer.x, g.pointer.y, 8, null, '#e6e0b28f');
    g.box(0, 0, W, 56, '#151526e8');
    g.label(`Armor ${'◆'.repeat(Math.max(0, hp))}`, 24, 28, '#9effd2', 20);
    g.label(tanks ? `Tanks ${kills}/${target}` : `Wave ${Math.min(3, 1 + Math.floor(kills / Math.ceil(target / 3)))}   •   Cleared ${kills}/${target}`, W - 24, 28, '#e8d8fa', 19, 'right');
    if (dt && hp <= 0) g.end('Run over', `You cleared ${kills} of ${target}.`);
    else if (dt && kills >= target) { g.score += hp * 160; g.end('Arena cleared', `You defeated all ${target} opponents.`, true); }
  };
}

function bulletHell(g) {
  const p = { x: W / 2, y: H - 69 }, waves = 4 + Math.floor(g.level / 2);
  const projectiles = [], enemies = [], beams = [];
  let wave = 0, hp = 4, safe = 0, shot = 0, later = .7, kills = 0;
  return dt => {
    const m = g.move();
    p.x = clamp(p.x + m.x * dt * 300, 20, W - 20);
    p.y = clamp(p.y + m.y * dt * 300, 68, H - 18);
    if (g.pointer.down) {
      p.x = clamp(p.x + (g.pointer.x - p.x) * Math.min(1, dt * 11), 20, W - 20);
      p.y = clamp(p.y + (g.pointer.y - p.y) * Math.min(1, dt * 11), 68, H - 18);
    }
    shot -= dt; safe -= dt;
    if ((g.key('space') || g.pointer.down) && shot <= 0) {
      for (const dx of [-11, 11]) beams.push({ x: p.x + dx, y: p.y - 11 });
      shot = .137; g.beep(292, .04, 'triangle', .024);
    }
    if (!enemies.length && wave < waves && g.time >= later) {
      wave++;
      const n = 2 + wave + Math.floor(g.level / 3);
      for (let i = 0; i < n; i++) enemies.push({
        x: (i + 1) * W / (n + 1), y: -40, target: 92 + i % 2 * 63, hp: 3 + wave + Math.floor(g.level / 2),
        next: g.time + g.rand(1.3, 2.6), phase: g.rand(0, TAU),
      });
    }
    for (const e of enemies) {
      e.y += (e.target - e.y) * Math.min(1, dt * 1.7);
      e.x += Math.cos(g.time * 2.35 + e.phase) * dt * 54;
      if (g.time < e.next) continue;
      e.next += g.rand(1.35, 2.55) - g.level * .06;
      const mid = Math.atan2(p.y - e.y, p.x - e.x);
      for (let i = -2; i <= 2; i++) {
        const a = mid + i * .27, v = 145 + g.level * 13 + wave * 8;
        projectiles.push({ x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v });
      }
    }
    for (let i = beams.length - 1; i >= 0; i--) {
      const b = beams[i]; b.y -= dt * 650;
      const index = enemies.findIndex(e => distance(e, b) < 24);
      if (index >= 0) {
        if (--enemies[index].hp <= 0) { enemies.splice(index, 1); kills++; g.beep(575, .11, 'sine'); later = g.time + 1.25; }
        beams.splice(i, 1);
      } else if (b.y < -12) beams.splice(i, 1);
    }
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const b = projectiles[i]; b.x += b.vx * dt; b.y += b.vy * dt;
      if (distance(b, p) < 16) {
        if (safe <= 0) { hp--; safe = 1.05; g.beep(102, .18); }
        projectiles.splice(i, 1);
      } else if (b.x < -40 || b.x > W + 40 || b.y < -45 || b.y > H + 40) projectiles.splice(i, 1);
    }
    g.score = kills * 120;
    g.image('#111032', '#161135'); g.starlight(56);
    for (const b of beams) g.line(b.x, b.y, b.x, b.y + 13, '#96fff8', 4);
    for (const b of projectiles) g.dot(b.x, b.y, 6.5, '#ff75b1', '#ffd4e8', 1.4);
    for (const e of enemies) drawShip(g, e.x, e.y, Math.PI / 2, '#ad5bad', 1.3);
    if (safe <= 0 || Math.floor(g.time * 14) % 2) drawShip(g, p.x, p.y, -Math.PI / 2, '#53cbec', 1.13);
    g.label(`Wave ${wave}/${waves}`, 24, 29);
    g.label(`Shields ${'◆'.repeat(Math.max(0, hp))}`, W - 23, 29, '#cfe6ff', 20, 'right');
    if (dt && hp <= 0) g.end('Fighter down', `You cleared ${kills} ships.`);
    else if (dt && wave === waves && !enemies.length && g.time > later) { g.score += 500; g.end('Sector clear', `You cleared all ${waves} waves.`, true); }
  };
}

function scope(g) {
  const target = 8 + g.level * 2, timer = 45 - g.level;
  const drones = Array.from({ length: 6 }, (_, i) => ({
    x: 147 + i * 134, y: g.rand(136, 422), phase: g.rand(0, TAU), code: g.random() < .45, disabled: 0,
  }));
  let scans = 0, mistakes = 0, cool = 0, result = '', resultUntil = 0;
  return dt => {
    const calm = (g.time + .3 + g.level * .13) % 5.6 < 3.55 - g.level * .13;
    for (const d of drones) {
      d.px = d.x + Math.sin(g.time * (1.08 + g.level * .12) + d.phase) * 64;
      d.py = d.y + Math.cos(g.time * .8 + d.phase) * 35;
      if (d.disabled && d.disabled < g.time) { d.disabled = 0; d.code = g.random() < .52; }
    }
    if (!drones.some(d => d.code && !d.disabled)) {
      const available = drones.find(d => !d.disabled);
      if (available) available.code = true;
    }
    if ((g.pointer.tap || g.action()) && g.time >= cool) {
      const picked = drones.find(d => !d.disabled && distance({ x: d.px, y: d.py }, g.pointer) < 32);
      cool = g.time + .34; resultUntil = g.time + .7;
      if (picked?.code && calm) { picked.disabled = g.time + 2.4; scans++; result = 'DRONE DISABLED'; g.beep(634); }
      else { mistakes++; result = calm ? 'WRONG SIGNAL' : 'ALARM ACTIVE'; g.beep(134, .16, 'square', .035); }
    }
    g.image('#0d1d2a', '#1d1935'); g.grid(33, '#81cdd61f');
    for (let i = 0; i < 16; i++) {
      const h = 51 + i * 64 % 220;
      g.box(i * 65, H - h, 52, h, '#26303e', 4);
      for (let j = 0; j < h / 14; j++) g.line(i * 65 + 10, H - h + j * 14, i * 65 + 37, H - h + j * 14, '#b98fca3c', 2);
    }
    for (const d of drones) if (!d.disabled) {
      const color = d.code ? '#ff6fb2' : '#7ce4c8';
      g.glow(color, 11, () => g.box(d.px - 22, d.py - 10, 44, 20, '#202737', 7, color));
      for (const side of [-1, 1]) g.line(d.px + side * 11, d.py - 11, d.px + side * 34, d.py - 17, color, 4);
      g.dot(d.px, d.py, 4, color);
    }
    const { x, y } = g.pointer;
    g.dot(x, y, 37, '#8ddcff0a', '#9ce9fa', 2);
    g.line(x - 49, y, x - 9, y, '#8de1ff', 1.6); g.line(x + 9, y, x + 49, y, '#8de1ff', 1.6);
    g.line(x, y - 49, x, y - 9, '#8de1ff', 1.6); g.line(x, y + 9, x, y + 49, '#8de1ff', 1.6);
    g.label(`Scans ${scans}/${target}   •   Errors ${mistakes}/4`, 25, 28);
    g.label(calm ? 'SCAN WINDOW OPEN' : 'WAIT • ALARM', W - 23, 28, calm ? '#8ef9ca' : '#ff8db2', 19, 'right');
    g.label(`${Math.max(0, Math.ceil(timer - g.time))}s`, W - 24, 460, '#d8c9f2', 20, 'right');
    if (resultUntil > g.time) g.label(result, W / 2, 483, result === 'DRONE DISABLED' ? '#a0fad8' : '#fb8da9', 25, 'center');
    g.score = scans * 120;
    if (dt && (mistakes >= 4 || g.time >= timer)) g.end('Signal lost', `You collected ${scans} scans.`);
    else if (dt && scans >= target) { g.score += 450; g.end('Drone network mapped', 'Every rogue signal was identified.', true); }
  };
}

function ninja(g) {
  const p = { x: W / 2, y: H / 2 + 55 };
  const shadows = [], trail = [], total = 22 + g.level * 5;
  let hp = 4, next = .6, dash = 0, recovery = 0, safe = 0, combo = 0, hit = 0, remaining = total;
  let heading = { x: 1, y: 0 };
  return dt => {
    let m = g.move();
    if ((g.action() || g.pointer.tap) && recovery <= 0) {
      if (g.pointer.tap) m = unit(g.pointer.x - p.x, g.pointer.y - p.y);
      if (!(m.x || m.y)) m = heading;
      heading = m; dash = .23; recovery = .58; combo = 0; g.beep(710, .09, 'triangle', .035);
    }
    if (!dash && (m.x || m.y)) heading = m;
    if (dash && dt) { trail.push({ x: p.x, y: p.y, until: g.time + .19 }); m = heading; }
    const v = dash > 0 ? 850 : 207;
    p.x = clamp(p.x + m.x * dt * v, 25, W - 25); p.y = clamp(p.y + m.y * dt * v, 76, H - 22);
    recovery -= dt; safe -= dt;
    if (g.time >= next && remaining > 0 && shadows.length < 12) {
      const side = remaining % 4;
      shadows.push({ x: side === 0 ? 28 : side === 1 ? W - 28 : g.rand(34, W - 34),
        y: side === 2 ? 78 : side === 3 ? H - 25 : g.rand(86, H - 25), speed: g.rand(42, 92) + g.level * 8 });
      remaining--; next = g.time + .71 - g.level * .039;
    }
    for (let i = shadows.length - 1; i >= 0; i--) {
      const e = shadows[i], u = unit(p.x - e.x, p.y - e.y);
      e.x += u.x * e.speed * dt; e.y += u.y * e.speed * dt;
      if (distance(p, e) >= (dash > 0 ? 47 : 26)) continue;
      if (dash > 0) { shadows.splice(i, 1); combo++; hit++; g.score += 85 + combo * 25; g.beep(380 + combo * 95, .083); }
      else if (safe <= 0) { hp--; safe = 1.05; g.beep(110, .14); }
    }
    dash = Math.max(0, dash - dt);
    g.image('#252041', '#351827'); g.starlight(4);
    g.glow('#d56d9f', 29, () => g.dot(744, 120, 43, '#ef9196'));
    for (let i = 0; i < 13; i++) g.poly([[i * 80 - 24, H], [i * 80 + 19, 124 + (i * 77 % 260)], [i * 80 + 86, H]], '#2c223e', '#754461');
    while (trail[0]?.until < g.time) trail.shift();
    for (const d of trail) g.dot(d.x, d.y, (d.until - g.time) * 131, '#7df5df64');
    for (const e of shadows) { g.dot(e.x, e.y, 17, '#2b1846', '#b17ac2'); g.line(e.x - 6, e.y - 3, e.x + 6, e.y - 3, '#f8a6ce', 3); }
    if (safe <= 0 || Math.floor(g.time * 14) % 2) drawShip(g, p.x, p.y, Math.atan2(heading.y, heading.x), '#8bf5df', dash > 0 ? 1.55 : .96);
    g.label(`Shadows ${hit}/${total}`, 24, 27);
    g.label(`Health ${'◆'.repeat(Math.max(0, hp))}`, W - 26, 26, '#e8bcf0', 20, 'right');
    g.meter(24, 76, 165, 1 - Math.max(0, recovery) / .58, '#9cf6de', 'Dash');
    if (dt && hp <= 0) g.end('Out of health', `You cleared ${hit} shadows.`);
    else if (dt && hit >= total) { g.score += hp * 150; g.end('Rooftops cleared', 'Every shadow has been defeated.', true); }
  };
}

function mech(g) {
  const p = { x: 250, y: 314 }, stages = 3 + Math.floor(g.level / 2);
  let health = 100, stage = 0, charge = 0, cooldown = 0, dodge = 0, callout = '', callTime = 0;
  const makeEnemy = () => ({ x: W - 241, y: 310, hp: 75 + stage * 17 + g.level * 10, shield: 2 + Number(stage > 1), at: g.time + 1.75 });
  let enemy = makeEnemy();
  const flash = text => { callout = text; callTime = g.time + .53; };
  function robot(q, color) {
    g.ctx.save(); g.ctx.translate(q.x, q.y);
    for (const x of [-30, 12]) g.box(x, 12, 18, 25, '#4c455d', 5, color);
    for (const x of [-49, 30]) g.box(x, -13, 19, 31, '#50415e', 6, color);
    g.box(-31, -26, 62, 51, '#3e3456', 9, color);
    g.box(-19, -41, 38, 23, color, 6, '#e7daf6');
    g.line(-11, -32, 12, -32, '#1c1730', 5);
    g.dot(0, 0, 11, color, '#ffe7ff');
    g.ctx.restore();
  }
  return dt => {
    const m = g.move();
    if (g.pressed('shift') && dodge <= -.25) { dodge = .43; flash('DODGE'); }
    p.x = clamp(p.x + m.x * dt * (dodge > 0 ? 390 : 193), 61, W - 59);
    p.y = clamp(p.y + m.y * dt * (dodge > 0 ? 390 : 193), 120, H - 65);
    cooldown -= dt; dodge -= dt; charge = clamp(charge + dt * .23, 0, 1);
    if (g.action() && cooldown <= 0) {
      cooldown = .38;
      if (distance(p, enemy) < 119) {
        if (enemy.shield > 0) { enemy.shield--; flash('SHIELD HIT'); }
        else { enemy.hp -= 21 + Math.round(charge * 13); charge *= .32; flash('DIRECT HIT'); }
        g.beep(164, .1, 'square', .043);
      } else flash('GET CLOSER');
    }
    if (enemy.hp <= 0) {
      stage++; g.score += 550; g.beep(520, .19); health = Math.min(100, health + 23); enemy = makeEnemy(); flash('RIVAL DOWN');
    }
    const u = unit(p.x - enemy.x, p.y - enemy.y), close = distance(p, enemy);
    const warning = g.time > enemy.at - .55;
    if (dt && close > 78 && !warning) { enemy.x += u.x * dt * (106 + g.level * 8); enemy.y += u.y * dt * (106 + g.level * 8); }
    if (g.time > enemy.at) {
      if (close < 122 + g.level * 3 && dodge <= 0) { health -= 15 + g.level; g.beep(92, .24); flash('ARMOR HIT'); }
      enemy.at = g.time + g.rand(1.38, 1.91) - g.level * .052;
    }
    g.image('#1e1937', '#342348'); g.grid(49, '#ccacff1d');
    g.box(32, 88, W - 64, H - 127, '#35293d5d', 33, '#a371b9');
    g.dot(W / 2, 317, 157, '#714b9a21', '#9c78be4f');
    if (warning) g.dot(enemy.x, enemy.y, 123 + g.level * 3, '#ed397023', '#fc729e', 2);
    robot(enemy, '#ee7f9d'); robot(p, '#bfa1fa');
    if (enemy.shield) g.dot(enemy.x, enemy.y, 48, '#8a9df726', '#b2aafa');
    if (callTime > g.time) g.label(callout, W / 2, 101, '#f5a6cf', 26, 'center');
    g.meter(25, 49, 221, health / 100, '#a7eecd', `Armor ${Math.max(0, health)}%`);
    g.meter(706, 49, 217, enemy.hp / (75 + stage * 17 + g.level * 10), '#fd91ab', `Rival ${Math.min(stages, stage + 1)}/${stages}`);
    if (dt && health <= 0) g.end('Mech disabled', `You beat ${stage} rivals.`);
    else if (dt && stage >= stages) { g.score += health * 10; g.end('Arena champion', `You beat all ${stages} rivals.`, true); }
  };
}

export const action = {
  zombies: mode('Arrows / WASD to move. Aim and hold the pointer, or hold Space for auto-aim.', g => arena(g, false), directions, [['space', 'Fire']]),
  bullet: mode('Drag to move and fire, or move with arrows / WASD and hold Space to fire.', bulletHell, directions, [['space', 'Fire']]),
  tank: mode('Arrows / WASD to move. Aim with the pointer or hold Space for auto-aim. Shots bounce.', g => arena(g, true), directions, [['space', 'Fire']]),
  scope: mode('Tap a pink drone to take a shot during the open window. Green drones are friendly.', scope),
  ninja: mode('Move with arrows / WASD and press Space to dash. Tap a spot to dash toward it.', ninja, directions, [['space', 'Dash']]),
  mech: mode('Move with arrows / WASD. Space or Punch to strike nearby, Shift or Dodge to evade.', mech, directions, [['space', 'Punch'], ['shift', 'Dodge']]),
};
