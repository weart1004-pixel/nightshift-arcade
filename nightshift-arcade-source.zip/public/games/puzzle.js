import { W, H, TAU, clamp, distance, inRect } from './engine.js';
import { mode, directions } from './controls.js';

const cardinal = [[1, 0], [0, 1], [-1, 0], [0, -1]];
const tint = ['#ff829e', '#79d6ff', '#8af0ab', '#ffd981'];
function board(g, cols, rows, tile, left = (W - cols * tile) / 2, top = (H - rows * tile) / 2 + 15) {
  const point = (x, y) => [left + (x + .5) * tile, top + (y + .5) * tile];
  function cell() {
    const x = Math.floor((g.pointer.x - left) / tile), y = Math.floor((g.pointer.y - top) / tile);
    return x >= 0 && x < cols && y >= 0 && y < rows ? [x, y] : null;
  }
  function draw() {
    g.box(left - 5, top - 5, cols * tile + 10, rows * tile + 10, '#141325', 9, '#4d4465');
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      g.box(left + x * tile + 2, top + y * tile + 2, tile - 4, tile - 4, (x + y) % 2 ? '#1b2339' : '#20283e', 5);
    }
  }
  return { draw, point, cell, left, top, tile };
}

function mirrors(g) {
  const b = board(g, 10, 6, 65);
  const cy = 1 + g.level % 2;
  const farY = 5;
  const middle = 2 + g.level % 3;
  const farther = 6 + g.level % 2;
  const ty = g.level % 3;
  const source = { x: 0, y: cy }, target = { x: 9, y: ty };
  const goalPieces = [
    { x: middle, y: cy, required: 1 }, { x: middle, y: farY, required: 1 },
    { x: farther, y: farY, required: 0 }, { x: farther, y: ty, required: 0 },
  ];
  const decoys = [{ x: 1, y: 4 }, { x: 5, y: 3 }, { x: 8, y: 4 }, { x: 4, y: 0 }, { x: 5, y: 1 }]
    .filter(c => {
      const beforeFirstTurn = c.y === cy && c.x <= middle;
      const firstColumn = c.x === middle && c.y >= cy;
      const bottomRow = c.y === farY && c.x >= middle && c.x <= farther;
      const lastColumn = c.x === farther && c.y >= ty;
      const lastRow = c.y === ty && c.x >= farther;
      return !(beforeFirstTurn || firstColumn || bottomRow || lastColumn || lastRow);
    });
  const pieces = [...goalPieces, ...decoys.slice(0, 2 + Math.floor(g.level / 2))].map((p, i) => ({
    ...p, turn: i === 0 ? 1 - p.required : g.random() < .5 ? 1 : 0,
  }));
  let moves = 0;
  function cast() {
    const route = [source], seen = new Set();
    let x = source.x, y = source.y, dir = 0;
    for (let i = 0; i < 70; i++) {
      x += cardinal[dir][0]; y += cardinal[dir][1]; route.push({ x, y });
      if (x === target.x && y === target.y) return { route, won: true };
      if (x < 0 || y < 0 || x >= 10 || y >= 6) break;
      const id = x + ',' + y + ',' + dir;
      if (seen.has(id)) break;
      seen.add(id);
      const m = pieces.find(p => p.x === x && p.y === y);
      if (m) dir = m.turn ? [1, 0, 3, 2][dir] : [3, 2, 1, 0][dir];
    }
    return { route, won: false };
  }
  return dt => {
    if (g.pointer.tap) {
      const c = b.cell();
      const m = c && pieces.find(p => p.x === c[0] && p.y === c[1]);
      if (m) { m.turn = 1 - m.turn; moves++; g.beep(370, .07, 'triangle', .04); }
    }
    const { route, won } = cast();
    g.image('#101735', '#14283c'); b.draw();
    g.glow('#66dffe', 12, () => {
      for (let i = 1; i < route.length; i++) {
        g.line(...b.point(route[i - 1].x, route[i - 1].y), ...b.point(route[i].x, route[i].y), '#72e6ff', 4);
      }
    });
    for (const m of pieces) {
      const [x, y] = b.point(m.x, m.y), d = m.turn ? 20 : -20;
      g.dot(x, y, 28, '#273858', '#4d87a0');
      g.line(x - 19, y - d, x + 19, y + d, '#adf4fa', 8);
      g.line(x - 19, y - d, x + 19, y + d, '#fff5ff', 2);
    }
    const [sx, sy] = b.point(source.x, source.y), [tx, ty2] = b.point(target.x, target.y);
    g.box(sx - 23, sy - 19, 44, 38, '#4588b1', 7, '#abf5ff');
    g.dot(sx + 19, sy, 8, '#d4feff');
    g.dot(tx, ty2, 24, won ? '#81f7bb' : '#253f57', '#8cffe4', 4);
    g.dot(tx, ty2, 8, won ? '#eafff2' : '#4a8291');
    g.label('Guide the beam to the receiver', 28, 31); g.label('Turns ' + moves, W - 25, 31, '#a9dcfb', 20, 'right');
    if (dt && won) { g.score = Math.max(220, 1500 - moves * 40); g.end('Receiver powered', 'You aligned the beam in ' + moves + ' turns.', true); }
  };
}

const slideLayouts = [
  [[0, 2, 2, 0], [1, 3, 2, 0], [2, 4, 2, 1], [5, 1, 2, 1], [4, 4, 2, 1], [4, 1, 2, 1], [0, 0, 2, 1], [1, 0, 2, 1], [3, 2, 3, 1], [3, 0, 2, 1], [0, 3, 2, 1]],
  [[1, 2, 2, 0], [0, 4, 2, 1], [4, 2, 3, 1], [4, 1, 2, 0], [0, 2, 2, 1], [1, 3, 3, 1], [3, 1, 2, 1], [2, 4, 2, 1], [3, 4, 2, 1], [5, 3, 2, 1], [4, 5, 2, 0], [0, 1, 3, 0]],
  [[1, 2, 2, 0], [3, 5, 2, 0], [4, 1, 3, 1], [0, 4, 2, 1], [1, 1, 3, 0], [0, 1, 2, 1], [1, 3, 2, 1], [0, 0, 2, 0], [4, 4, 2, 0], [4, 0, 2, 0], [5, 1, 3, 1], [3, 3, 2, 1]],
  [[0, 2, 2, 0], [5, 0, 2, 1], [2, 3, 2, 1], [3, 4, 3, 0], [3, 1, 2, 0], [2, 0, 2, 1], [0, 3, 2, 1], [5, 2, 2, 1], [3, 2, 2, 1]],
  [[2, 2, 2, 0], [3, 3, 2, 1], [4, 3, 2, 0], [1, 3, 2, 1], [4, 4, 2, 0], [0, 5, 2, 0], [4, 0, 3, 1], [2, 1, 2, 0], [0, 1, 2, 0]],
  [[1, 2, 2, 0], [0, 5, 3, 0], [2, 0, 2, 1], [2, 3, 2, 0], [0, 3, 2, 0], [4, 3, 2, 1], [5, 1, 2, 1], [4, 1, 2, 1], [3, 0, 2, 1], [2, 4, 2, 0], [0, 0, 3, 1], [4, 0, 2, 0]],
];

function sliding(g) {
  const n = 6, b = board(g, n, n, 68);
  const original = slideLayouts[g.level];
  const blocks = original.map(([x, y, length, vertical]) => ({ x, y, length, vertical }));
  let selected = -1, moves = 0, drag = null;
  const occupies = (block, x, y) => block.vertical
    ? x === block.x && y >= block.y && y < block.y + block.length
    : y === block.y && x >= block.x && x < block.x + block.length;
  function slide(index, step) {
    const block = blocks[index];
    if (!block || !step) return;
    let changed = false;
    for (let i = 0; i < Math.abs(step); i++) {
      const d = Math.sign(step), edge = d > 0 ? block.length : -1;
      const x = block.x + (block.vertical ? 0 : edge), y = block.y + (block.vertical ? edge : 0);
      if (x < 0 || y < 0 || x >= n || y >= n || blocks.some(c => c !== block && occupies(c, x, y))) break;
      if (block.vertical) block.y += d; else block.x += d;
      changed = true;
    }
    if (!changed) return;
    moves++; g.beep(290, .07, 'triangle', .04);
  }
  return dt => {
    if (g.pressed('r') || g.hitBox(749, 89, 177, 53)) {
      original.forEach(([x, y], i) => Object.assign(blocks[i], { x, y }));
      selected = -1; moves = 0; drag = null;
    }
    if (g.pointer.tap && b.cell()) {
      const [x, y] = b.cell(), index = blocks.findIndex(block => occupies(block, x, y));
      if (index >= 0) { selected = index; drag = { x: g.pointer.x, y: g.pointer.y, index }; }
      else if (selected >= 0) {
        const block = blocks[selected];
        const along = block.vertical ? x === block.x : y === block.y;
        if (along) slide(selected, (block.vertical ? y - block.y : x - block.x));
      }
    }
    if (g.pointer.released && drag) {
      const vertical = blocks[drag.index].vertical;
      const amount = vertical ? g.pointer.y - drag.y : g.pointer.x - drag.x;
      slide(drag.index, Math.round(amount / b.tile));
      drag = null;
    }
    if (selected >= 0) {
      const block = blocks[selected];
      if (g.pressed(block.vertical ? 'up' : 'left')) slide(selected, -1);
      if (g.pressed(block.vertical ? 'down' : 'right')) slide(selected, 1);
    }
    g.image('#2b1d2c', '#1c1a30'); b.draw();
    const [rx, ry] = b.point(n - 1, 2);
    g.box(rx + 34, ry - 23, 39, 46, '#4a5148', 5, '#a9e3b6');
    g.label('→', rx + 55, ry, '#cdffd6', 25, 'center');
    g.label('EXIT', rx + 55, ry + 40, '#a9e3b6', 14, 'center');
    const colors = ['#a4715d', '#8d665e', '#725b7f', '#97696c', '#866750'];
    blocks.forEach((block, index) => {
      const [cx, cy] = b.point(block.x, block.y);
      const x = cx - b.tile / 2 + 4, y = cy - b.tile / 2 + 4;
      const w = b.tile * (block.vertical ? 1 : block.length) - 8, h = b.tile * (block.vertical ? block.length : 1) - 8;
      const color = index ? colors[index % colors.length] : '#cb566f';
      g.box(x, y, w, h, color, 9, index === selected ? '#fff0b7' : index ? '#cfa89c' : '#ffa9ab');
      for (let i = 0; i < 3; i++) {
        if (block.vertical) g.line(x + 16 + i * 13, y + 9, x + 16 + i * 13, y + h - 9, '#fff2d122', 2);
        else g.line(x + 9, y + 16 + i * 13, x + w - 9, y + 16 + i * 13, '#fff2d122', 2);
      }
      if (!index) g.label('→', x + w / 2, y + h / 2, '#fff2e7', 36, 'center');
    });
    g.label('Slide the red block to the exit', 26, 27); g.label('Moves ' + moves, W - 26, 28, '#f4c7b4', 20, 'right');
    g.button(749, 89, 177, 53, 'Reset', 'R', g.pointer);
    g.label('Each block can slide along its longest side.', W / 2, 512, '#dfc7d7', 18, 'center');
    if (dt && blocks[0].x === n - blocks[0].length) {
      g.score = Math.max(220, 2050 - moves * 34); g.end('Block escaped', 'You freed the red block in ' + moves + ' moves.', true);
    }
  };
}

function pipes(g) {
  const cols = 8, rows = 6, b = board(g, cols, rows, 64);
  const startRow = 1 + g.level % 4;
  let row = startRow;
  const path = [[0, row]];
  for (let x = 1; x < cols; x++) {
    path.push([x, row]);
    if (x === cols - 1 || (x + g.level) % 2 === 0) continue;
    const change = x % 3 === 0 ? 2 : 1;
    const next = clamp(row + (x % 4 < 2 ? change : -change), 0, rows - 1);
    while (row !== next) { row += Math.sign(next - row); path.push([x, row]); }
  }
  const endRow = row;
  const mask = (x, y) => 1 << cardinal.findIndex(([dx, dy]) => dx === x && dy === y);
  const cells = Array.from({ length: rows }, () => Array.from({ length: cols }, () => g.pick([3, 5, 6, 9, 10, 12])));
  for (let i = 0; i < path.length; i++) {
    const [x, y] = path[i], [px, py] = path[i - 1] || [-1, startRow], [nx, ny] = path[i + 1] || [cols, endRow];
    cells[y][x] = mask(px - x, py - y) | mask(nx - x, ny - y);
  }
  const rotate = value => (value << 1 | value >> 3) & 15;
  cells.forEach((values, y) => values.forEach((value, x) => {
    if (x === 0 && y === startRow) return;
    const count = x === cols - 1 && y === endRow ? 1 : Math.floor(g.rand(0, 4));
    for (let i = 0; i < count; i++) value = rotate(value);
    values[x] = value;
  }));
  let moves = 0;
  function fill() {
    const queue = (cells[startRow][0] & 4) ? [[0, startRow]] : [], seen = new Set(queue.map(String));
    for (let i = 0; i < queue.length; i++) {
      const [x, y] = queue[i];
      for (let j = 0; j < 4; j++) {
        const [dx, dy] = cardinal[j], nx = x + dx, ny = y + dy, id = nx + ',' + ny;
        if (seen.has(id) || !(cells[y][x] & (1 << j)) || !(cells[ny]?.[nx] & (1 << ((j + 2) % 4)))) continue;
        seen.add(id); queue.push([nx, ny]);
      }
    }
    return seen;
  }
  return dt => {
    const c = b.cell();
    if (g.pointer.tap && c) { const [x, y] = c; cells[y][x] = rotate(cells[y][x]); moves++; g.beep(300, .055, 'triangle', .04); }
    const set = fill();
    const won = set.has((cols - 1) + ',' + endRow) && (cells[endRow][cols - 1] & 1);
    g.image('#102631', '#152437'); b.draw();
    cells.forEach((items, y) => items.forEach((value, x) => {
      const [cx, cy] = b.point(x, y), wet = set.has(x + ',' + y), color = wet ? '#78ebce' : '#65828e';
      for (let i = 0; i < 4; i++) if (value & (1 << i)) {
        const [dx, dy] = cardinal[i];
        g.line(cx, cy, cx + dx * 27, cy + dy * 27, '#0e1c29', 24);
        g.line(cx, cy, cx + dx * 26, cy + dy * 26, color, 14);
        g.line(cx, cy, cx + dx * 26, cy + dy * 26, wet ? '#d1fff0' : '#8eabb4', 3);
      }
      g.dot(cx, cy, 6, color);
    }));
    const [sx, sy] = b.point(0, startRow), [tx, ty] = b.point(cols - 1, endRow);
    g.line(sx - 35, sy, sx - 67, sy, '#81e9cd', 12); g.label('IN', sx - 69, sy, '#b5fbe1', 16, 'right');
    g.line(tx + 35, ty, tx + 67, ty, won ? '#81e9cd' : '#8c8b9b', 12); g.label('OUT', tx + 70, ty, '#b5fbe1', 16);
    g.label('Connect the inlet to the drain', 27, 29); g.label('Turns ' + moves, W - 27, 29, '#b3eadc', 20, 'right');
    if (dt && won) { g.score = Math.max(220, 2500 - moves * 24); g.end('Water flowing', 'You connected the board in ' + moves + ' turns.', true); }
  };
}

function defusal(g) {
  const names = ['ROSE', 'SKY', 'MINT', 'GOLD'];
  const rules = [
    { title: 'Direct', note: 'Use the signals in the shown order.', apply: list => list },
    { title: 'Reverse', note: 'Enter the last signal first.', apply: list => list.slice().reverse() },
    { title: 'Swap pairs', note: 'Rose ↔ Sky. Mint ↔ Gold.', apply: list => list.map(n => n ^ 1) },
    { title: 'Rotate left', note: 'Move the first signal to the end.', apply: list => list.slice(1).concat(list[0]) },
  ];
  const total = 5 + g.level, budget = 53 + g.level * 4;
  let round = 0, mistake = 0, entered = [], signal = [], answer = [], rule = 0, feed = '';
  function next() {
    rule = (round + g.level) % rules.length;
    const length = 3 + Math.floor(g.level / 2) + Number(round >= 3);
    signal = [];
    while (signal.length < length) {
      const n = Math.floor(g.rand(0, 4));
      signal.push(n === signal.at(-1) ? (n + signal.length % 3 + 1) % 4 : n);
    }
    answer = rules[rule].apply(signal);
    entered = [];
  }
  next();
  function input(value) {
    if (value !== answer[entered.length]) { mistake++; entered = []; feed = 'Sequence reset. Check the manual.'; g.beep(127, .15, 'square', .031); return; }
    entered.push(value); g.beep(384 + value * 76, .089, 'triangle', .054);
    if (entered.length === answer.length) { round++; feed = 'Signal accepted.'; next(); }
  }
  return dt => {
    g.score = round * 180;
    g.image('#261a30', '#291c2f'); g.grid(35, '#e5abfe16');
    g.label('Signal relay ' + (Math.min(round + 1, total)) + ' / ' + total, 31, 30);
    g.label('Errors ' + mistake + ' / 4', W - 31, 30, '#fac8c5', 21, 'right');
    g.box(30, 64, 565, 421, '#201a2c', 14, '#885d8b');
    g.box(617, 64, 313, 421, '#241d34', 14, '#885d8b');
    g.label('Incoming signal', 52, 101, '#e5cfec', 21);
    signal.forEach((v, i) => {
      const x = 61 + i * 76;
      g.box(x, 132, 65, 59, tint[v] + '38', 8, tint[v]);
      g.label(names[v], x + 32, 162, tint[v], 15, 'center');
    });
    g.label('Your sequence', 52, 219, '#e5cfec', 18);
    for (let i = 0; i < answer.length; i++) {
      const x = 70 + i * 39, value = entered[i];
      g.dot(x, 254, 13, value !== undefined ? tint[value] : '#473754', '#b39cc4');
    }
    names.forEach((name, i) => {
      if (g.button(54 + i * 132, 307, 115, 64, (i + 1) + '  ' + name, null, g.pointer, true, tint[i]) || g.pressed(String(i + 1))) input(i);
    });
    g.label(feed, 53, 421, '#e8c5d2', 17);
    g.label('GAME MANUAL', 640, 103, '#facbd8', 19);
    rules.forEach((item, i) => {
      const y = 132 + i * 76;
      g.box(637, y, 275, 62, i === rule ? '#52344f' : '#272138', 7, i === rule ? '#e199b3' : '#4a4159');
      g.label(item.title, 650, y + 20, i === rule ? '#ffe4ef' : '#c5b7d1', 18);
      g.label(item.note, 650, y + 43, '#d5c3d9', 13);
    });
    g.meter(32, 515, W - 64, 1 - g.time / budget, '#f697af', Math.max(0, Math.ceil(budget - g.time)) + ' seconds');
    if (dt && (mistake >= 4 || g.time >= budget)) g.end('Relay offline', 'You decoded ' + round + ' signals.');
    else if (dt && round >= total) { g.score += (budget - g.time) * 8; g.end('Relay secured', 'You decoded all ' + total + ' signals.', true); }
  };
}

function memory(g) {
  const target = 7 + g.level;
  const pattern = Array.from({ length: target }, () => Math.floor(g.rand(0, 4)));
  let round = 1, at = 0, position = 0, show = true, flash = -1, flashTime = 0;
  const colors = ['#a387ff', '#71dcf6', '#78ebbd', '#f9bb76'];
  return dt => {
    const pulse = .72 - g.level * .024;
    const index = Math.floor((g.time - at - .59) / pulse);
    if (show && index >= round) { show = false; at = g.time; flash = -1; }
    const active = show && index >= 0 && (g.time - at - .59) % pulse < pulse * .65 ? pattern[index] : -1;
    if (active !== -1 && flash !== active) {
      g.beep(300 + active * 100, .14, 'triangle', .06);
      flash = active;
    }
    if (show && active === -1) flash = -1;
    let pressed = -1;
    for (let i = 0; i < 4; i++) {
      const x = 257 + i % 2 * 232, y = 117 + Math.floor(i / 2) * 163;
      if (!show && (g.pressed(String(i + 1)) || g.hitBox(x, y, 215, 146))) pressed = i;
    }
    if (pressed !== -1) {
      flash = pressed; flashTime = g.time + .20;
      if (pattern[position] !== pressed) { g.end('Sequence broken', 'You reached a pattern of ' + round + ' tiles.'); }
      else {
        position++; g.score += 55; g.beep(300 + pressed * 100, .15, 'triangle', .06);
        if (position === round) {
          if (round === target) { g.score += 500; g.end('Pattern unlocked', 'You repeated all ' + target + ' tiles.', true); }
          else { round++; at = g.time + .25; show = true; position = 0; flash = -1; }
        }
      }
    }
    g.image('#181632', '#21152c'); g.grid(40, '#c5a1f211');
    g.label(show ? 'Watch the pattern' : 'Your turn', W / 2, 58, '#f7e7ff', 29, 'center');
    g.label('Level ' + round + ' / ' + target, 28, 29, '#d8c6ee', 18);
    for (let i = 0; i < 4; i++) {
      const x = 257 + i % 2 * 232, y = 117 + Math.floor(i / 2) * 163;
      const lit = active === i || !show && flashTime > g.time && flash === i;
      g.glow(colors[i], lit ? 26 : 0, () => g.box(x, y, 215, 146, lit ? colors[i] : colors[i] + '34', 15, colors[i]));
      g.label(String(i + 1), x + 108, y + 73, lit ? '#1e1730' : '#f4eaff', 41, 'center');
    }
    g.label(show ? 'Wait for the last tile' : position + ' of ' + round + ' matched', W / 2, 477, '#d9c7ef', 19, 'center');
  };
}

function portal(g) {
  const cols = 10, rows = 7, b = board(g, cols, rows, 58);
  const flips = [Boolean(g.level & 1), Boolean(g.level & 2)];
  const map = (x, y) => ({ x: flips[0] ? cols - 1 - x : x, y: flips[1] ? rows - 1 - y : y });
  const goals = [map(8, 4), map(6, 1)];
  const exits = [map(4, 2), map(7, 4)];
  const walls = [map(3, 4), map(4, 4), map(5, 4), map(6, 4), map(3, 5), map(4, 5), map(5, 5), map(6, 5),
    map(4, 3), map(5, 2), map(5, 3), map(6, 3)];
  if (g.level === 4) walls.push(map(2, 4), map(1, 5));
  const same = (a, c) => a.x === c.x && a.y === c.y;
  const solid = p => p.x < 1 || p.x >= cols - 1 || p.y < 1 || p.y >= rows - 1 || walls.some(c => same(c, p));
  let p, boxes, turn, oldMove = 0;
  const undo = [];
  function reset() { p = map(1, 2); boxes = [map(3, 2), map(3 + Number(g.level > 1), 1)]; turn = 0; undo.length = 0; }
  reset();
  function travel(dx, dy) {
    const to = { x: p.x + dx, y: p.y + dy };
    if (solid(to)) return;
    const index = boxes.findIndex(c => same(c, to));
    const old = [p, boxes.slice()];
    if (index !== -1) {
      let next = { x: to.x + dx, y: to.y + dy };
      if (solid(next) || boxes.some(c => same(c, next))) return;
      const portal = exits.findIndex(c => same(c, next));
      if (portal !== -1) {
        const target = exits[1 - portal];
        if (boxes.some(c => same(c, target))) return;
        next = target; g.beep(620, .15, 'triangle');
      }
      boxes[index] = next;
    }
    p = to; turn++; undo.push(old);
  }
  return dt => {
    if (g.pressed('r') || g.hitBox(747, 87, 185, 55)) reset();
    if ((g.pressed('z') || g.hitBox(747, 149, 185, 55)) && undo.length) { [p, boxes] = undo.pop(); turn--; }
    if (g.time >= oldMove && dt) {
      const button = ['right', 'down', 'left', 'up'].findIndex(key => g.key(key) || g.pressed(key));
      const tapped = g.pointer.tap && b.cell();
      if (button >= 0 || tapped) {
        let vector = cardinal[button];
        if (tapped && button < 0) {
          const x = tapped[0] - p.x, y = tapped[1] - p.y;
          vector = Math.abs(x) > Math.abs(y) ? [Math.sign(x), 0] : [0, Math.sign(y)];
        }
        if (vector[0] || vector[1]) travel(...vector);
        oldMove = g.time + .145;
      }
    }
    g.image('#15182c', '#241936'); b.draw();
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) if (solid({x, y})) {
      const [cx, cy] = b.point(x, y);
      g.box(cx - 26, cy - 26, 52, 52, '#444056', 5, '#68617d');
      g.line(cx - 17, cy - 19, cx + 17, cy - 19, '#9589a54c', 2);
    }
    goals.forEach(c => {
      const [x, y] = b.point(c.x, c.y);
      g.dot(x, y, 13, '#305a65', '#8af6de', 3);
    });
    exits.forEach((c, i) => {
      const [x, y] = b.point(c.x, c.y), color = i ? '#ab83fe' : '#ffa67d';
      g.glow(color, 15, () => g.dot(x, y, 20, color + '49', color, 4));
    });
    for (const box of boxes) {
      const [x, y] = b.point(box.x, box.y), docked = goals.some(c => same(c, box));
      g.box(x - 19, y - 19, 38, 38, docked ? '#58ae85' : '#b9796b', 5, '#ffdfc1');
      g.line(x - 12, y - 12, x + 12, y + 12, '#ffe6d18d', 2);
    }
    const [x, y] = b.point(p.x, p.y);
    g.dot(x, y, 15, '#68c9ee', '#e5f9ff', 3);
    g.label('Dock both crates', 27, 30); g.label('Moves ' + turn, W - 26, 30, '#d9c4f5', 20, 'right');
    g.box(752, 232, 180, 91, '#201934', 8, '#5c4c72');
    g.label('Portal crates', 766, 257, '#d5c4f3', 18);
    g.label('Push onto a portal', 766, 282, '#c6b5d8', 14);
    g.label('to teleport the crate.', 766, 302, '#c6b5d8', 14);
    g.button(747, 87, 185, 55, 'Reset', 'R', g.pointer);
    g.button(747, 149, 185, 55, 'Undo', 'Z', g.pointer, Boolean(undo.length));
    if (dt && goals.every(c => boxes.some(box => same(c, box)))) {
      g.score = Math.max(220, 1750 - turn * 13); g.end('Cargo delivered', 'You docked both crates in ' + turn + ' moves.', true);
    }
  };
}

export const puzzle = {
  mirrors: mode('Tap a mirror to rotate it. Guide the beam to the receiver.', mirrors),
  slide: mode('Drag a block or select it and use the arrows. Free the red block on the right.', sliding),
  pipes: mode('Tap pipes to rotate them. Connect IN to OUT.', pipes),
  defuse: mode('Follow the highlighted manual rule. Tap colors or press 1–4.', defusal),
  memory: mode('Memorize the pattern, then tap the tiles or press 1–4.', memory),
  portal: mode('Arrows / WASD, onscreen arrows, or tap the board. Z undoes a move. R resets.', portal, directions),
};
