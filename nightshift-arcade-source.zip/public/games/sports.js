import { W, H, TAU, clamp, mix, distance, inRect, unit } from './engine.js';
import { mode, horizontal, vertical } from './controls.js';

function penalty(g) {
  const goal = { x: 242, y: 113, w: 476, h: 211 }, origin = { x: W / 2, y: 458 };
  const rounds = 5 + g.level, target = Math.ceil(rounds * .64);
  let aim = { x: W / 2, y: 218 }, shot, tries = 0, scored = 0, report = '', reportAt = 0;
  const keeperPhase = g.rand(0, TAU);
  const timing = () => (Math.sin(g.time * (3.6 + g.level * .49)) + 1) / 2;
  function kick() {
    if (shot || tries >= rounds) return;
    const accuracy = Math.abs(timing() - .70);
    shot = { x: aim.x + g.rand(-1, 1) * accuracy * 216, y: aim.y + g.rand(-1, 1) * accuracy * 169, t: g.time, judged: false };
    tries++; g.beep(193, .12, 'triangle');
  }
  return dt => {
    const m = g.move();
    aim.x = clamp(aim.x + m.x * 255 * dt, goal.x + 22, goal.x + goal.w - 22);
    aim.y = clamp(aim.y + m.y * 231 * dt, goal.y + 18, goal.y + goal.h - 18);
    if (!shot && g.pointer.active && !(m.x || m.y) && inRect(g.pointer, goal.x - 28, goal.y - 20, goal.w + 56, goal.h + 45)) {
      aim.x = clamp(g.pointer.x, goal.x + 14, goal.x + goal.w - 14);
      aim.y = clamp(g.pointer.y, goal.y + 13, goal.y + goal.h - 13);
    }
    if (g.action() || g.pointer.tap && inRect(g.pointer, goal.x - 30, goal.y - 40, goal.w + 60, 427)) kick();
    const keeper = { x: W / 2 + Math.sin(g.time * (2.19 + g.level * .19) + keeperPhase) * (153 + g.level * 7), y: 242 + Math.sin(g.time * 3.8) * 20 };
    const p = shot ? clamp((g.time - shot.t) / .50, 0, 1) : 0;
    if (shot && p >= 1 && !shot.judged) {
      shot.judged = true;
      const onFrame = inRect(shot, goal.x + 6, goal.y + 6, goal.w - 12, goal.h - 12);
      const saved = Math.abs(shot.x - keeper.x) < 63 + g.level * 5 && Math.abs(shot.y - keeper.y) < 67 + g.level * 5;
      if (onFrame && !saved) { scored++; report = 'GOAL'; g.beep(650, .18, 'triangle'); }
      else { report = saved && onFrame ? 'SAVED' : 'WIDE'; g.beep(134, .18, 'triangle'); }
      reportAt = g.time;
    }
    if (shot && g.time - shot.t > 1.12) shot = undefined;
    g.image('#122a35', '#123c32');
    for (let i = 0; i < 24; i++) {
      const y = 74 + i * 20;
      const start = 75 + i % 2 * 22;
      for (let x = start; x < W - 48 && y < 252; x += 64) g.dot(x, y, 2, ['#9ed2a550', '#c5ade264', '#aacde058'][Math.floor(x / 64) % 3]);
    }
    g.box(0, 314, W, H - 314, '#285741');
    for (let i = 0; i < 5; i++) g.box(0, 326 + i * 51, W, 24, '#3b72505e');
    g.poly([[goal.x, goal.y], [goal.x + goal.w, goal.y], [goal.x + goal.w, goal.y + goal.h], [goal.x, goal.y + goal.h]], '#112731aa', '#e7fce0', 5);
    for (let x = goal.x + 15; x < goal.x + goal.w; x += 22) g.line(x, goal.y + 4, x, goal.y + goal.h - 3, '#a2e5bc3b', 1.5);
    for (let y = goal.y + 16; y < goal.y + goal.h; y += 17) g.line(goal.x + 3, y, goal.x + goal.w - 3, y, '#a2e5bc3b', 1.5);
    g.line(146, 339, 814, 339, '#c4e9c5', 2);
    g.line(146, 339, 67, 466, '#c4e9c5', 2); g.line(814, 339, 893, 466, '#c4e9c5', 2);
    g.box(keeper.x - 29, keeper.y - 22, 58, 52, '#d58775', 11, '#ffecdb');
    g.dot(keeper.x, keeper.y - 36, 13, '#e7b788', '#fef1cb');
    g.line(keeper.x - 62, keeper.y - 17, keeper.x + 62, keeper.y - 17, '#f9b68c', 13);
    g.line(keeper.x - 13, keeper.y + 14, keeper.x - 19, keeper.y + 69, '#20293d', 13);
    g.line(keeper.x + 13, keeper.y + 14, keeper.x + 19, keeper.y + 69, '#20293d', 13);
    if (!shot) g.dot(aim.x, aim.y, 14, null, '#fbf9c9', 2);
    const bx = shot ? mix(origin.x, shot.x, p) : origin.x, by = shot ? mix(origin.y, shot.y, p) - Math.sin(p * Math.PI) * 24 : origin.y;
    const r = 18 - p * 8;
    g.dot(bx, by, r, '#eff9e8', '#1d4139', 2);
    g.dot(bx - r * .18, by - r * .18, r * .36, '#264744');
    g.label('Goals ' + scored + ' / ' + target, 24, 27);
    g.label('Shots ' + tries + ' / ' + rounds, W - 24, 27, '#cdeed6', 20, 'right');
    g.meter(31, 497, 249, timing(), '#b4e498', 'Shot timing');
    g.box(31 + 249 * .68, 494, 12, 14, '#f9ddb9', 3);
    if (report && g.time - reportAt < .75) g.label(report, W / 2, 67, report === 'GOAL' ? '#a3f5ba' : '#ffb1a8', 29, 'center');
    g.score = scored * 180;
    if (dt && !shot && tries >= rounds) {
      if (scored >= target) { g.score += 400; g.end('Shootout won', scored + ' goals from ' + tries + ' shots.', true); }
      else g.end('Shootout complete', scored + ' goals from ' + tries + ' shots.');
    }
  };
}

function minigolf(g) {
  const pocket = { x: 96, y: 79, w: 768, h: 404 };
  const holes = 3 + Number(g.level > 1);
  const course = [
    [[.43, .34, .07, .42], [.62, .02, .064, .32]],
    [[.35, .0, .08, .62], [.61, .40, .075, .60], [.78, .11, .042, .24]],
    [[.26, .31, .31, .09], [.44, .63, .08, .36], [.73, .18, .08, .34]],
    [[.29, .0, .07, .57], [.43, .47, .26, .08], [.72, .10, .065, .64]],
    [[.23, .26, .28, .08], [.43, .60, .09, .40], [.68, .12, .10, .46]],
    [[.34, .47, .062, .52], [.55, .02, .078, .43], [.74, .49, .12, .15]],
  ];
  let stage = 0, shots = 0, localShots = 0, ball, flag, walls, vx = 0, vy = 0, aiming = false, angle = 0, power = .64;
  function stageStart() {
    const index = (g.level + stage) % course.length;
    ball = { x: 139, y: 410 - stage * 21 }; flag = { x: 813, y: 164 + (index % 3) * 62 };
    walls = course[index].map(([x, y, w, h]) => [pocket.x + x * pocket.w, pocket.y + y * pocket.h, w * pocket.w, h * pocket.h]);
    vx = vy = 0; localShots = 0;
  }
  stageStart();
  function shoot(x, y) {
    if (Math.hypot(x, y) < 28) return;
    const s = Math.min(565, Math.hypot(x, y)), u = unit(x, y);
    vx = u.x * s; vy = u.y * s; localShots++; shots++;
    g.beep(251, .075, 'triangle', .04);
  }
  return dt => {
    const moving = Math.hypot(vx, vy) > 11;
    if (!moving) {
      vx = vy = 0;
      if (g.pointer.tap && distance(g.pointer, ball) < 60) aiming = true;
      if (aiming && g.pointer.released) {
        aiming = false; shoot((ball.x - g.pointer.x) * 3.4, (ball.y - g.pointer.y) * 3.4);
      }
      if (g.key('left')) angle -= dt * 2.2;
      if (g.key('right')) angle += dt * 2.2;
      if (g.key('up')) power = Math.min(1, power + dt * .57);
      if (g.key('down')) power = Math.max(.11, power - dt * .57);
      if (g.action()) shoot(Math.cos(angle) * power * 560, Math.sin(angle) * power * 560);
    }
    for (let i = 0; i < 3 && dt; i++) {
      const nx = ball.x + vx * dt / 3, ny = ball.y + vy * dt / 3;
      const solid = q => walls.some(([x, y, w, h]) => inRect(q, x - 11, y - 11, w + 22, h + 22));
      if (nx < pocket.x + 12 || nx > pocket.x + pocket.w - 12 || solid({ x: nx, y: ball.y })) vx *= -.76;
      else ball.x = nx;
      if (ny < pocket.y + 12 || ny > pocket.y + pocket.h - 12 || solid({ x: ball.x, y: ny })) vy *= -.76;
      else ball.y = ny;
    }
    vx *= Math.exp(-dt * 1.21); vy *= Math.exp(-dt * 1.21);
    if (dt && distance(flag, ball) < 18 && Math.hypot(vx, vy) < 325) {
      stage++; g.score += Math.max(80, 650 - localShots * 50); g.beep(640, .2, 'triangle');
      if (stage === holes) { g.score += 400; g.end('Course complete', 'You finished ' + holes + ' holes in ' + shots + ' strokes.', true); }
      else stageStart();
    }
    g.image('#10282e', '#192337');
    g.box(pocket.x - 5, pocket.y - 5, pocket.w + 10, pocket.h + 10, '#416656', 15, '#8ad7a4');
    g.box(pocket.x, pocket.y, pocket.w, pocket.h, '#366f56', 11);
    for (let i = 0; i < 9; i++) g.box(pocket.x + 7 + i * 85, pocket.y + 6, 41, pocket.h - 12, '#6cbd7e22', 3);
    for (const [x, y, w, h] of walls) { g.box(x, y, w, h, '#26344b', 5, '#7994a9'); g.line(x + 4, y + 4, x + w - 4, y + 4, '#a7bda44a', 2); }
    g.dot(flag.x, flag.y, 15, '#162336', '#d1f5c6', 2);
    g.line(flag.x, flag.y, flag.x, flag.y - 64, '#efffe9', 3);
    g.poly([[flag.x, flag.y - 63], [flag.x + 37, flag.y - 53], [flag.x, flag.y - 42]], '#ffb77c', '#fff1bb');
    if (!moving) {
      const u = aiming ? unit(ball.x - g.pointer.x, ball.y - g.pointer.y) : { x: Math.cos(angle), y: Math.sin(angle) };
      const length = aiming ? Math.min(150, distance(ball, g.pointer) * 1.05) : power * 105;
      if (aiming) g.line(ball.x, ball.y, g.pointer.x, g.pointer.y, '#d7f7c89e', 2);
      for (let i = 0; i < 8; i++) g.dot(ball.x + u.x * (15 + length * i / 7), ball.y + u.y * (15 + length * i / 7), 3, '#f4fadb99');
    }
    g.dot(ball.x, ball.y, 10, '#faffef', '#364945');
    g.label('Hole ' + Math.min(holes, stage + 1) + ' / ' + holes, 23, 30); g.label('Strokes ' + shots, W - 23, 30, '#d1f1d6', 19, 'right');
  };
}

function hoops(g) {
  const totalTime = 46 + g.level * 2, goal = 7 + g.level * 2;
  const launch = { x: 143, y: 422 };
  let hoop = { x: 745, y: 250 }, attempts = 0, buckets = 0, shot, angle = -.78, charge = .64, held = false, next = .14, feedback = '', feedbackAt = 0;
  const radius = 12;
  function fire() {
    const v = 380 + charge * 690;
    attempts++; shot = { x: launch.x, y: launch.y, vx: Math.cos(angle) * v, vy: Math.sin(angle) * v, scored: false, t: 0 };
    g.beep(205, .10, 'triangle');
  }
  return dt => {
    if (!shot) {
      if (g.key('up')) angle -= dt * .85;
      if (g.key('down')) angle += dt * .85;
      if (g.pointer.active && !g.key('up') && !g.key('down') && g.pointer.x > launch.x + 55 && g.pointer.y < launch.y) angle = Math.atan2(g.pointer.y - launch.y, g.pointer.x - launch.x);
      angle = clamp(angle, -1.25, -.34);
      const pushing = g.key('space') || g.pointer.down;
      if (pushing && !held) charge = .25;
      if (pushing) charge = clamp(charge + dt * .65, .25, 1);
      if (g.time > next && ((held && !pushing) || (g.pressed('space') && !pushing) || g.pointer.tap && g.pointer.released || g.pressed('enter'))) fire();
      held = pushing;
    }
    if (shot) {
      shot.t += dt;
      const oldY = shot.y, oldX = shot.x;
      shot.vy += dt * 758; shot.x += shot.vx * dt; shot.y += shot.vy * dt;
      if (!shot.scored && oldY < hoop.y && shot.y >= hoop.y && Math.abs(hoop.x - shot.x) < 34 - g.level * 1.7) {
        shot.scored = true; buckets++; g.score += 130; feedback = 'SWISH'; feedbackAt = g.time; g.beep(630, .13);
      }
      if (shot.x > hoop.x + 48 && oldX < hoop.x + 48 && Math.abs(shot.y - hoop.y + 42) < 55) { shot.x = oldX; shot.vx *= -.64; }
      if (shot.y > H + 24 || shot.x > W + 25 || shot.t > 3.4) {
        if (shot.scored) {
          hoop.x = clamp(704 + g.rand(-98, 98), 604, 800);
          hoop.y = 254 + g.rand(-18, 58) + g.level * 3;
        }
        shot = undefined; next = g.time + .12;
      }
    }
    g.image('#13213c', '#22213b'); g.starlight(0);
    for (let x = 23; x < W; x += 38) g.line(x, 134, x, 475, '#a598d517', 1);
    g.box(0, 469, W, 71, '#3d2a46');
    g.line(0, 468, W, 468, '#9472ba', 3);
    g.line(hoop.x + 54, hoop.y - 71, hoop.x + 54, 469, '#62708b', 10);
    g.box(hoop.x + 42, hoop.y - 87, 12, 94, '#a9b9d4', 5, '#ded6ef');
    for (let x = -29; x <= 33; x += 13) {
      g.line(hoop.x + x, hoop.y + 1, hoop.x + x * .63, hoop.y + 42, '#d8cfeb', 2);
    }
    g.line(hoop.x - 40, hoop.y, hoop.x + 42, hoop.y, '#f79779', 7);
    if (!shot) {
      const v = 380 + charge * 690;
      for (let i = 1; i < 18; i++) {
        const t = i * .102, x = launch.x + Math.cos(angle) * v * t, y = launch.y + Math.sin(angle) * v * t + 379 * t * t;
        if (x > W || y > H) break;
        g.dot(x, y, 3.6, '#fef0d89f');
      }
    }
    const b = shot || launch;
    g.dot(b.x, b.y, radius, '#ec9962', '#ffce93', 2);
    g.line(b.x - 8, b.y, b.x + 8, b.y, '#793b44', 2); g.line(b.x, b.y - 9, b.x, b.y + 9, '#793b44', 2);
    g.label('Baskets ' + buckets + ' / ' + goal + '   •   Attempts ' + attempts, 24, 29);
    g.label(Math.max(0, Math.ceil(totalTime - g.time)) + 's', W - 24, 29, '#ebc4f7', 20, 'right');
    g.meter(24, 512, 204, charge, '#ffc393', 'Shot power');
    if (feedback && g.time - feedbackAt < .71) g.label(feedback, W / 2, 90, '#ffcda4', 29, 'center');
    if (dt && buckets >= goal) { g.score += 400; g.end('Court champion', buckets + ' baskets in ' + attempts + ' shots.', true); }
    else if (dt && g.time >= totalTime) g.end('Final buzzer', buckets + ' baskets in ' + attempts + ' shots.');
  };
}

function pong(g) {
  const needed = 7 + Math.floor(g.level / 2), top = 64, bottom = H - 31;
  let yours = H / 2, theirs = H / 2, a = 0, b = 0, ball, serve = 0;
  const size = 97 - g.level * 6;
  function reset(toward) {
    ball = { x: W / 2, y: (top + bottom) / 2, vx: toward * (270 + g.level * 27), vy: g.rand(-156, 156) };
    serve = g.time + 1.04;
  }
  reset(-1);
  return dt => {
    const m = g.move();
    yours = clamp(g.pointer.active && !m.y ? g.pointer.y : yours + m.y * dt * 420, top + size / 2, bottom - size / 2);
    const desire = ball.y + Math.sin(g.time * 2.7) * (35 - g.level * 5);
    theirs = clamp(theirs + clamp(desire - theirs, -dt * (180 + g.level * 32), dt * (180 + g.level * 32)), top + 47, bottom - 47);
    if (g.time >= serve) {
      const oldX = ball.x;
      ball.x += ball.vx * dt; ball.y += ball.vy * dt;
      if (ball.y < top + 10 || ball.y > bottom - 10) { ball.vy *= -1; ball.y = clamp(ball.y, top + 10, bottom - 10); }
      const left = ball.vx < 0 && oldX >= 58 && ball.x < 58 && Math.abs(ball.y - yours) < size / 2 + 8;
      const right = ball.vx > 0 && oldX <= W - 58 && ball.x > W - 58 && Math.abs(ball.y - theirs) < 55;
      if (left || right) {
        const zone = left ? (ball.y - yours) / (size / 2) : (ball.y - theirs) / 47;
        ball.vx = (left ? 1 : -1) * Math.min(775, Math.abs(ball.vx) * 1.10);
        ball.vy = zone * Math.abs(ball.vx) * .86;
        g.beep(left ? 442 : 328, .08, 'triangle', .048);
      }
      if (ball.x < -30) { b++; reset(-1); g.beep(125, .15); }
      if (ball.x > W + 30) { a++; g.score += 150; reset(1); g.beep(575, .15); }
    }
    g.image('#14243a', '#102431');
    g.box(19, top, W - 38, bottom - top, '#22516a', 10, '#6ac3db');
    for (let y = top + 9; y < bottom; y += 22) g.line(W / 2, y, W / 2, y + 10, '#c2edfa8a', 2);
    g.line(20, H / 2 + 16, W - 19, H / 2 + 16, '#9ad9e976', 2);
    g.box(35, yours - size / 2, 16, size, '#87e2f2', 6, '#defdff');
    g.box(W - 51, theirs - 47, 16, 94, '#e898b5', 6, '#fddeef');
    g.glow('#c6f3ff', 17, () => g.dot(ball.x, ball.y, 10, '#e8feff'));
    g.label('You  ' + a, 23, 31); g.label(b + '  CPU', W - 23, 31, '#ffbee2', 20, 'right');
    g.label('First to ' + needed, W / 2, 32, '#b7dfe7', 17, 'center');
    if (g.time < serve) g.label('Get ready', W / 2, 454, '#c8e7edcc', 17, 'center');
    if (dt && a >= needed) { g.score += 550; g.end('Match won', a + '–' + b + ' final score.', true); }
    else if (dt && b >= needed) g.end('Match complete', a + '–' + b + ' final score.');
  };
}

function ski(g) {
  const lineY = 428;
  const gates = [];
  let sequence = 0, nextGate = 2.9;
  function addGate() {
    const index = sequence++;
    gates.push({
      index,
      x: 478 + Math.sin(index * .74 + g.level * .72) * (189 + g.level * 14) + g.rand(-55, 55),
      width: Math.max(76, 137 - g.level * 12 - Math.floor(index / 12) * 3),
      at: nextGate, passed: false,
    });
    nextGate += Math.max(.84, 1.47 - g.level * .095 - index * .006);
  }
  for (let i = 0; i < 5; i++) addGate();
  const trees = Array.from({ length: 36 }, (_, i) => ({ x: i % 2 ? g.rand(35, 207) : g.rand(751, 926), y: g.rand(0, H), size: g.rand(10, 35) }));
  let x = W / 2, cleared = 0, misses = 0, tilt = 0, flash = 0;
  return dt => {
    const dir = Number(g.key('right')) - Number(g.key('left'));
    if (g.pointer.down) x += clamp(g.pointer.x - x, -dt * 410, dt * 410);
    else x += dir * dt * (326 + g.level * 9);
    x = clamp(x, 59, W - 59); tilt += (dir - tilt) * dt * 10;
    const speed = 202 + g.level * 35;
    while (nextGate < g.time + 5) addGate();
    while (gates[0]?.at < g.time - 1) gates.shift();
    g.image('#a4c4e6', '#d1ddf1');
    for (let i = 0; i < 11; i++) {
      const y = (i * 62 + g.time * speed * .66) % H;
      g.line(40, y, 925, y, '#83aac437', 2);
    }
    for (const t of trees) {
      const y = (t.y + g.time * speed) % (H + 55) - 20;
      g.poly([[t.x, y - t.size * 1.3], [t.x - t.size, y + t.size], [t.x + t.size, y + t.size]], '#428692', '#a0c9ca');
    }
    for (let i = 0; i < gates.length; i++) {
      const gate = gates[i], y = lineY - (gate.at - g.time) * speed;
      if (!gate.passed && g.time >= gate.at) {
        gate.passed = true;
        if (Math.abs(gate.x - x) <= gate.width / 2 - 4) { cleared++; g.score += 120; g.beep(460 + gate.index % 6 * 44, .08, 'triangle', .042); }
        else { misses++; flash = g.time + .31; g.beep(138, .12); }
      }
      if (y < -15 || y > H + 26) continue;
      const color = gate.index % 2 ? '#814ca5' : '#c25568';
      const [left, right] = [gate.x - gate.width / 2, gate.x + gate.width / 2];
      g.line(left, y, right, y, gate.passed ? '#6b9cac49' : '#f9fcfa', 3);
      for (const pos of [left, right]) {
        g.line(pos, y + 10, pos, y - 26, '#4d5c80', 4);
        g.poly([[pos, y - 25], [pos + (pos < gate.x ? -29 : 29), y - 16], [pos, y - 7]], color);
      }
    }
    g.ctx.save(); g.ctx.translate(x, lineY); g.ctx.rotate(tilt * .3);
    g.line(-10, -25, -10, 19, '#385984', 5); g.line(10, -25, 10, 19, '#385984', 5);
    g.dot(0, 0, 15, flash > g.time ? '#df8e9d' : '#3f65a6', '#f8feff', 2);
    g.dot(0, -10, 8, '#564680', '#eef2ff');
    g.ctx.restore();
    g.box(14, 11, 230, 46, '#213556ef', 8); g.box(W - 195, 11, 180, 46, '#213556ef', 8);
    g.label('Gates cleared ' + cleared, 27, 35, '#edf7ff');
    g.label('Misses ' + misses + '/5', W - 27, 36, '#ffe8ec', 19, 'right');
    if (misses >= 5) g.end('Run over', 'You cleared ' + cleared + ' gates.');
  };
}

function bowling(g) {
  const count = 6 + g.level, deckY = 173, rollY = 446, origin = { x: W / 2, y: rollY }, pins = [];
  let frames = 0, strokes = 0, ball, aim = W / 2, english = 0, power = 0, previous = 0, result = '', resultAt = 0;
  function rack() {
    pins.length = 0;
    for (let row = 0; row < 4; row++) for (let i = 0; i <= row; i++) {
      pins.push({ x: W / 2 + (i - row / 2) * 38 + g.level * Math.sin((row + 1) * 1.4) * 3, y: deckY - row * 24, down: false });
    }
  }
  rack();
  function roll() {
    if (ball || frames >= count) return;
    const strength = (1 + Math.sin(g.time * (3.7 + g.level * .43))) / 2;
    ball = { x: origin.x, y: rollY, aim, curve: english * (32 + 36 * strength), strength, t: 0 }; strokes++; power = strength;
    g.beep(153, .16, 'triangle');
  }
  return dt => {
    if (!ball) {
      aim = clamp(aim + (Number(g.key('right')) - Number(g.key('left'))) * dt * 225, 336, 625);
      if (g.key('up')) english = Math.min(1, english + dt * 1.44);
      if (g.key('down')) english = Math.max(-1, english - dt * 1.44);
      if (g.pointer.active && !g.key('left') && !g.key('right') && g.pointer.y < rollY) aim = clamp(g.pointer.x, 336, 625);
      if (g.action() || g.pointer.tap) roll();
    }
    if (ball) {
      ball.t += dt * (1.06 + ball.strength * .47);
      const t = clamp(ball.t, 0, 1.31);
      ball.x = mix(origin.x, ball.aim, t) + ball.curve * t * t; ball.y = mix(rollY, deckY - 16, t);
      if (dt) for (const p of pins) {
        const impact = 13 + ball.strength * 20;
        if (p.down || distance(p, ball) > impact) continue;
        p.down = true;
        const spread = 27 + ball.strength * 39;
        for (const other of pins) if (!other.down && other.y <= p.y && distance(other, p) < spread) other.down = true;
        g.beep(310 + Math.floor(ball.x % 9) * 50, .066, 'triangle', .044);
      }
      if (ball.t > 1.35) {
        const down = pins.filter(p => p.down).length;
        g.score += (down - previous) * 20;
        resultAt = g.time; result = (down - previous) + ' pins';
        if (strokes === 1 && down === 10) { g.score += 125; result = 'STRIKE'; }
        if (strokes === 2 && down === 10) { g.score += 60; result = 'SPARE'; }
        if (down === 10 || strokes >= 2) { frames++; strokes = 0; previous = 0; rack(); }
        else previous = down;
        ball = undefined;
      }
    }
    g.image('#151c36', '#261b3d');
    g.starlight(2);
    g.poly([[306, 84], [651, 84], [877, H], [76, H]], '#644a6a', '#b974b0', 4);
    g.poly([[326, 86], [631, 86], [816, H], [137, H]], '#947292', '#d69db6', 2);
    for (let i = 1; i < 11; i++) g.line(326 + i * 305 / 11, 88, 137 + i * 679 / 11, H, '#ccadc080', 2);
    g.line(157, 514, 803, 514, '#f4aee0', 3);
    for (const p of pins) {
      if (p.down) {
        g.box(p.x - 12, p.y + 2, 26, 9, '#dfbad9', 4, '#ab79b2');
      } else {
        g.box(p.x - 8, p.y - 17, 16, 29, '#f2e8f9', 7, '#decbf6');
        g.line(p.x - 6, p.y - 7, p.x + 6, p.y - 7, '#db688f', 3);
      }
    }
    const spot = ball || origin;
    if (!ball) {
      g.line(spot.x, spot.y + 4, aim, deckY - 16, '#f5deff66', 2);
      g.dot(aim, deckY - 16, 9, '#281d4777', '#e5b2fe', 2);
    }
    g.glow('#ce75ed', 15, () => g.dot(spot.x, spot.y, 17, '#894bad', '#e5b4e5', 2));
    for (let i = 0; i < 3; i++) g.dot(spot.x + i * 4 - 4, spot.y - 4 + i % 2 * 5, 2.2, '#432d61');
    g.label('Frame ' + Math.min(count, frames + 1) + ' / ' + count, 23, 28);
    g.label('Roll ' + Math.min(2, strokes + Number(!ball)) + ' / 2', W - 24, 28, '#f4d0f5', 19, 'right');
    g.meter(25, 496, 146, ball ? power : (1 + Math.sin(g.time * (3.7 + g.level * .43))) / 2, '#fa9bdc', 'Release power');
    if (result && g.time - resultAt < .8) g.label(result, W / 2, 50, '#ffcef3', 26, 'center');
    if (dt && frames >= count) g.end('Game complete', count + ' frames played.', true);
  };
}

export const sports = {
  penalty: mode('Move the aim with the arrows or pointer. Tap the goal or press Space as the timing bar reaches the marker.', penalty, ['left', 'up', 'down', 'right'], [['space', 'Kick']]),
  golf: mode('Press near the ball, pull back, and release. Or ← / → aim, ↑ / ↓ change power, Space putts.', minigolf),
  hoops: mode('Aim with ↑ / ↓ or your pointer. Hold Space or press the field to charge, then release to shoot.', hoops, vertical, [['space', 'Shoot']]),
  pong: mode('Move your pointer or use ↑ / ↓ to rally against the CPU.', pong, vertical),
  ski: mode('Hold ← / → or drag to steer through the slalom gates.', ski, horizontal),
  bowl: mode('Aim with ← / → or pointer. ↑ / ↓ set spin. Space or tap releases at the current power.', bowling, horizontal, [['space', 'Roll']]),
};
