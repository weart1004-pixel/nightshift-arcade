export const W = 960;
export const H = 540;
export const TAU = Math.PI * 2;
export const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));
export const mix = (from, to, weight) => from + (to - from) * weight;
export const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
export const unit = (x, y) => {
  const length = Math.hypot(x, y) || 1;
  return { x: x / length, y: y / length };
};
export const inRect = (p, x, y, w, h) => p.x >= x && p.x <= x + w && p.y >= y && p.y <= y + h;
export const rectsOverlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

export function seedFrom(text) {
  let hash = 2166136261;
  for (const char of text) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
  return hash >>> 0;
}

export function seeded(seed) {
  return () => {
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), seed | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const aliases = { a: 'left', d: 'right', w: 'up', s: 'down', arrowleft: 'left', arrowright: 'right', arrowup: 'up', arrowdown: 'down', ' ': 'space' };
const normalize = key => aliases[key.toLowerCase()] || key.toLowerCase();
const handled = new Set(['left', 'right', 'up', 'down', 'space', 'shift', 'enter', 'backspace', 'p', ...'1234567890qerfzxjkl']);

export function newInput(canvas, controls, onPause) {
  const down = new Set();
  const tappedKeys = new Set();
  const letters = [];
  const pointer = { x: W / 2, y: H / 2, startX: W / 2, startY: H / 2, active: false, down: false, tap: false, released: false };
  const events = new AbortController();
  const { signal } = events;
  let enabled = false;
  let pointerId;

  function press(key) {
    if (!down.has(key)) tappedKeys.add(key);
    down.add(key);
  }
  function updatePointer(event) {
    const bounds = canvas.getBoundingClientRect();
    pointer.active = true;
    pointer.x = (event.clientX - bounds.left) * W / bounds.width;
    pointer.y = (event.clientY - bounds.top) * H / bounds.height;
  }
  function clearKeys() {
    down.clear();
    tappedKeys.clear();
    letters.length = 0;
    pointer.down = pointer.tap = pointer.released = false;
    pointerId = undefined;
  }
  function clearFrame() {
    tappedKeys.clear();
    letters.length = 0;
    pointer.tap = pointer.released = false;
  }

  window.addEventListener('keydown', event => {
    if (!enabled || event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.target instanceof HTMLButtonElement && [' ', 'Enter'].includes(event.key)) return;
    const key = normalize(event.key);
    const printable = /^[a-z0-9]$/i.test(event.key) || event.key === 'Backspace';
    if (controls.typing && printable) {
      event.preventDefault();
      if (!event.repeat) letters.push(event.key.toLowerCase());
      return;
    }
    if (handled.has(key)) event.preventDefault();
    if (key === 'p') {
      if (!event.repeat) onPause();
      return;
    }
    press(key);
  }, { signal });
  window.addEventListener('keyup', event => down.delete(normalize(event.key)), { signal });
  window.addEventListener('blur', clearKeys, { signal });
  canvas.addEventListener('pointermove', event => {
    if (enabled && (pointerId === undefined || pointerId === event.pointerId)) updatePointer(event);
  }, { signal });
  canvas.addEventListener('pointerdown', event => {
    if (!enabled || pointerId !== undefined) return;
    event.preventDefault();
    pointerId = event.pointerId;
    canvas.focus({ preventScroll: true });
    canvas.setPointerCapture?.(event.pointerId);
    updatePointer(event);
    pointer.startX = pointer.x;
    pointer.startY = pointer.y;
    pointer.down = pointer.tap = true;
  }, { signal });
  for (const name of ['pointerup', 'pointercancel']) {
    canvas.addEventListener(name, event => {
      if (!enabled || event.pointerId !== pointerId) return;
      updatePointer(event);
      pointerId = undefined;
      pointer.down = false;
      pointer.released = name === 'pointerup';
    }, { signal });
  }

  return {
    down, tappedKeys, letters, pointer, clearFrame, clearKeys,
    setEnabled(value) { enabled = value; clearKeys(); pointer.active = false; },
    setButton(key, value) {
      if (enabled && value) press(key);
      else down.delete(key);
    },
    dispose() { events.abort(); clearKeys(); },
  };
}

// Draw each mode's illustration behind the playfield. Fade the center so
// silhouettes, targets and puzzle tiles remain readable over the scenery.
function stageArt(url) {
  const art = document.createElement('canvas');
  art.width = W;
  art.height = H;
  const source = new Image();
  let ready = false;
  source.onload = () => {
    const ctx = art.getContext('2d');
    const scale = Math.max(W / source.naturalWidth, H / source.naturalHeight);
    const w = source.naturalWidth * scale, h = source.naturalHeight * scale;
    ctx.drawImage(source, (W - w) / 2, (H - h) / 2, w, h);
    const mask = ctx.createRadialGradient(W / 2, H / 2, H * .12, W / 2, H / 2, W * .58);
    mask.addColorStop(0, 'rgba(0,0,0,.12)');
    mask.addColorStop(.70, 'rgba(0,0,0,.30)');
    mask.addColorStop(1, 'rgba(0,0,0,.50)');
    ctx.globalCompositeOperation = 'destination-in';
    ctx.fillStyle = mask;
    ctx.fillRect(0, 0, W, H);
    ready = true;
  };
  source.src = url;
  return ctx => { if (ready) ctx.drawImage(art, 0, 0, W, H); };
}

export function painter(ctx, drawBackdrop) {
  const image = (top, bottom) => {
    const color = ctx.createLinearGradient(0, 0, 0, H);
    color.addColorStop(0, top);
    color.addColorStop(1, bottom);
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, W, H);
    drawBackdrop?.(ctx);
  };
  const box = (x, y, w, h, fill, radius = 0, stroke) => {
    if (!radius && !stroke) {
      ctx.fillStyle = fill;
      ctx.fillRect(x, y, w, h);
      return;
    }
    ctx.beginPath();
    if (radius) ctx.roundRect(x, y, w, h, radius);
    else ctx.rect(x, y, w, h);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.lineWidth = 2; ctx.strokeStyle = stroke; ctx.stroke(); }
  };
  const dot = (x, y, radius, fill, stroke, width = 2) => {
    ctx.beginPath();
    ctx.arc(x, y, Math.max(0, radius), 0, TAU);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.lineWidth = width; ctx.strokeStyle = stroke; ctx.stroke(); }
  };
  const line = (x, y, tx, ty, color, width = 1) => {
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(tx, ty);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.stroke();
  };
  const poly = (points, fill, stroke, width = 2) => {
    ctx.beginPath();
    points.forEach(([x, y], index) => index ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.lineWidth = width; ctx.strokeStyle = stroke; ctx.stroke(); }
  };
  const label = (text, x, y, color = '#f5edff', size = 21, align = 'left', weight = 700, mono = false) => {
    ctx.font = `${weight} ${size}px ${mono ? 'monospace' : 'Roboto, system-ui, sans-serif'}`;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillStyle = color;
    ctx.fillText(text, x, y);
  };
  const glow = (color, blur, callback) => {
    ctx.save();
    ctx.shadowColor = color;
    ctx.shadowBlur = blur;
    callback();
    ctx.restore();
  };
  const meter = (x, y, width, amount, color, labelText) => {
    box(x, y, width, 8, '#ffffff22', 4);
    const filled = width * clamp(amount, 0, 1);
    if (filled > 1) box(x, y, filled, 8, color, 4);
    if (labelText) label(labelText, x, y - 13, '#d8cdeb', 15);
  };
  const grid = (size = 32, color = '#b998ff16', ox = 0, oy = 0) => {
    for (let x = (ox % size + size) % size; x < W; x += size) line(x, 0, x, H, color);
    for (let y = (oy % size + size) % size; y < H; y += size) line(0, y, W, y, color);
  };
  const button = (x, y, width, height, title, subtitle, pointer, active = true, tint = '#a785ff') => {
    const hover = active && inRect(pointer, x, y, width, height);
    box(x, y, width, height, hover ? '#3e305a' : '#211a35', 9, active ? (hover ? tint : '#594574') : '#383143');
    label(title, x + 14, y + (subtitle ? height * .34 : height * .5), active ? '#f5edff' : '#9b91a6', 19);
    if (subtitle) label(subtitle, x + 14, y + height * .72, active ? tint : '#8d8399', 14);
    return hover && pointer.tap;
  };
  return { ctx, image, box, dot, line, poly, label, glow, meter, grid, button };
}

export function createScene(canvas, game, input, sound, onEnd) {
  const draw = painter(canvas.getContext('2d'), stageArt(game.image));
  const random = seeded(seedFrom(game.id));
  const pressed = key => input.tappedKeys.has(key);
  const key = name => input.down.has(name);
  const pointer = input.pointer;
  const result = {
    ...draw,
    level: game.level, game, time: 0, score: 0, random,
    rand: (from, to) => from + (to - from) * random(),
    pick: array => array[Math.floor(random() * array.length)],
    key, pressed, pointer, letters: input.letters,
    action: () => pressed('space') || pressed('enter'),
    move: () => unit(Number(key('right')) - Number(key('left')), Number(key('down')) - Number(key('up'))),
    hitBox: (x, y, w, h) => pointer.tap && inRect(pointer, x, y, w, h),
    beep: sound,
    end(title, message, won = false) { onEnd(title, message, won); },
  };
  result.stars = Array.from({ length: 91 }, (_, index) => ({
    x: (index * 193.57 + 17) % W,
    y: (index * 87.41 + 31) % H,
    r: .55 + index % 5 * .28,
  }));
  result.starlight = (speed = 0, tint = '#9eb1ee') => {
    for (const star of result.stars) {
      const y = (star.y + result.time * speed * star.r) % H;
      draw.dot(star.x, y, star.r, tint + (star.r > 1.3 ? 'ba' : '59'));
    }
  };
  return result;
}

export function makeMaze(columns, rows, random) {
  const cells = Array.from({ length: rows }, () => Array(columns).fill(1));
  const stack = [[1, 1]];
  cells[1][1] = 0;
  while (stack.length) {
    const [x, y] = stack.at(-1);
    const options = [[2, 0], [-2, 0], [0, 2], [0, -2]].filter(([dx, dy]) =>
      x + dx > 0 && x + dx < columns - 1 && y + dy > 0 && y + dy < rows - 1 && cells[y + dy][x + dx]);
    if (!options.length) { stack.pop(); continue; }
    const [dx, dy] = options[Math.floor(random() * options.length)];
    cells[y + dy / 2][x + dx / 2] = 0;
    cells[y + dy][x + dx] = 0;
    stack.push([x + dx, y + dy]);
  }
  return cells;
}

export function routeStep(grid, start, target) {
  if (start.x === target.x && start.y === target.y) return null;
  const queue = [start];
  const seen = new Set([`${start.x},${start.y}`]);
  for (let i = 0; i < queue.length; i++) {
    const node = queue[i];
    for (const [dx, dy] of [[0, -1], [1, 0], [0, 1], [-1, 0]]) {
      const x = node.x + dx, y = node.y + dy;
      const id = `${x},${y}`;
      if (grid[y]?.[x] !== 0 || seen.has(id)) continue;
      const first = node.first || { x, y };
      if (x === target.x && y === target.y) return first;
      seen.add(id);
      queue.push({ x, y, first });
    }
  }
  return null;
}

export function drawShip(g, x, y, heading, color, scale = 1) {
  g.ctx.save();
  g.ctx.translate(x, y);
  g.ctx.rotate(heading);
  g.ctx.scale(scale, scale);
  g.poly([[19, 0], [-14, -13], [-9, 0], [-14, 13]], color, '#ffffffb3', 1.5);
  g.poly([[9, 0], [-9, -4], [-9, 4]], '#151c3c');
  g.ctx.restore();
}

export function wrap(point, padding = 15) {
  if (point.x < -padding) point.x = W + padding;
  if (point.x > W + padding) point.x = -padding;
  if (point.y < -padding) point.y = H + padding;
  if (point.y > H + padding) point.y = -padding;
}
