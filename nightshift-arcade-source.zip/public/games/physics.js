import { W, H, TAU, clamp, mix, distance, inRect, unit } from './engine.js';
import { mode, horizontal, vertical } from './controls.js';

function cannon(g) {
  const origin = { x: 117, y: 417 }, floor = 469;
  const target = { x: 590 + g.random() * 220, size: 110 - 8 * g.level };
  const bumps = Array.from({ length: 2 + Math.floor(g.level / 2) }, (_, i) => ({
    x: 318 + i * 84, y: g.rand(325, 418), w: 36 + g.level * 3, struck: false,
  }));
  let angle = -.73, power = .55, charge = false, shots = 7, dummy = null, best = 0;
  function fire() {
    if (dummy || shots <= 0) return;
    shots--;
    const speed = 355 + power * 760;
    dummy = {
      x: origin.x + Math.cos(angle) * 64, y: origin.y + Math.sin(angle) * 64,
      vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, rotation: 0, time: 0,
    };
    g.beep(114, .22, 'triangle');
  }
  return dt => {
    if (!dummy) {
      if (g.key('up')) angle -= dt * .8;
      if (g.key('down')) angle += dt * .8;
      if (g.pointer.active && !g.key('up') && !g.key('down') && g.pointer.x > origin.x + 25 && g.pointer.y < floor) angle = Math.atan2(g.pointer.y - origin.y, g.pointer.x - origin.x);
      angle = clamp(angle, -1.36, -.12);
      const held = g.key('space') || g.pointer.down;
      if (held && !charge) power = .28;
      if (held) power = clamp(power + dt * .63, .28, 1);
      if ((charge && !held) || (g.pressed('space') && !held) || (g.pointer.tap && g.pointer.released) || g.pressed('enter')) {
        bumps.forEach(block => { block.struck = false; });
        fire();
      }
      charge = held;
    }
    if (dummy) {
      const d = dummy;
      d.time += dt;
      d.vy += 670 * dt;
      d.x += d.vx * dt;
      d.y += d.vy * dt;
      d.rotation += dt * (4 + d.vx * .008);
      for (const b of bumps) if (!b.struck && inRect(d, b.x - 10, b.y - 10, b.w + 20, floor - b.y + 10)) {
        b.struck = true; d.vy = -Math.abs(d.vy) * .52 - 95; d.vx *= .73;
      }
      if (dt && (d.y >= floor - 12 || d.x > W + 80 || d.time > 5)) {
        const error = Math.abs(d.x - target.x);
        best = Math.max(best, Math.max(0, 340 - error));
        g.score = best;
        dummy = null;
        if (error < target.size / 2) { g.score += 500 + shots * 60; g.end('Right on target', `Landing error ${Math.round(error)} pixels.`, true); }
        else if (shots <= 0) g.end('All shots used', 'Try a lower charge if the dummy overshoots the pad.');
      }
    }
    g.image('#1f1c39', '#38223c');
    g.grid(42, '#c79afe15');
    g.box(0, floor, W, H - floor, '#1a1629');
    g.line(0, floor, W, floor, '#8a688b', 3);
    g.box(target.x - target.size / 2, floor - 12, target.size, 15, '#348979', 4, '#9effce');
    g.label('LAND HERE', target.x, floor + 22, '#a4ffd9', 15, 'center');
    for (const b of bumps) g.box(b.x, b.y, b.w, floor - b.y, b.struck ? '#62556a' : '#795643', 4, '#c08975');
    if (!dummy) {
      const v = 355 + power * 760;
      for (let i = 1; i < 25; i++) {
        const t = i * .082;
        const x = origin.x + (v * t + 64) * Math.cos(angle);
        const y = origin.y + (v * t + 64) * Math.sin(angle) + 335 * t * t;
        if (x > W || y > floor) break;
        g.dot(x, y, 3 - i * .075, '#ffe0a989');
      }
    }
    g.dot(origin.x, origin.y + 29, 25, '#272637', '#df9c7e', 5);
    g.line(origin.x, origin.y, origin.x + 64 * Math.cos(angle), origin.y + 64 * Math.sin(angle), '#f2a166', 29);
    if (dummy) {
      const d = dummy;
      g.ctx.save(); g.ctx.translate(d.x, d.y); g.ctx.rotate(d.rotation);
      g.line(0, -10, 0, 15, '#ffb664', 8);
      g.line(-14, -9 + Math.sin(d.time * 16) * 8, 14, 1, '#ef9868', 6);
      g.line(0, 15, -9, 28, '#ef9868', 6);
      g.line(0, 15, 9, 25 + Math.sin(d.time * 15) * 5, '#ef9868', 6);
      g.dot(0, -20, 9, '#ffce8a', '#f5ebc5');
      g.ctx.restore();
    }
    g.label(`Shots left ${shots}`, 25, 29);
    g.meter(712, 39, 220, power, '#ffa878', 'Launch charge');
  };
}

function bridge(g) {
  const span = 5 + Math.floor(g.level / 2), left = 175, right = 785, deck = 287;
  const width = (right - left) / span;
  const top = deck - 87 - g.level * 4;
  const points = Array.from({ length: span + 1 }, (_, i) => ({ x: left + width * i, y: deck, i, fixed: !i || i === span }))
    .concat(Array.from({ length: span }, (_, i) => ({ x: left + width * (i + .5), y: top, i: span + 1 + i })));
  const beams = new Map();
  let select = null, trial = null, delivered = 0, used = 0, failure = '';
  const budget = span * 4;
  const key = (a, b) => [Math.min(a, b), Math.max(a, b)].join(':');

  function test() {
    select = null;
    trial = { x: 130, y: deck - 18, fall: 0 };
    failure = '';
  }
  function roadIsSolid(section) {
    const a = points[section], b = points[section + 1], c = points[span + 1 + section];
    const exists = (u, v) => beams.has(key(u.i, v.i));
    if (!exists(a, b)) return false;
    if (g.level === 0) return section === 0 || section === span - 1 || (exists(a, c) || exists(b, c));
    return exists(a, c) && exists(c, b);
  }
  return dt => {
    if ((g.action() || g.hitBox(778, 30, 150, 54)) && !trial) test();
    if (g.pointer.tap && !trial) {
      const point = points.find(p => distance(p, g.pointer) < 28);
      if (point) {
        if (select && select !== point && distance(point, select) < width * 1.62) {
          const id = key(point.i, select.i);
          if (beams.has(id)) { beams.delete(id); used--; }
          else if (used < budget) { beams.set(id, [point, select]); used++; g.beep(310); }
          select = null;
        } else select = point === select ? null : point;
      }
    }
    if (trial) {
      const section = Math.floor((trial.x - left) / width);
      if (section >= 0 && section < span && !roadIsSolid(section) && !trial.fall) {
        trial.fall = 1;
        failure = `Support span ${section + 1} with a road beam and diagonal braces.`;
        g.beep(122, .22, 'triangle');
      }
      trial.fall += trial.fall ? dt * 420 : 0;
      trial.y += trial.fall * dt;
      trial.x += dt * (trial.fall ? 50 : 165);
      if (trial.y > H) trial = null;
      else if (trial.x > 852) { delivered = 1; g.score = 1200 + (budget - used) * 50; g.end('Bridge held', `The truck crossed using ${used} beams.`, true); }
    }
    g.image('#171f3a', '#3a2238');
    g.poly([[0, 201], [122, 250], [left, deck], [left, H], [0, H]], '#56423b', '#a87969');
    g.poly([[W, 207], [834, 246], [right, deck], [right, H], [W, H]], '#56423b', '#a87969');
    g.box(left, H - 83, right - left, 83, '#235276');
    for (let i = 0; i < 12; i++) g.line(left + i * 50, H - 35 - i % 3 * 11, left + i * 50 + 30, H - 35 - i % 3 * 11, '#6d9eba', 2);
    for (const [a, b] of beams.values()) {
      const road = a.y === deck && b.y === deck;
      g.line(a.x, a.y, b.x, b.y, road ? '#c78f5d' : '#8c647d', road ? 12 : 8);
      g.line(a.x, a.y - 3, b.x, b.y - 3, road ? '#fed99e' : '#fad2ac', 2);
    }
    if (select) g.line(select.x, select.y, g.pointer.x, g.pointer.y, '#e0b0ff77', 3);
    for (const p of points) {
      g.dot(p.x, p.y, p === select ? 14 : 11, p.fixed ? '#7be9bf' : '#503d58', p === select ? '#ffeb96' : '#f3c2cf');
      g.dot(p.x, p.y, 3, '#fff1ea');
    }
    const tx = trial?.x ?? 119, ty = trial?.y ?? deck - 18;
    g.box(tx - 16, ty - 13, 32, 23, '#db785b', 4, '#ffc9a6');
    g.box(tx - 14, ty - 18, 17, 14, '#e3a55f', 4);
    g.dot(tx - 9, ty + 10, 7, '#2b2941', '#a4a6bf');
    g.dot(tx + 12, ty + 10, 7, '#2b2941', '#a4a6bf');
    g.label(`Beams ${used} / ${budget}`, 28, 29);
    g.label(failure || 'Connect the road in a row. Use the top points for braces.', 28, 62, '#ffd9ba', 17);
    g.button(778, 30, 150, 54, 'Test bridge', 'Space / tap', g.pointer, !trial);
    if (!delivered) g.score = Math.max(g.score, Math.min(span, Math.floor(((trial?.x || left) - left) / width)) * 60);
  };
}

function grapple(g) {
  const total = 2380 + g.level * 330;
  const platform = 434;
  const anchors = Array.from({ length: Math.ceil(total / 162) }, (_, i) => (
    { x: 181 + i * 168 + g.rand(-15, 15), y: g.rand(104, 182) }
  ));
  const p = { x: 88, y: platform - 19, vx: 90, vy: 0 };
  let hook, rope, start = true, peak = 0;
  return dt => {
    const hold = g.key('space') || g.pointer.down;
    if (hold && !hook) {
      const candidates = anchors.filter(a => distance(p, a) < 362 && a.x > p.x - 32 && a.y < p.y - 19);
      if (candidates.length) {
        hook = candidates.at(-1);
        rope = clamp(distance(p, hook) * .81, 103, 290);
        p.vy -= 146;
        p.vx = Math.max(p.vx, 152);
        start = false;
        g.beep(473, .07, 'triangle');
      }
    }
    if (!hold && hook) { hook = null; p.vy -= 65; }
    if (g.key('left')) p.vx -= dt * 235;
    if (g.key('right')) p.vx += dt * 265;
    p.vx = clamp(p.vx + dt * (start ? 14 : 28), -330, 470);
    p.vy += dt * 555;
    p.x = Math.max(30, p.x + p.vx * dt);
    p.y += p.vy * dt;
    if (hook) {
      const dx = p.x - hook.x, dy = p.y - hook.y;
      const d = Math.hypot(dx, dy);
      if (d > rope) {
        const u = unit(dx, dy);
        const velocity = p.vx * u.x + p.vy * u.y;
        p.x = hook.x + u.x * rope; p.y = hook.y + u.y * rope;
        if (velocity > 0) { p.vx -= u.x * velocity; p.vy -= u.y * velocity; }
      }
    }
    if ((p.x < 217 || p.x > total - 35) && p.y >= platform - 14 && p.y < platform + 22 && p.vy > 0) {
      p.y = platform - 14; p.vy = 0;
    }
    peak = Math.max(peak, p.x); g.score = peak / 2;
    const offset = Math.max(0, p.x - 252);
    g.image('#172745', '#352b58');
    g.starlight(1);
    for (let i = 0; i < 21; i++) {
      const x = ((i * 90 - offset * .27) % 1890 + 1890) % 1890 - 151;
      const h = 75 + i * 29 % 146;
      g.box(x, H - h, 67, h, '#312848', 4);
      g.line(x + 16, H - h + 21, x + 51, H - h + 21, '#f3ad7a75', 2);
    }
    for (const a of anchors) {
      const x = a.x - offset;
      if (x < -14 || x > W + 14) continue;
      g.line(x, a.y, x, 0, '#a78ce253', 3);
      g.glow('#bb91ff', 10, () => g.dot(x, a.y, 9, a === hook ? '#ffe798' : '#ae7deb', '#f1e6ff'));
    }
    g.box(-offset, platform, 217, H - platform, '#3a3553', 5, '#b689d4');
    g.box(total - offset - 35, platform, 190, H - platform, '#30625f', 5, '#89f3c6');
    if (hook) g.line(hook.x - offset, hook.y, p.x - offset, p.y, '#d4bcff', 3);
    g.dot(p.x - offset, p.y, 15, '#cf75fe', '#ffe5ff', 3);
    g.line(p.x - offset - 6, p.y - 3, p.x - offset + 6, p.y - 3, '#2a1732', 4);
    g.label('Reach the far roof', 23, 27);
    g.meter(710, 37, 225, p.x / total, '#b889f9', `Distance ${Math.min(100, Math.round(p.x / total * 100))}%`);
    if (dt && p.y > H + 45) g.end('Swing interrupted', 'Hold the hook to build momentum, then release as you swing forward.');
    if (dt && p.x >= total && p.y < platform + 10) { g.score += 400; g.end('Roof reached', 'You made it across the skyline.', true); }
  };
}

const fruitColors = ['#ff7d8d', '#ffb758', '#fedf6e', '#7be1a2', '#68ccf0', '#ad81e8', '#83d948'];
const radius = tier => 13 + tier * 6.7;
function merge(g) {
  const left = 253, right = 707, top = 119, bottom = 497;
  const fruit = [];
  const goal = 5 + Number(g.level >= 3);
  let upcoming = 0, x = W / 2, cooldown = 0, danger = 0, biggest = 0;
  function drop() {
    if (cooldown > 0) return;
    fruit.push({ x, y: 76, vy: 0, vx: 0, tier: upcoming, age: 0 });
    upcoming = Math.floor(g.rand(0, g.level > 2 ? 2.4 : 1.8));
    cooldown = .43;
  }
  return dt => {
    cooldown = Math.max(0, cooldown - dt);
    const steering = Number(g.key('right')) - Number(g.key('left'));
    x += steering * dt * 278;
    if (!steering && g.pointer.active && inRect(g.pointer, left - 36, 36, right - left + 72, H - 36)) x = g.pointer.x;
    x = clamp(x, left + radius(upcoming), right - radius(upcoming));
    if (g.action() || g.pointer.tap) drop();

    for (const f of fruit) {
      const r = radius(f.tier);
      f.age += dt; f.vy += dt * 674;
      f.x += f.vx * dt; f.y += f.vy * dt;
      if (f.x < left + r || f.x > right - r) { f.x = clamp(f.x, left + r, right - r); f.vx *= -.22; }
      if (f.y > bottom - r) { f.y = bottom - r; f.vy *= -.15; f.vx *= .9; }
    }
    for (let step = 0; step < 3 && dt; step++) for (let i = 0; i < fruit.length; i++) for (let j = fruit.length - 1; j > i; j--) {
      const a = fruit[i], b = fruit[j], sum = radius(a.tier) + radius(b.tier), d = distance(a, b);
      if (d >= sum) continue;
      if (a.tier === b.tier && a.tier < fruitColors.length - 1 && a.age > .14 && b.age > .14) {
        a.x = (a.x + b.x) / 2; a.y = (a.y + b.y) / 2; a.vx = (a.vx + b.vx) * .4; a.vy = (a.vy + b.vy) * .45;
        a.tier++; a.age = 0; biggest = Math.max(biggest, a.tier);
        fruit.splice(j, 1); g.score += (a.tier + 1) * 90;
        g.beep(275 + a.tier * 104, .15, 'triangle');
        continue;
      }
      const m = d < .001 ? { x: 0, y: -1 } : unit(b.x - a.x, b.y - a.y);
      const push = (sum - d) * .52;
      a.x -= m.x * push; b.x += m.x * push; a.y -= m.y * push; b.y += m.y * push;
      const relative = (a.vx - b.vx) * m.x + (a.vy - b.vy) * m.y;
      if (relative > 0) { a.vx -= m.x * relative * .52; a.vy -= m.y * relative * .52; b.vx += m.x * relative * .52; b.vy += m.y * relative * .52; }
    }
    danger = fruit.some(f => f.age > 1.1 && f.y - radius(f.tier) < top && Math.abs(f.vy) < 160) ? danger + dt : Math.max(0, danger - dt * 2);
    g.image('#231438', '#3b2347');
    g.grid(40, '#e3a9e816');
    g.box(left, top, right - left, bottom - top, '#25192f', 9, '#c28eaf');
    g.line(left, top, right, top, danger > .1 ? '#ff546c' : '#c0788a', 2);
    g.line(x, 95, x, bottom, '#e9ccdf48', 2);
    [...fruit, { x, y: 76, tier: upcoming }].forEach(f => {
      const r = radius(f.tier);
      g.dot(f.x, f.y, r, fruitColors[f.tier], '#fff4e7');
      g.dot(f.x - r * .26, f.y - r * .30, r * .26, '#ffffff49');
      if (f.tier >= 4) g.line(f.x, f.y - r + 1, f.x + 9, f.y - r - 7, '#82ef9f', 4);
      g.dot(f.x - r * .25, f.y + 3, 2, '#4d2344');
      g.dot(f.x + r * .25, f.y + 3, 2, '#4d2344');
    });
    g.label('Fruit merger', 22, 26);
    g.label(`Largest ${biggest + 1} / ${goal + 1}`, W - 23, 26, '#fbe2f3', 19, 'right');
    if (danger > 1.75) g.end('The bin overflowed', 'Drop matching fruits near each other to combine them.');
    else if (biggest >= goal) { g.score += 600; g.end('Orchard champion', 'You grew the biggest fruit on the board.', true); }
  };
}

function sand(g) {
  const cols = 132, rows = 65, side = 6.5, ox = 51, oy = 73;
  const cells = new Uint8Array(cols * rows);
  const color = ['#121421', '#deb873', '#529fdb', '#8a809e', '#76b683'];
  const names = ['1 Sand', '2 Water', '3 Wall', '4 Seed', '5 Erase'];
  const idx = (x, y) => y * cols + x;
  let brush = 1, accumulator = 0;
  const gridTop = rows - 1;
  for (let x = 0; x < cols; x++) cells[idx(x, gridTop)] = 3;
  for (let i = 0; i < 3 + g.level; i++) {
    const x = Math.floor(g.rand(6, cols - 24)), y = Math.floor(g.rand(15, rows - 5));
    for (let n = 0; n < 15; n++) cells[idx(x + n, y)] = 3;
  }
  function step() {
    const scanLeft = g.random() > .5;
    for (let y = rows - 2; y > 0; y--) for (let n = 1; n < cols - 1; n++) {
      const dir = g.random() > .5 ? 1 : -1;
      const x = scanLeft ? n : cols - n - 1;
      const at = idx(x, y), value = cells[at];
      if (!value || value === 3) continue;
      if (value === 4) {
        if (cells[at + cols] === 2 && g.random() < .026) {
          cells[at + cols] = 4;
          if (!cells[at - cols]) cells[at - cols] = 4;
        }
        continue;
      }
      const options = value === 1 ? [cols, cols + dir, cols - dir] : [cols, cols + dir, dir, -dir];
      const offset = options.find(move => !cells[at + move] || value === 1 && cells[at + move] === 2);
      if (offset !== undefined) { cells[at] = cells[at + offset]; cells[at + offset] = value; }
    }
  }
  return dt => {
    for (let i = 1; i <= 5; i++) if (g.pressed(String(i))) brush = i;
    if (g.pressed('r') || g.hitBox(786, 17, 123, 41)) cells.fill(0, 0, cols * (rows - 1));
    if (g.pointer.down && inRect(g.pointer, ox, oy, cols * side, rows * side - side)) {
      const x = Math.floor((g.pointer.x - ox) / side), y = Math.floor((g.pointer.y - oy) / side);
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        if (x + dx < 1 || x + dx >= cols - 1 || y + dy < 1 || y + dy >= rows - 1 || dx * dx + dy * dy > 5) continue;
        const at = idx(x + dx, y + dy);
        if (brush >= 3 || !cells[at]) cells[at] = brush === 5 ? 0 : brush;
      }
    }
    accumulator += dt;
    if (accumulator > .028) { step(); accumulator -= .028; }
    g.image('#1f172a', '#0e1526');
    g.box(ox - 3, oy - 3, cols * side + 6, rows * side + 6, '#101320', 6, '#645587');
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const cell = cells[idx(x, y)];
      if (cell) g.box(ox + x * side, oy + y * side, side + .25, side + .25, color[cell]);
    }
    names.forEach((name, i) => {
      if (g.button(ox + i * 134, 17, 121, 41, name, null, g.pointer, true, color[i + 1] || '#eec9ea')) brush = i + 1;
      if (brush === i + 1) g.line(ox + i * 134 + 2, 59, ox + i * 134 + 119, 59, color[i + 1] || '#eec9ea', 3);
    });
    g.button(786, 17, 123, 41, 'Clear', null, g.pointer);
  };
}

function wreck(g) {
  const pivot = { x: 448 + g.level * 9, y: 71 };
  let rope = 329;
  let angle = -.8, velocity = 0, timer = 54 - g.level * 2, boost = 0, broken = 0;
  const columns = 5 + Math.floor(g.level / 2), rows = 6;
  const bricks = Array.from({ length: columns * rows }, (_, i) => ({
    x: 460 + i % columns * 58 + Math.floor(i / columns) % 2 * 15,
    y: 212 + Math.floor(i / columns) * 44, xvel: 0, yvel: 0,
    color: ['#b55e5b', '#cd7769', '#a95c71'][i % 3], broken: false,
  }));
  const deck = 493;
  return dt => {
    const aimed = g.pointer.down ? Math.sign(g.pointer.x - pivot.x) : 0;
    const adjustment = Number(g.key('down')) - Number(g.key('up'));
    rope = clamp(rope + dt * adjustment * 145, 182, 435);
    const input = Number(g.key('right')) - Number(g.key('left')) + aimed;
    if ((g.action() || g.pressed('shift')) && boost <= 0) { velocity += Math.sign(input || velocity || 1) * 2.2; boost = 1.3; }
    boost -= dt; timer -= dt;
    velocity += (-Math.sin(angle) * 2.65 + input * 3.4 - velocity * .31) * dt;
    angle += velocity * dt;
    if (Math.abs(angle) > 1.49) { angle = clamp(angle, -1.49, 1.49); velocity *= -.26; }
    const ball = { x: pivot.x + Math.sin(angle) * rope, y: pivot.y + Math.cos(angle) * rope };
    g.image('#292139', '#402845');
    g.grid(34, '#ffd1c811');
    g.box(0, deck, W, H - deck, '#261b2c');
    g.line(0, deck, W, deck, '#805865', 3);
    g.line(84, 73, 84, deck, '#6b5068', 15);
    g.line(76, 71, pivot.x + 38, 71, '#d18c6f', 13);
    for (const b of bricks) {
      if (!b.broken && dt && Math.abs(velocity) > .25 && inRect(ball, b.x - 38, b.y - 36, 131, 111)) {
        b.broken = true; b.xvel = velocity * 135 + g.rand(24, 145); b.yvel = g.rand(-170, -32); broken++;
        velocity *= .966; if (broken % 3 === 1) g.beep(125 + broken * 6, .14, 'triangle', .054);
      }
      if (!b.broken && dt && b.y < deck - 40 && !bricks.some(other => !other.broken && other !== b && Math.abs(other.x - b.x) < 38 && other.y > b.y && other.y - b.y < 64)) {
        b.y += dt * 171;
      }
      if (b.broken) { b.x += b.xvel * dt; b.y += b.yvel * dt; b.yvel += dt * 620; }
      g.box(b.x, Math.min(b.y, b.broken ? H + 100 : deck - 40), 54, 39, b.color, 4, '#e19c8a');
    }
    g.line(pivot.x, pivot.y, ball.x, ball.y, '#f4c6a9', 5);
    g.dot(ball.x, ball.y, 37, '#4b435b', '#bfa2aa', 4);
    g.dot(ball.x - 9, ball.y - 10, 14, '#746479');
    g.dot(pivot.x, pivot.y, 9, '#efb389');
    g.score = broken * 99;
    const target = Math.ceil(bricks.length * (.45 + g.level * .034));
    g.label(`Bricks broken ${broken} / ${target}`, 23, 29);
    g.label(`Time ${Math.max(0, Math.ceil(timer))}s`, W - 23, 29, '#ffd6c6', 19, 'right');
    g.meter(26, 498, 148, (rope - 182) / 253, '#eca68d', 'Cable length');
    if (dt && timer <= 0) g.end('Time is up', `You knocked out ${broken} bricks.`);
    else if (broken >= target) { g.score += Math.ceil(timer) * 10; g.end('Structure down', `You knocked out ${broken} bricks.`, true); }
  };
}

export const physics = {
  cannon: mode('Aim with ↑ / ↓ or point. Hold Space or press the field to charge. Release to launch.', cannon, vertical, [['space', 'Charge']]),
  bridge: mode('Tap two joints to add or remove a beam. Tap Test bridge or press Space to send the truck.', bridge),
  grapple: mode('Hold Space or touch the field to grapple. Release to let go. ← / → adjust your swing.', grapple, horizontal, [['space', 'Hook']]),
  merge: mode('Aim with ← / → or your pointer. Tap or press Space to drop the fruit.', merge),
  sand: mode('Drag to paint. Tap a material or press 1–5. Clear the canvas with R.', sand),
  wreck: mode('Hold ← / → to swing. ↑ / ↓ adjusts the cable. Space or Boost adds momentum.', wreck, ['left', 'up', 'down', 'right'], [['space', 'Boost']]),
};
