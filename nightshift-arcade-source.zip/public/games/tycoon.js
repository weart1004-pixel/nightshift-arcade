import { W, H, TAU, clamp } from './engine.js';
import { mode } from './controls.js';

const integer = value => Math.max(0, Math.floor(value)).toLocaleString('en-US');
const money = value => '$' + integer(value);

function buildBoard(g, spec) {
  function metricList(stats) {
    stats.forEach(([name, value], i) => {
      const x = 38 + i * 225;
      g.box(x, 70, 209, 74, '#1c2433', 9, '#3d5361');
      g.label(name, x + 15, 90, '#bdcce0', 15);
      g.label(String(value), x + 15, 120, spec.color, 23);
    });
  }
  function buttonList(actions) {
    actions.forEach((job, i) => {
      const [name, detail, enabled, run] = job;
      const x = 38 + (i % 2) * 450, y = 325 + Math.floor(i / 2) * 87;
      const click = g.button(x, y, 434, 72, (i + 1) + '   ' + name, detail, g.pointer, enabled, spec.color);
      if (enabled && (click || g.pressed(String(i + 1)))) {
        run(); g.beep(380 + i * 55, .091, 'triangle', .045);
      }
    });
  }
  return (stats, actions, objectCount, message, progress) => {
    g.image('#10212c', '#221a33');
    g.grid(42, '#c5eaff0b');
    g.label(spec.name, 38, 35, '#e9fff5', 27);
    g.label(spec.goal, W - 38, 34, '#a9c9ca', 17, 'right');
    metricList(stats);
    g.box(38, 160, 884, 142, '#172334', 10, '#3d5866');
    for (let i = 0; i < 5; i++) {
      const x = 68 + i * 171, y = 178, active = i < objectCount;
      const tint = active ? spec.color : '#5d6b828f';
      const body = active ? '#253b4b' : '#20293d';
      g.box(x, y + 14, 119, 55, body, 8, tint);
      g.line(x - 8, y + 72, x + 128, y + 72, '#4d617b', 3);
      g.box(x + 35, y + 8, 49, 37, '#242947', 8, tint);
      if (active) {
        g.glow(spec.color, 11, () => g.dot(x + 59, y + 27, 8 + Math.sin(g.time * 4 + i) * 2, spec.color));
        for (let j = 0; j < 3; j++) g.box(x + 22 + j * 32, y + 53, 14, 4, tint, 2);
      }
      g.label(spec.modules[i], x + 59, y + 91, active ? '#edf4fb' : '#a6afc0', 15, 'center');
    }
    g.meter(50, 290, 856, progress, spec.color);
    buttonList(actions);
    g.label(message, 40, 511, '#d4d6eb', 16);
  };
}

function mine(g) {
  const target = 420 + g.level * 140;
  const draw = buildBoard(g, {
    name: 'Crystal mine', goal: 'Mine ' + target + ' gems', modules: ['Shaft', 'Drill', 'Turret', 'Rampart', 'Extractor'], color: '#9fe6c6',
  });
  let gems = 22, total = 0, drills = 0, turrets = 0, integrity = 100, raid = 14 - g.level * .58, cooldown = 0;
  const gain = n => { gems += n; total += n; };
  return dt => {
    cooldown = Math.max(0, cooldown - dt);
    gain(dt * drills * (2.6 + drills * .14));
    raid -= dt;
    if (raid <= 0) {
      integrity -= Math.max(1, 19 + g.level * 4 - turrets * 8);
      raid = 13 - g.level * .66; g.beep(127, .24, 'square', .035);
    }
    const drillCost = 25 + drills * 26, turretCost = 43 + turrets * 37, patchCost = 26 + g.level * 3;
    draw([['Available', integer(gems)], ['Mined', integer(total)], ['Base integrity', Math.max(integrity, 0) + '%'], ['Next raid', Math.ceil(raid) + 's']], [
      ['Mine crystals', '+' + (5 + drills) + ' gems', !cooldown, () => { gain(5 + drills); cooldown = .24; }],
      ['Upgrade drill', drillCost + ' gems • Passive mining', gems >= drillCost, () => { gems -= drillCost; drills++; }],
      ['Build turret', turretCost + ' gems • Reduces raid damage', gems >= turretCost, () => { gems -= turretCost; turrets++; }],
      ['Repair base', patchCost + ' gems • Restore 32%', gems >= patchCost && integrity < 100, () => { gems -= patchCost; integrity = Math.min(100, integrity + 32); }],
    ], Math.min(5, 1 + drills + turrets), 'Incoming raids damage your base. Build turrets before the timer runs out.', total / target);
    g.score = total;
    if (integrity <= 0) g.end('The mine fell', 'You mined ' + integer(total) + ' gems.');
    else if (total >= target) { g.score += 500; g.end('Mine secured', 'You hit the gem target with ' + integrity + '% integrity.', true); }
  };
}

function food(g) {
  const lemonade = g.level % 2 === 1;
  const item = lemonade ? 'lemonade' : 'pizza';
  const total = 26 + g.level * 7;
  const draw = buildBoard(g, {
    name: lemonade ? 'Lemonade stand' : 'Pizza counter', goal: 'Serve ' + total + ' orders', modules: [lemonade ? 'Pitcher' : 'Oven', 'Prep area', 'Counter', 'Dining room', 'Location 2'], color: lemonade ? '#ffe68b' : '#ffba8e',
  });
  let cash = 29, stock = 6, orders = 2, size = 1, helpers = 0, sold = 0, missed = 0, demand = 3.1, patience = 1, cooldown = 0, auto = 0;
  const price = () => 8 + size * 3;
  function serve() {
    if (!orders || !stock) return;
    sold++; cash += price(); orders--; stock--; patience = 1;
  }
  return dt => {
    demand -= dt; cooldown = Math.max(0, cooldown - dt); auto -= dt;
    if (demand <= 0) { orders++; demand = Math.max(.92, 4.1 - size * .32 - g.level * .24); }
    if (orders > 0) patience -= dt * (.079 + orders * .019 + g.level * .008);
    if (orders && patience <= 0) { orders--; missed++; patience = 1; }
    if (helpers && auto <= 0) { serve(); auto = Math.max(.5, 3.05 - helpers * .51); }
    const staff = 51 + helpers * 49, expand = 41 + size * 33;
    draw([['Cash', money(cash)], ['Ingredients', integer(stock)], ['Orders waiting', integer(orders)], ['Orders served', sold + '/' + total]], [
      ['Serve ' + item, '+' + money(price()) + ' per order', orders > 0 && stock > 0 && !cooldown, () => { serve(); cooldown = .27; }],
      ['Restock', '$13 • +7 ingredients', cash >= 13, () => { cash -= 13; stock += 7; }],
      ['Hire staff', money(staff) + ' • Automatically serves orders', cash >= staff, () => { cash -= staff; helpers++; }],
      ['Expand', money(expand) + ' • Faster orders and better prices', cash >= expand, () => { cash -= expand; size++; }],
    ], Math.min(5, size + helpers), 'Patience ' + Math.max(0, Math.ceil(patience * 100)) + '%   •   Lost orders ' + missed + '/8', sold / total);
    g.score = sold * 35 + cash;
    if (missed >= 8) g.end('The line walked out', 'You served ' + sold + ' orders.');
    else if (sold >= total) { g.score += 350; g.end('Sold out', 'You served all ' + total + ' orders.', true); }
  };
}

function breed(g) {
  const target = 3 + Number(g.level >= 3);
  const names = ['Mossling', 'Glowbug', 'Stormkin', 'Moon Drake', 'Star Wyrm'];
  const draw = buildBoard(g, {
    name: 'Monster hatchery', goal: 'Raise a ' + names[target], modules: names, color: '#b798fa',
  });
  let cash = 24, eggs = 1, creatures = [0, 0, 0, 0, 0], incubator = 0, next = 0, level = 0, raised = 0, feedAt = 0;
  return dt => {
    cash += dt * (1.25 + creatures.reduce((sum, count, i) => sum + count * (i + 1) * .55, 0));
    if (incubator && g.time >= incubator) {
      creatures[next]++; level = Math.max(level, next); raised++; incubator = 0; g.beep(530 + next * 88, .19, 'triangle', .056);
    }
    const pair = [3, 2, 1, 0].find(i => i < target && creatures[i] >= 2) ?? -1;
    draw([['Cash', money(cash)], ['Eggs', integer(eggs)], ['In pens', creatures.reduce((a, b) => a + b, 0)], ['Rarest', raised ? names[level] : 'None yet']], [
      ['Buy egg', '$13 • Add one egg', cash >= 13, () => { cash -= 13; eggs++; }],
      ['Hatch egg', eggs ? 'Needs one egg • 2.5 seconds' : 'Buy an egg first', eggs > 0 && !incubator, () => { eggs--; next = 0; incubator = g.time + 2.5; }],
      ['Breed a pair', pair >= 0 ? names[pair] + ' + ' + names[pair] + ' → ' + names[pair + 1] : 'Needs two creatures of the same type', pair >= 0 && !incubator, () => { creatures[pair]--; next = pair + 1; incubator = g.time + 4.05 + (pair + g.level * .3) * .45; }],
      ['Harvest nectar', 'Earn $7 from the pens • Every 3s', raised > 0 && feedAt <= g.time, () => { cash += 7; feedAt = g.time + 3; }],
    ], raised ? level + 1 : 0, incubator ? 'Incubating ' + names[next] + '  •  ' + Math.ceil(incubator - g.time) + 's' : 'Creatures in your pens generate cash. Breed pairs to discover new types.', level / target);
    g.score = raised * 45 + level * 200;
    if (level >= target) { g.score += 350; g.end('Rare creature raised', names[level] + ' is in your hatchery.', true); }
  };
}

function factory(g) {
  const target = 32 + g.level * 15;
  const draw = buildBoard(g, {
    name: 'Orbital station', goal: 'Fabricate ' + target + ' parts', modules: ['Solar bank', 'Ore drill', 'Fabricator', 'Processing', 'Assembly'], color: '#86ddf6',
  });
  let cash = 43, ore = 0, parts = 0, solar = 2, drills = 1, fabs = 0, cooldown = 0;
  return dt => {
    cooldown = Math.max(0, cooldown - dt);
    const power = solar * 3, demand = drills + fabs * 3;
    const efficiency = Math.min(1, power / Math.max(demand, 1));
    ore += dt * drills * 1.3 * efficiency;
    const converted = Math.min(ore, dt * fabs * (1.15 - g.level * .065) * efficiency);
    ore -= converted; parts += converted; cash += converted * 4.65;
    const solarCost = 20 + solar * 4, drillCost = 22 + drills * 13, fabCost = 27 + fabs * 22;
    draw([['Credits', money(cash)], ['Stored ore', integer(ore)], ['Parts built', integer(parts) + '/' + target], ['Power load', demand + ' / ' + power]], [
      ['Salvage ore', '+4 ore and $4 • Every 1.3s', !cooldown, () => { ore += 4; cash += 4; cooldown = 1.3; }],
      ['Add solar bank', money(solarCost) + ' • +3 power supply', cash >= solarCost, () => { cash -= solarCost; solar++; }],
      ['Add ore drill', money(drillCost) + ' • Faster extraction', cash >= drillCost, () => { cash -= drillCost; drills++; }],
      ['Add fabricator', money(fabCost) + ' • Turns ore into parts', cash >= fabCost, () => { cash -= fabCost; fabs++; }],
    ], Math.min(5, 2 + fabs + Math.max(0, drills - 1)), demand > power ? 'Power shortage. Add solar banks to restore full production.' : 'Fabricated parts generate credits for upgrades.', parts / target);
    g.score = parts * 50;
    if (parts >= target) { g.score += 500; g.end('Station online', 'You fabricated all ' + target + ' parts.', true); }
  };
}

function terminalTycoon(g) {
  const target = 47 + g.level * 14;
  const draw = buildBoard(g, {
    name: 'Network operations', goal: 'Process ' + target + ' jobs', modules: ['Console', 'Node array', 'Cooler', 'Cluster', 'Core'], color: '#96f3a6',
  });
  let credits = 34, queue = 6, servers = 1, coolers = 0, heat = 0, total = 0, down = 0, throttle = 0, cooldown = 0;
  return dt => {
    const working = queue > 0 && down <= 0;
    cooldown = Math.max(0, cooldown - dt);
    const cooling = 7 + coolers * 8.5;
    heat = clamp(heat + dt * ((working ? servers * (8 + g.level * .55) : 0) - cooling), 0, 100);
    if (heat >= 100) { down = 2.3; heat = 59; throttle++; g.beep(136, .2, 'square', .04); }
    const worked = working ? Math.min(queue, dt * servers * .95) : 0;
    total += worked; queue -= worked; credits += worked * 4.8; down -= dt;
    const node = 24 + servers * 13, cooler = 23 + coolers * 15;
    draw([['Credits', money(credits)], ['Queued jobs', integer(Math.ceil(queue))], ['Jobs processed', integer(total)], ['Heat', Math.ceil(heat) + '%']], [
      ['Queue jobs', '+7 jobs • Every second', !cooldown, () => { queue += 7; cooldown = 1.05; }],
      ['Add server', money(node) + ' • Faster throughput', credits >= node, () => { credits -= node; servers++; }],
      ['Add cooling', money(cooler) + ' • Reduces heat', credits >= cooler, () => { credits -= cooler; coolers++; }],
      ['Vent heat', '$8 • Removes 35% heat', heat >= 15 && credits >= 8, () => { credits -= 8; heat = Math.max(0, heat - 35); }],
    ], Math.min(5, servers + coolers), down > 0 ? 'Cooling down after an overheat.' : 'Overheats ' + throttle + '/5  •  Keep the queue full and the servers cool.', total / target);
    g.score = total * 42;
    if (throttle >= 5) g.end('Network shut down', 'You processed ' + integer(total) + ' jobs.');
    else if (total >= target) { g.score += 500; g.end('Jobs cleared', 'All ' + target + ' jobs were processed.', true); }
  };
}

function dungeon(g) {
  const goal = 5 + g.level;
  const draw = buildBoard(g, {
    name: 'Dungeon dispatch', goal: 'Clear ' + goal + ' floors', modules: ['Guild', 'Gear vault', 'Training yard', 'Alchemist', 'Deep gate'], color: '#d4a8ff',
  });
  let gold = 40, health = 100, gear = 1, rank = 1, potions = 1, floor = 0, run = 0, report = 'The team is waiting for orders.';
  return () => {
    const power = gear * 10 + rank * 12;
    const danger = 18 + floor * (11 + g.level) + g.level * 3;
    if (run && run <= g.time) {
      run = 0;
      const damage = Math.max(9, 17 + (danger - power) * 1.6 + g.rand(-5, 5));
      health -= Math.round(damage);
      if (power + 9 >= danger) {
        floor++; const loot = 35 + floor * 9; gold += loot; report = 'Floor cleared. Loot +' + money(loot) + '.'; g.beep(550, .18);
      } else {
        gold += 16; report = 'The party retreated with $16. Upgrade to raise party power.'; g.beep(136, .21);
      }
    }
    const gearCost = 13 + gear * 15, train = 15 + rank * 14;
    draw([['Gold', money(gold)], ['Health', Math.max(health, 0) + '%'], ['Party power', power], ['Floor rating', danger]], [
      ['Send party', 'Explore floor ' + (floor + 1), !run, () => { run = g.time + 3 + floor * .35; }],
      ['Upgrade gear', money(gearCost) + ' • +10 party power', gold >= gearCost && !run, () => { gear++; gold -= gearCost; }],
      ['Train party', money(train) + ' • +12 party power', gold >= train && !run, () => { rank++; gold -= train; }],
      ['Heal party', potions ? 'Free potion • +47% health' : '$17 • Restore 38% health', health < 100 && (potions || gold >= 17) && !run, () => {
        if (potions) { potions--; health += 47; }
        else { gold -= 17; health += 38; }
        health = Math.min(100, health);
      }],
    ], Math.min(5, 1 + Math.floor((rank + gear) / 2)), run ? 'Exploring floor ' + (floor + 1) + '  •  ' + Math.ceil(run - g.time) + 's' : report, floor / goal);
    g.score = floor * 200 + gold;
    if (health <= 0) g.end('The party fell', 'You cleared ' + floor + ' floors.');
    else if (floor >= goal) { g.score += 450; g.end('Dungeon cleared', 'Your team cleared all ' + goal + ' floors.', true); }
  };
}

const hint = 'Tap an action or use its numbered shortcut (1–4).';
export const tycoon = {
  mine: mode(hint, mine), food: mode(hint, food), breed: mode(hint, breed),
  factory: mode(hint, factory), hack: mode(hint, terminalTycoon), loot: mode(hint, dungeon),
};
