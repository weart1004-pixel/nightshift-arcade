import { W, H, TAU, clamp, distance, inRect, makeMaze, routeStep } from './engine.js';
import { mode, directions, horizontal } from './controls.js';

function mazeSurvival(g, variant) {
  const columns = 17 + (g.level > 3 ? 2 : 0);
  const rows = 11 + (g.level > 4 ? 2 : 0);
  const side = Math.floor(Math.min(884 / columns, 442 / rows));
  const ox = (W - columns * side) / 2;
  const oy = (H - rows * side) / 2 + 10;
  const maze = makeMaze(columns, rows, g.random);
  const center = (x, y) => ({ x: ox + (x + .5) * side, y: oy + (y + .5) * side });
  const cell = point => ({ x: Math.floor((point.x - ox) / side), y: Math.floor((point.y - oy) / side) });
  const player = center(1, 1);
  const exit = center(columns - 2, rows - 2);
  const cells = maze.flatMap((row, y) => row.flatMap((wall, x) => wall || x + y < 6 ? [] : [{ x, y }]));
  const spawn = cells.filter(value => value.x >= columns - 5 && value.y <= 5);
  let hunterCell = { ...g.pick(spawn.length ? spawn : cells) };
  let hunter = center(hunterCell.x, hunterCell.y);
  let patrol = g.pick(cells);
  let rest = 0;
  let noise = 0;
  let alert = 0;
  let facing = 0;
  const keyCount = variant === 'asylum' ? 3 + Number(g.level >= 3) : 1;
  const pool = cells.filter(value => value.x !== columns - 2 || value.y !== rows - 2);
  const keys = Array.from({ length: keyCount }, (_, i) => {
    const quarter = pool.filter(value => (i % 2 ? value.x >= columns / 2 : value.x < columns / 2) && !value.used);
    const c = g.pick(quarter.length ? quarter : pool.filter(value => !value.used));
    c.used = true;
    return { ...center(c.x, c.y), collected: false };
  });

  function walk(dx, dy) {
    const r = side * .20;
    function clear(x, y) {
      return [[-r, -r], [r, -r], [r, r], [-r, r]].every(([sx, sy]) => {
        const loc = cell({ x: x + sx, y: y + sy });
        return maze[loc.y]?.[loc.x] === 0;
      });
    }
    if (clear(player.x + dx, player.y)) player.x += dx;
    if (clear(player.x, player.y + dy)) player.y += dy;
  }

  return dt => {
    const movement = g.move();
    const moving = movement.x || movement.y;
    const sneaking = g.key('shift');
    if (moving) facing = Math.atan2(movement.y, movement.x);
    const speed = side * (variant === 'sound' ? (sneaking ? 2.35 : 4.2) : 4);
    walk(movement.x * speed * dt, movement.y * speed * dt);
    noise = clamp(noise + dt * (moving && !sneaking ? 1.7 : -2.8), 0, 1);
    if (variant === 'sound' && distance(player, hunter) < side * (2.4 + noise * 4) && noise > .36) alert = 3.5;
    else alert = Math.max(0, alert - dt);
    rest -= dt;
    if (g.time > 4 && rest <= 0 && dt) {
      const playerCell = cell(player);
      const sees = variant === 'sound' ? alert > 0 || distance(player, hunter) < side * .95 : distance(player, hunter) < side * (5 + g.level * .3);
      const next = routeStep(maze, hunterCell, sees ? playerCell : patrol);
      if (next) hunterCell = next;
      else patrol = g.pick(cells);
      rest = sees ? .51 - g.level * .023 : .96;
    }
    const destination = center(hunterCell.x, hunterCell.y);
    hunter.x += (destination.x - hunter.x) * Math.min(1, dt * 5.3);
    hunter.y += (destination.y - hunter.y) * Math.min(1, dt * 5.3);
    for (const k of keys) if (!k.collected && distance(player, k) < side * .39) {
      k.collected = true;
      g.beep(570, .14, 'triangle');
    }
    const collected = keys.filter(k => k.collected).length;
    const open = collected === keyCount;
    g.score = collected * 100 + g.time * 2;

    g.image('#080e1b', '#171126');
    for (let y = 0; y < rows; y++) for (let x = 0; x < columns; x++) {
      const lx = ox + x * side, ly = oy + y * side;
      if (maze[y][x]) {
        g.box(lx, ly, side, side, '#273346');
        g.box(lx + 2, ly + 2, side - 4, side - 4, '#35445a', 3);
        g.line(lx + 5, ly + 6, lx + side - 5, ly + 6, '#536078');
      } else {
        g.box(lx, ly, side, side, (x + y) % 2 ? '#292739' : '#282837');
        g.box(lx + 3, ly + 3, side - 6, side - 6, '#202234', 4);
      }
    }
    g.glow(open ? '#63ef9d' : '#f56e98', 19, () => {
      g.box(exit.x - side * .4, exit.y - side * .4, side * .8, side * .8, open ? '#16694b' : '#69233b', 5, open ? '#83ffd1' : '#f987ab');
      g.label('EXIT', exit.x, exit.y, '#ffefff', 11, 'center');
    });
    for (const k of keys) if (!k.collected) {
      g.glow('#ffc875', 12, () => g.dot(k.x - 4, k.y, 5, null, '#ffd286', 3));
      g.line(k.x, k.y, k.x + 10, k.y, '#ffd286', 3);
      g.line(k.x + 7, k.y, k.x + 7, k.y + 4, '#ffd286', 2);
    }
    g.glow('#ff476d', 17, () => {
      g.dot(hunter.x, hunter.y, side * .28, '#501b46', '#da4c88');
      g.dot(hunter.x - 4, hunter.y - 3, 2.2, '#fff2fa');
      g.dot(hunter.x + 4, hunter.y - 3, 2.2, '#fff2fa');
    });
    const light = (variant === 'sound' ? 3.25 : variant === 'asylum' ? 3.05 : 2.6) * side;
    const ctx = g.ctx;
    const fx = player.x + Math.cos(facing) * (variant === 'flashlight' ? 21 : 0);
    const fy = player.y + Math.sin(facing) * (variant === 'flashlight' ? 21 : 0);
    const night = ctx.createRadialGradient(fx, fy, side * .55, fx, fy, light);
    night.addColorStop(0, '#06071200');
    night.addColorStop(.42, '#0607122e');
    night.addColorStop(1, '#060712f6');
    g.box(0, 0, W, H, night);
    g.glow('#b1f1fa', 14, () => g.dot(player.x, player.y, side * .20, '#7de2e4', '#e5ffff'));
    g.label(variant === 'sound' ? `Pass ${collected} / ${keyCount}` : `Keys ${collected} / ${keyCount}`, 27, 26);
    g.label(open ? 'Exit unlocked' : `Exit ${Math.ceil(distance(player, exit) / side)} tiles away`, W - 24, 26, open ? '#87ffb4' : '#c2aabf', 17, 'right');
    if (variant === 'sound') g.meter(27, H - 17, 165, noise, alert ? '#ff5c90' : '#59e6c6', alert ? 'IT HEARD YOU' : 'Noise');
    if (dt && g.time > 4 && distance(player, hunter) < side * .38) g.end('Caught in the dark', `You recovered ${collected} of ${keyCount}.`);
    if (dt && open && distance(player, exit) < side * .38) {
      g.score += 500;
      g.end('You made it out', `Escape time ${Math.floor(g.time)} seconds.`, true);
    }
  };
}

function cameras(g) {
  const rooms = ['Showroom', 'Workshop', 'West Hall', 'Office Door'];
  let camera = 0, threat = 0, door = false, power = 100, arrival = 0;
  let next = 4.1, blocked = 0;
  const dawn = 34 + g.level * 4;

  return dt => {
    if (g.pressed('left')) camera = (camera + rooms.length - 1) % rooms.length;
    if (g.pressed('right')) camera = (camera + 1) % rooms.length;
    if (g.action() || g.hitBox(706, 426, 216, 59)) {
      door = !door;
      g.beep(door ? 190 : 305, .14, 'square');
    }
    if (g.time >= next && threat < 3) {
      threat++;
      next = g.time + g.rand(2.7, 4.5) - g.level * .16;
      if (threat === 3) {
        arrival = 0;
        g.beep(105, .35, 'sawtooth', .04);
      }
    }
    if (threat === 3) {
      arrival += dt;
      if (door && arrival > 1.18) { threat = 0; blocked++; next = g.time + 3.4; g.beep(245); }
      else if (!door && arrival > 1.65 - g.level * .06) g.end('The door was open', 'Close the security door as soon as the office alert appears.');
    }
    power -= dt * (door ? 7.5 : .7 + g.level * .035);
    g.score = g.time * 15 + blocked * 80;

    g.image('#111926', '#110e1b');
    g.box(27, 50, 650, 348, '#10272f', 12, '#526674');
    const focal = [365, 270, 484, 315][camera];
    g.poly([[38, 62], [666, 62], [focal + 98, 147], [focal - 91, 147]], '#1d333a');
    g.poly([[38, 385], [666, 385], [focal + 98, 305], [focal - 91, 305]], '#233e41');
    g.box(focal - 91, 147, 189, 158, '#13292e', 2, '#3b555c');
    g.line(38, 62, focal - 91, 147, '#647b80', 3);
    g.line(666, 62, focal + 98, 147, '#647b80', 3);
    g.line(38, 385, focal - 91, 305, '#52636d', 3);
    g.line(666, 385, focal + 98, 305, '#52636d', 3);
    for (let i = 0; i < 6; i++) {
      const x = 63 + i * 96;
      g.box(x, 120 + 194 * (i % 2), 37, 22, '#0d212c', 3);
      g.dot(x + 12, 131 + 194 * (i % 2), 4, i === camera ? '#79dcb1' : '#426973');
    }
    if (threat === camera) {
      const sway = Math.sin(g.time * 5) * 4;
      g.box(focal - 24 + sway, 216, 51, 112, '#101423', 15);
      g.dot(focal + sway, 207, 28, '#161922', '#53626b');
      g.glow('#ee5375', 15, () => { g.dot(focal - 10 + sway, 205, 4, '#ffd1df'); g.dot(focal + 11 + sway, 205, 4, '#ffd1df'); });
    }
    for (let y = 64; y < 392; y += 5) g.line(37, y, 666, y, '#09172646', 1);
    g.label(`CAM ${camera + 1}  /  ${rooms[camera].toUpperCase()}`, 48, 82, '#b1eccf', 17, 'left', 700, true);
    g.dot(648, 82, 5, '#ff6e9c');
    for (let i = 0; i < rooms.length; i++) {
      if (g.button(29 + i * 164, 423, 153, 62, rooms[i], `Camera ${i + 1}`, g.pointer, true, camera === i ? '#88ffca' : '#ac9acd')) camera = i;
    }
    const danger = threat === 3;
    g.box(706, 50, 216, 348, '#22182a', 11, danger ? '#ff6a8a' : '#41384f');
    g.label('SECURITY DOOR', 814, 79, '#efd9ee', 17, 'center');
    g.box(752, 105, 124, 172, door ? '#393647' : '#14101c', 5, '#665570');
    if (door) for (let i = 0; i < 7; i++) g.line(757, 118 + i * 23, 871, 118 + i * 23, '#746281', 2);
    if (danger) g.glow('#ff436e', 20, () => g.dot(814, 160, 8, '#ff9fae'));
    g.label(danger ? 'AT THE DOOR' : 'Hall clear', 814, 308, danger ? '#ff8caa' : '#9cdbc2', 17, 'center');
    g.meter(722, 371, 184, power / 100, power > 25 ? '#8ee8b9' : '#ff819b', `Power ${Math.max(0, Math.ceil(power))}%`);
    g.button(706, 426, 216, 59, door ? 'Open door' : 'Close door', door ? 'Power draining' : 'Space / tap', g.pointer);
    g.label(`Shift ends in ${Math.max(0, Math.ceil(dawn - g.time))}s`, 30, 24);
    if (dt && power <= 0) g.end('Power lost', 'Open the door between visits to save power.');
    if (dt && g.time >= dawn) g.end('Morning shift', `You turned away ${blocked} visitors.`, true);
  };
}

function anomaly(g) {
  const areas = [
    [148, 168, 153, 139], [353, 136, 132, 122], [572, 172, 136, 144], [785, 261, 86, 156],
  ];
  const colors = ['#bc75d0', '#5eadc8', '#c98d65', '#8fb789', '#d86774'];
  const count = 5 + g.level;
  let round = 0, mistakes = 0, changed = 0, observe = true, since = 0, objects = [];
  function reset() {
    const previous = changed;
    changed = (previous + 1 + Math.floor(g.random() * 3)) % areas.length;
    objects = areas.map(() => ({ color: g.pick(colors), angle: g.rand(-.12, .12), shift: g.rand(-7, 7) }));
    since = g.time;
    observe = true;
  }
  reset();

  return dt => {
    if (observe && g.time - since > 3.25 - .16 * g.level) { observe = false; since = g.time; }
    if (g.pointer.tap && !observe) {
      const selected = areas.findIndex(area => inRect(g.pointer, ...area));
      if (selected !== -1) {
        if (selected === changed) { round++; g.beep(660); }
        else { mistakes++; g.beep(140, .16, 'triangle'); }
        reset();
      }
    }
    if (!observe && g.time - since > 11 - .5 * g.level) { mistakes++; reset(); }
    g.score = round * 150;
    g.image('#171321', '#201b28');
    g.poly([[39, 66], [924, 66], [661, 141], [288, 141]], '#251f30');
    g.poly([[39, 488], [924, 488], [661, 323], [288, 323]], '#2c2937');
    g.poly([[39, 66], [288, 141], [288, 323], [39, 488]], '#382e40');
    g.poly([[924, 66], [661, 141], [661, 323], [924, 488]], '#31293e');
    g.box(288, 141, 373, 181, '#211d2c', 0, '#514154');
    for (let i = 0; i < 6; i++) g.line(75 + 166 * i, 489, 373 + i * 44, 322, '#4e4559', 2);
    areas.forEach(([x, y, w, h], index) => {
      const obj = objects[index];
      const flagged = !observe && index === changed;
      const hovered = !observe && inRect(g.pointer, x, y, w, h);
      g.box(x, y, w, h, hovered ? '#ffffff14' : '#17132180', 6, hovered ? '#efafeb' : '#655069');
      const cx = x + w / 2 + obj.shift + (flagged && round % 3 === 0 ? 22 : 0);
      const cy = y + h / 2;
      const tint = flagged && round % 3 === 1 ? '#ea6779' : obj.color;
      g.ctx.save();
      g.ctx.translate(cx, cy);
      g.ctx.rotate(flagged && round % 3 === 2 ? obj.angle + .42 : obj.angle);
      if (index === 0) {
        g.box(-34, -42, 68, 82, '#4b3742', 2, '#ab806a');
        g.poly([[-25, 25], [-2, -14], [15, 5], [25, -4], [25, 25]], tint);
        g.dot(12, -20, 8, '#ffe3ae');
      } else if (index === 1) {
        g.dot(0, 0, 31, '#14101d', tint, 5);
        g.line(0, 0, -13, -16, '#fff0e1', 3);
        g.line(0, 0, 16, 4, '#fff0e1', 3);
      } else if (index === 2) {
        g.line(0, 35, 0, -15, '#dfba9c', 4);
        g.poly([[-26, 7], [-18, -25], [18, -25], [26, 7]], tint, '#ffdbdb');
        g.line(-20, 36, 20, 36, '#a48ba8', 5);
      } else {
        g.box(-23, -61, 46, 123, tint, 3, '#ae819c');
        g.dot(14, 12, 3, '#f9d69c');
      }
      g.ctx.restore();
    });
    g.label(observe ? 'Study the hallway' : 'What changed?', 26, 27, '#f7e7f5', 24);
    g.label(`Found ${round}/${count}   •   Errors ${mistakes}/3`, W - 26, 28, '#fbcbe5', 18, 'right');
    const duration = observe ? 3.25 - .16 * g.level : 11 - .5 * g.level;
    g.meter(28, 516, W - 56, 1 - (g.time - since) / duration, observe ? '#89d5f4' : '#ed8dda');
    if (dt && mistakes >= 3) g.end('Inspection failed', `You found ${round} anomalies.`);
    if (dt && round >= count) g.end('Hallway cleared', `You found all ${count} anomalies.`, true);
  };
}

function sonar(g) {
  const cols = 21, rows = 11, side = 40, ox = 60, oy = 58;
  const channel = makeMaze(cols, rows, g.random);
  const sub = { x: ox + 1.5 * side, y: oy + 1.5 * side };
  const goal = { x: ox + (cols - 1.5) * side, y: oy + (rows - 1.5) * side };
  let pulse = -10, heading = 0, oxygen = 100, contact = 0;
  const echo = { ...sub };
  const rocks = channel.flatMap((row, y) => row.flatMap((solid, x) => !solid ? [] : [{
    x: ox + x * side, y: oy + y * side, r: g.rand(5, 13),
  }]));
  const blocked = (x, y) => channel[Math.floor((y - oy) / side)]?.[Math.floor((x - ox) / side)] !== 0;

  return dt => {
    if ((g.action() || g.pointer.tap) && g.time - pulse > 2.1) {
      pulse = g.time; echo.x = sub.x; echo.y = sub.y;
      oxygen -= 1.2;
      g.beep(445, .5, 'sine', .045);
    }
    const m = g.move();
    if (m.x || m.y) heading = Math.atan2(m.y, m.x);
    const vx = m.x * dt * (162 - g.level * 4), vy = m.y * dt * (162 - g.level * 4);
    contact = Math.max(0, contact - dt);
    if (!blocked(sub.x + vx + Math.sign(vx) * 7, sub.y)) sub.x += vx;
    else if (m.x) contact = .13;
    if (!blocked(sub.x, sub.y + vy + Math.sign(vy) * 7)) sub.y += vy;
    else if (m.y) contact = .13;
    oxygen -= dt * (.48 + .032 * g.level + (contact > 0 ? .38 : 0));
    const radius = (g.time - pulse) * 310;
    g.score = g.time * 2 + 70 - distance(sub, goal) / 14;
    g.image('#031a28', '#051324');
    g.grid(40, '#8ae8d616', ox, oy);
    for (const rock of rocks) {
      const center = { x: rock.x + 20, y: rock.y + 20 };
      const rippled = g.time - pulse < 2.3 && distance(center, echo) < radius && radius < distance(center, echo) + 355;
      if (distance(center, sub) < 66 || rippled) {
        g.box(rock.x + 2, rock.y + 2, 36, 36, rippled ? '#123e4a' : '#102a3c', 6, '#25505b');
        g.dot(center.x, center.y, rock.r, '#2e4e5b');
      }
    }
    if (radius < 680) g.glow('#6affce', 8, () => g.dot(echo.x, echo.y, radius, null, '#7cf4d79f', 2));
    g.glow('#53e7ac', 19, () => {
      g.dot(goal.x, goal.y, 9 + Math.sin(g.time * 4) * 2, '#99ffd7', '#dcffea');
    });
    g.ctx.save();
    g.ctx.translate(sub.x, sub.y);
    g.ctx.rotate(heading);
    g.box(-13, -7, 26, 14, '#f4c45c', 7, '#fff2bd');
    g.dot(5, 0, 4, '#31788f');
    g.line(-12, -9, -12, 9, '#e8dda8', 3);
    g.ctx.restore();
    g.meter(30, 43, 170, oxygen / 100, '#74e2d6', `Oxygen ${Math.max(0, Math.ceil(oxygen))}%`);
    g.label(g.time - pulse > 2.1 ? 'Sonar ready' : 'Sonar recharging', W - 30, 30, '#94efdc', 19, 'right');
    if (dt && oxygen <= 0) g.end('Oxygen depleted', 'Follow the beacon and use pings to spot turns.');
    if (dt && distance(sub, goal) < 15) { g.score = 350 + oxygen * 5; g.end('Beacon located', `You surfaced with ${Math.ceil(oxygen)}% oxygen.`, true); }
  };
}

const codes = ['hollow','specter','echo','void','null','mirror','warden','cipher','nightfall','hex','static','glitch',
  'nobody','shatter','blackout','signal','orbit','fracture','silent','shutdown','shadow','root','ghost','haunted','corridor'];
function terminal(g) {
  const rows = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
  let matched = 0, buffer = '', next = g.pick(codes), clock = 0;
  const target = 9 + g.level * 2;
  function type(char) {
    if (char === 'backspace') buffer = buffer.slice(0, -1);
    else if (buffer.length < next.length + 4) buffer += char;
    if (buffer !== next) return;
    const prev = next;
    next = g.pick(codes.filter(code => code !== prev));
    matched++;
    buffer = '';
    clock = g.time;
    g.beep(465 + matched * 13, .08, 'square', .036);
  }
  return dt => {
    g.letters.forEach(type);
    const budget = 8.8 - g.level * .46 - Math.min(matched, 10) * .17;
    const left = budget - (g.time - clock);
    g.score = matched * 100;
    g.image('#0b130c', '#071713');
    g.box(47, 39, 866, 254, '#091811', 13, '#35624b');
    for (let y = 42; y < 290; y += 4) g.line(50, y, 910, y, '#75ffad08');
    g.label('AFTER HOURS TERMINAL', 70, 68, '#70cda7', 17, 'left', 700, true);
    g.label(`Codes ${matched} / ${target}`, 887, 68, '#7ce2b5', 17, 'right', 700, true);
    g.label(next.toUpperCase(), W / 2, 146, left < 2.5 ? '#ffa189' : '#b1f2b1', 46, 'center', 800, true);
    const inputColor = next.startsWith(buffer) ? '#5df8a2' : '#ff8d8c';
    g.label(`> ${buffer.toUpperCase()}${Math.floor(g.time * 3) % 2 ? '_' : ' '}`, W / 2, 216, inputColor, 32, 'center', 700, true);
    g.meter(70, 270, 820, left / budget, left < 2.5 ? '#f3827b' : '#56d18d');
    rows.forEach((row, y) => {
      const start = (W - (row.length * 65 + (y === 2 ? 89 : 0))) / 2;
      [...row].forEach((char, x) => {
        if (g.button(start + x * 65, 313 + y * 61, 58, 50, char.toUpperCase(), null, g.pointer, true, '#91edb7')) type(char);
      });
      if (y === 2 && g.button(start + row.length * 65, 313 + y * 61, 84, 50, '⌫ Delete', null, g.pointer)) type('backspace');
    });
    if (dt && matched >= target) g.end('Terminal sealed', `You cleared all ${target} codes.`, true);
    else if (dt && left <= 0) g.end('Signal lost', `You cleared ${matched} of ${target} codes.`);
  };
}

export const horror = {
  flashlight: mode('Arrows / WASD or onscreen arrows to move. Find the key, then the exit.', g => mazeSurvival(g, 'flashlight'), directions),
  cameras: mode('← → or tap a feed to change cameras. Space or Close door to block visitors.', cameras, horizontal, [['space', 'Door']]),
  anomaly: mode('Study the scene. Click or tap the changed object.', anomaly),
  sonar: mode('Arrows / WASD to steer. Space or tap the water to send a sonar pulse.', sonar, directions, [['space', 'Sonar']]),
  terminal: mode('Type the code or tap the letters. Backspace removes a letter.', terminal, [], [], true),
  sound: mode('Arrows / WASD to move. Hold Shift or Sneak to stay quiet.', g => mazeSurvival(g, 'sound'), directions, [['shift', 'Sneak']]),
  asylum: mode('Arrows / WASD or onscreen arrows to move. Collect the keys and reach the exit.', g => mazeSurvival(g, 'asylum'), directions),
};
