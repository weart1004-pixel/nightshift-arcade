import { W, H, TAU, clamp, distance, drawShip, inRect, makeMaze, routeStep, unit, wrap } from './engine.js';
import { mode, directions, horizontal } from './controls.js';

function asteroids(g) {
  const p = { x: W / 2, y: H / 2, vx: 0, vy: 0, heading: -Math.PI / 2 };
  const rocks = [], shots = [];
  let hp = 4, immunity = 1.2, cooldown = 0, wave = 0, next = .3;
  const total = 3 + Math.floor(g.level / 2), scale = [14, 24, 41];
  function rock(x, y, size) {
    const heading = g.rand(0, TAU), speed = g.rand(49, 108) + g.level * 9 + (2 - size) * 24;
    rocks.push({ x, y, size, vx: Math.cos(heading) * speed, vy: Math.sin(heading) * speed,
      spin: g.rand(-.7, .7), a: g.rand(0, TAU), points: Array.from({ length: 8 }, () => g.rand(.73, 1.17)) });
  }
  return dt => {
    if (!rocks.length && g.time >= next && wave < total) {
      wave++;
      for (let i = 0; i < 2 + wave + Math.floor(g.level / 2); i++) rock(i % 2 ? 49 : W - 49, g.rand(56, H - 42), 2);
    }
    p.heading += (Number(g.key('right')) - Number(g.key('left'))) * dt * 4.05;
    const touch = g.pointer.down;
    if (touch) p.heading = Math.atan2(g.pointer.y - p.y, g.pointer.x - p.x);
    if (g.key('up') || touch) {
      p.vx += Math.cos(p.heading) * dt * 300;
      p.vy += Math.sin(p.heading) * dt * 300;
    }
    const resistance = Math.exp(-dt * (g.key('down') ? 3.5 : .47));
    p.vx *= resistance; p.vy *= resistance; p.x += p.vx * dt; p.y += p.vy * dt; wrap(p);
    cooldown -= dt; immunity -= dt;
    if ((g.key('space') || touch) && cooldown <= 0 && dt) {
      const offsets = g.score < 600 ? [0] : g.score < 1600 ? [-.10, .10] : [-.19, 0, .19];
      for (const offset of offsets) {
        const a = p.heading + offset;
        shots.push({ x: p.x + Math.cos(a) * 19, y: p.y + Math.sin(a) * 19,
          vx: Math.cos(a) * 470 + p.vx * .5, vy: Math.sin(a) * 470 + p.vy * .5, life: 1.1 });
      }
      cooldown = .19; g.beep(380, .059, 'triangle', .035);
    }
    for (const r of rocks) { r.x += r.vx * dt; r.y += r.vy * dt; r.a += r.spin * dt; wrap(r, 44); }
    for (let i = shots.length - 1; i >= 0; i--) {
      const s = shots[i]; s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt; wrap(s);
      const index = rocks.findIndex(r => distance(s, r) < scale[r.size]);
      if (index !== -1) {
        const [r] = rocks.splice(index, 1);
        if (r.size) { rock(r.x - 9, r.y, r.size - 1); rock(r.x + 9, r.y, r.size - 1); }
        g.score += 60 + (2 - r.size) * 25; g.beep(174 + r.size * 60, .065, 'square', .028);
        next = g.time + 1;
      }
      if (index >= 0 || s.life <= 0) shots.splice(i, 1);
    }
    if (immunity <= 0 && rocks.some(r => distance(p, r) < scale[r.size] + 11)) {
      hp--; immunity = 1.45; g.beep(101, .18);
    }
    g.image('#0b142a', '#211638'); g.starlight(6);
    for (const r of rocks) {
      g.poly(r.points.map((f, i) => {
        const a = r.a + i * TAU / r.points.length, d = f * scale[r.size];
        return [r.x + Math.cos(a) * d, r.y + Math.sin(a) * d];
      }), '#4d3e63', '#c1a9d8');
    }
    for (const s of shots) g.glow('#85f6ed', 9, () => g.dot(s.x, s.y, 3, '#b6ffee'));
    if (immunity <= 0 || Math.floor(g.time * 12) % 2) drawShip(g, p.x, p.y, p.heading, '#a58afe');
    g.label('Wave ' + wave + '/' + total, 24, 29);
    g.label('Shields ' + '◆'.repeat(Math.max(0, hp)), W - 25, 29, '#c7e3f6', 19, 'right');
    if (hp <= 0) g.end('Ship lost', 'You reached wave ' + wave + '.');
    else if (dt && wave === total && !rocks.length && g.time >= next) { g.score += 450; g.end('Belt cleared', 'All asteroid waves are clear.', true); }
  };
}

function breakout(g) {
  const rows = 4 + g.level, columns = 11, bricks = [], drops = [];
  const tints = ['#be77ed', '#7d8bf7', '#66cbe9', '#72e1b4', '#f4ca7d', '#f4a88e', '#e785c0', '#9aaff9'];
  for (let row = 0; row < rows; row++) for (let col = 0; col < columns; col++) {
    if (row > 1 && (row + col + g.level) % 11 === 0) continue;
    bricks.push({ x: 61 + col * 77, y: 70 + row * 25, tint: tints[row % tints.length],
      hp: row < g.level / 2 ? 2 : 1, power: (row * 7 + col * 3 + g.level) % 13 === 0 });
  }
  let paddle = W / 2, ball, lives = 4, attached = true, bonus = 0;
  const deck = 491, r = 9;
  const reset = () => { ball = { x: paddle, y: deck - 14, vx: g.rand(-180, 180), vy: -(280 + g.level * 34) }; attached = true; };
  reset();
  return dt => {
    const size = (bonus > 0 ? 190 : 128) - g.level * 6;
    const steering = Number(g.key('right')) - Number(g.key('left'));
    if (steering) paddle += steering * dt * 430;
    else if (g.pointer.active) paddle = g.pointer.x;
    paddle = clamp(paddle, size / 2 + 11, W - size / 2 - 11);
    bonus -= dt;
    if (attached) {
      ball.x = paddle;
      if (g.action() || g.pointer.tap) attached = false;
    }
    if (!attached) {
      const step = dt / 3;
      for (let i = 0; i < 3; i++) {
        const ox = ball.x, oy = ball.y;
        ball.x += ball.vx * step; ball.y += ball.vy * step;
        if (ball.x < r || ball.x > W - r) { ball.x = clamp(ball.x, r, W - r); ball.vx *= -1; }
        if (ball.y < 47) { ball.y = 47; ball.vy = Math.abs(ball.vy); }
        if (ball.vy > 0 && oy <= deck && ball.y + r >= deck && Math.abs(ball.x - paddle) < size / 2 + r) {
          const speed = Math.min(650, Math.hypot(ball.vx, ball.vy) * 1.035);
          const angle = ((ball.x - paddle) / (size / 2)) * 1.05;
          ball.vx = Math.sin(angle) * speed; ball.vy = -Math.cos(angle) * speed; ball.y = deck - r - 1; g.beep(359);
        }
        const index = bricks.findIndex(b => inRect(ball, b.x - r, b.y - r, 71 + r * 2, 20 + r * 2));
        if (index === -1) continue;
        const b = bricks[index];
        if (ox < b.x - r || ox > b.x + 71 + r) ball.vx *= -1;
        else ball.vy *= -1;
        ball.x = ox; ball.y = oy;
        if (--b.hp <= 0) { if (b.power) drops.push({ x: b.x + 35, y: b.y }); bricks.splice(index, 1); g.score += 68; }
        g.beep(440 + b.y, .07, 'triangle', .04);
        break;
      }
      if (ball.y > H + 15) { lives--; reset(); g.beep(130, .16); }
    }
    for (let i = drops.length - 1; i >= 0; i--) {
      const d = drops[i]; d.y += 157 * dt;
      if (Math.abs(d.y - deck) < 14 && Math.abs(d.x - paddle) < size / 2) { bonus = 12; drops.splice(i, 1); g.beep(743); }
      else if (d.y > H + 20) drops.splice(i, 1);
    }
    g.image('#151337', '#281433'); g.grid(31, '#976ddd18');
    for (const b of bricks) {
      g.box(b.x, b.y, 71, 20, b.tint + (b.hp > 1 ? 'aa' : '78'), 4, b.tint);
      g.line(b.x + 6, b.y + 4, b.x + 64, b.y + 4, b.tint, 2);
      if (b.power) g.dot(b.x + 35, b.y + 10, 4, '#fdf6e1');
    }
    for (const d of drops) { g.dot(d.x, d.y, 10, '#74fbdc', '#eefff9', 2); g.label('+', d.x, d.y, '#242b39', 15, 'center'); }
    g.box(paddle - size / 2, deck, size, 12, bonus > 0 ? '#6de8ca' : '#8a73ec', 5, '#e2d5ff');
    g.glow('#f8d3ff', 13, () => g.dot(ball.x, ball.y, r, '#fff0fa'));
    g.label('Balls ' + lives, 23, 26);
    g.label('Bricks ' + bricks.length, W - 25, 26, '#f0d0fb', 18, 'right');
    if (attached) g.label('Space / tap to serve', W / 2, H - 18, '#d9c7ed', 15, 'center');
    if (lives <= 0) g.end('Last ball lost', 'You left ' + bricks.length + ' bricks standing.');
    else if (!bricks.length) { g.score += lives * 180; g.end('All bricks cleared', 'You cleared the wall with ' + lives + ' balls left.', true); }
  };
}

function missile(g) {
  const buildings = Array.from({ length: 6 }, (_, i) => ({ x: 79 + i * 161, alive: true, size: g.rand(45, 69) }));
  const falling = [], explosions = [], missiles = [];
  let spawned = 0, blocked = 0, hits = 0, spawn = .7, reload = 0;
  const target = 32 + g.level * 9;
  const pos = { x: 480, y: 499 };
  return dt => {
    spawn -= dt; reload -= dt;
    const m = g.move();
    const pointing = g.pointer.active && (!m.x && !m.y);
    pos.x = pointing ? g.pointer.x : pos.x + m.x * 340 * dt;
    pos.y = pointing ? g.pointer.y : pos.y + m.y * 340 * dt;
    pos.x = clamp(pos.x, 12, W - 12); pos.y = clamp(pos.y, 49, H - 67);
    if (spawn <= 0 && spawned < target) {
      const living = buildings.filter(b => b.alive);
      const b = g.pick(living);
      if (b) {
        const start = { x: g.rand(14, W - 14), y: 38 };
        const u = unit(b.x - start.x, H - 51 - start.y);
        const speed = g.rand(60, 95) + 15 * g.level + spawned * .9;
        falling.push({ ...start, sx: start.x, sy: start.y, vx: u.x * speed, vy: u.y * speed, target: b });
        spawned++; spawn = Math.max(.38, 1.06 - g.level * .065 - spawned * .012);
      }
    }
    if ((g.key('space') || g.pointer.down || g.pointer.tap) && reload <= 0 && dt) {
      const start = { x: W / 2, y: H - 33 };
      const d = distance(pos, start);
      missiles.push({ ...start, sx: start.x, sy: start.y, tx: pos.x, ty: pos.y, t: 0, tmax: Math.max(.10, d / 710) });
      reload = .21 + .022 * g.level; g.beep(435, .075, 'sine', .034);
    }
    for (let i = missiles.length - 1; i >= 0; i--) {
      const p = missiles[i]; p.t += dt;
      p.x = p.sx + (p.tx - p.sx) * p.t / p.tmax; p.y = p.sy + (p.ty - p.sy) * p.t / p.tmax;
      if (p.t >= p.tmax) { explosions.push({ x: p.tx, y: p.ty, time: 0 }); missiles.splice(i, 1); }
    }
    for (let i = explosions.length - 1; i >= 0; i--) { explosions[i].time += dt; if (explosions[i].time > .56) explosions.splice(i, 1); }
    const blastRadius = p => 6 + Math.sin(p.time / .56 * Math.PI) * (58 - g.level * 3);
    for (let i = falling.length - 1; i >= 0; i--) {
      const f = falling[i]; f.x += f.vx * dt; f.y += f.vy * dt;
      if (explosions.some(p => distance(p, f) < blastRadius(p))) {
        blocked++; falling.splice(i, 1); g.beep(490 + blocked % 6 * 56, .075);
      } else if (f.y >= H - 51) {
        if (f.target.alive) { f.target.alive = false; hits++; g.beep(110, .19); }
        falling.splice(i, 1);
      }
    }
    g.score = blocked * 115;
    g.image('#101638', '#2c1742'); g.starlight(3);
    for (let i = 0; i < 18; i++) g.box(i * 58 - 3, H - (130 + i * 17 % 66), 45, 200, '#271d45', 2);
    g.box(0, H - 39, W, 39, '#1a1630');
    for (const b of buildings) {
      g.box(b.x - 29, H - (b.alive ? b.size : 21), 58, b.alive ? b.size : 21, b.alive ? '#4c4a77' : '#4b2e54', 4, '#9c84bb');
      if (b.alive) for (let j = -19; j < 20; j += 11) g.line(b.x + j, H - 40, b.x + j, H - 17, '#98d4d4', 3);
    }
    for (const f of falling) { g.line(f.sx, f.sy, f.x, f.y, '#da609b8c', 2); g.dot(f.x, f.y, 6, '#ffa0b0', '#ffe1b4'); }
    for (const p of missiles) { g.line(p.sx, p.sy, p.x, p.y, '#6aace4', 2); g.dot(p.x, p.y, 4, '#b7f3ff'); }
    for (const p of explosions) {
      const r = blastRadius(p);
      g.glow('#6bfaff', 18, () => g.dot(p.x, p.y, r, '#78def448', '#95eefa', 2));
      for (let i = 0; i < 8; i++) g.dot(p.x + Math.cos(i * TAU / 8) * r * .74, p.y + Math.sin(i * TAU / 8) * r * .74, 2, '#d8fff3');
    }
    g.dot(pos.x, pos.y, 13, null, '#caf7ed', 1.5);
    g.label('Intercepted ' + blocked + '/' + target, 24, 28);
    g.label('Buildings ' + (buildings.length - hits) + '/' + buildings.length, W - 24, 28, '#d6c8f8', 19, 'right');
    if (hits >= buildings.length) g.end('City offline', 'You stopped ' + blocked + ' threats.');
    else if (dt && spawned === target && !falling.length) { g.score += (buildings.length - hits) * 200; g.end('City defended', (buildings.length - hits) + ' buildings survived.', true); }
  };
}

function frog(g) {
  const laneHeight = 41, top = 55, from = 10, columns = 15, stepX = 59, left = 65;
  const y = row => top + row * laneHeight + laneHeight / 2;
  const start = { x: left + 7 * stepX, row: from };
  const p = { ...start };
  const rows = Array.from({ length: 9 }, (_, i) => ({
    row: i + 1, river: i < 4, speed: (i % 2 ? -1 : 1) * (75 + g.level * 18 + i * 10),
    width: i < 4 ? 137 - g.level * 7 : 72 + g.level * 5, offset: g.rand(0, 240),
  }));
  const docks = Array.from({ length: 3 + +(g.level >= 3) }, (_, i) => ({ x: left + stepX * (i * 3 + 3), used: false }));
  let lives = 5, at = 0, safe = .6, peak = from;
  function reset(cost) { lives -= cost; Object.assign(p, start); safe = g.time + .6; peak = from; if (cost) g.beep(115, .15); }
  function hop(dx, dy) {
    const tx = p.x + dx * stepX, tr = p.row + dy;
    if (tx < 25 || tx > W - 25 || tr < 0 || tr > from) return;
    p.x = tx; p.row = tr;
    if (tr < peak) { g.score += 6; peak = tr; }
    g.beep(340 + (from - p.row) * 17, .06, 'triangle', .032);
  }
  return dt => {
    if (g.time >= at && dt) {
      const current = ['right', 'down', 'left', 'up'].findIndex(key => g.key(key) || g.pressed(key));
      const moves = [[1, 0], [0, 1], [-1, 0], [0, -1]];
      if (current >= 0) { hop(...moves[current]); at = g.time + .155; }
      else if (g.pointer.tap) {
        const dx = g.pointer.x - p.x, dy = g.pointer.y - y(p.row);
        if (Math.abs(dx) > Math.abs(dy)) hop(Math.sign(dx), 0);
        else hop(0, Math.sign(dy));
        at = g.time + .155;
      }
    }
    g.image('#112333', '#1c1836');
    g.box(0, top, W, laneHeight, '#29453f');
    g.box(0, top + laneHeight * from, W, laneHeight, '#29453f');
    for (const lane of rows) {
      const cy = y(lane.row), space = lane.river ? 217 : 256;
      g.box(0, cy - 20, W, laneHeight, lane.river ? '#19445f' : '#292944');
      g.line(0, cy + laneHeight / 2, W, cy + laneHeight / 2, '#a8bcf43c', 1);
      let onboard = false;
      for (let i = -1; i <= Math.ceil(W / space); i++) {
        const x = i * space + ((lane.offset + g.time * lane.speed) % space + space) % space;
        g.box(x, cy - 14, lane.width, 28, lane.river ? '#566d7c' : lane.row % 2 ? '#a2528c' : '#4e8aba', 6, lane.river ? '#92d2bd' : '#cfbcf0');
        if (lane.river) g.line(x + 6, cy + 3, x + lane.width - 6, cy + 3, '#9ad7b169', 2);
        else g.box(x + lane.width * .32, cy - 10, lane.width * .35, 20, '#221d37', 2);
        if (p.x < x + lane.width + 7 && p.x > x - 7 && p.row === lane.row) onboard = true;
      }
      if (dt && p.row === lane.row) {
        if (lane.river && onboard) p.x += lane.speed * dt;
        if (g.time > safe && (lane.river ? !onboard || p.x < 14 || p.x > W - 14 : onboard)) reset(1);
      }
    }
    for (const d of docks) {
      g.box(d.x - 32, top + 3, 65, 34, d.used ? '#2e726e' : '#1d7060', 7, d.used ? '#70f5c0' : '#80caae');
      if (d.used) g.dot(d.x, y(0), 10, '#adf8ac');
    }
    if (p.row === 0) {
      const berth = docks.find(d => !d.used && Math.abs(d.x - p.x) < 34);
      if (berth) { berth.used = true; g.score += 250; g.beep(650, .12); reset(0); }
      else reset(1);
    }
    g.dot(p.x, y(p.row), 10, '#a8e979', '#e4ffb1', 2);
    for (const dx of [-7, 7]) g.dot(p.x + dx, y(p.row) - 7, 4.3, '#d7f4a2', '#5a806a', 1);
    g.label('Lives ' + lives, 24, 27); g.label('Docks ' + docks.filter(d => d.used).length + '/' + docks.length, W - 24, 27, '#c8eddf', 19, 'right');
    if (lives <= 0) g.end('Crossing over', 'You reached ' + docks.filter(d => d.used).length + ' docks.');
    else if (docks.every(d => d.used)) { g.score += lives * 140; g.end('All docks filled', 'Every crossing is complete.', true); }
  };
}

function chaser(g) {
  const cols = 21, rows = 13, size = 32, ox = (W - cols * size) / 2, oy = 80;
  const maze = makeMaze(cols, rows, g.random);
  for (let i = 0; i < 23; i++) {
    const x = Math.floor(g.rand(2, cols - 2)), y = Math.floor(g.rand(2, rows - 2));
    if (!maze[y - 1][x] && !maze[y + 1][x] || !maze[y][x - 1] && !maze[y][x + 1]) maze[y][x] = 0;
  }
  const food = maze.map(row => row.map(v => v ? 0 : 1));
  const start = { x: 1, y: 1 }, point = (x, y) => [ox + x * size + size / 2, oy + y * size + size / 2];
  const p = { ...start };
  const homes = [{ x: cols - 2, y: rows - 2 }, { x: cols - 4, y: rows - 2 }, { x: cols - 2, y: rows - 4 }];
  const ghosts = homes.slice(0, g.level > 2 ? 3 : 2).map((home, i) => ({ ...home, home, tint: ['#ef77a8', '#74cded', '#e8a574'][i], next: 3 + i * .55 }));
  const living = [];
  food[1][1] = 0;
  food[rows - 2][1] = food[1][cols - 2] = food[7][11] = 2;
  // These three coordinates are odd maze cells and therefore open.
  let left = food.flat().filter(Boolean).length, total = left, dirX = 0, dirY = 0, tick = 0, power = 0, lives = 3, safe = 1;
  const steps = [[1, 0], [0, 1], [-1, 0], [0, -1]];
  for (let yy = 0; yy < rows; yy++) for (let xx = 0; xx < cols; xx++) if (!maze[yy][xx]) living.push({ x: xx, y: yy });
  return dt => {
    let dir = ['right', 'down', 'left', 'up'].findIndex(key => g.key(key) || g.pressed(key));
    if (dir < 0 && g.pointer.tap) {
      const [x, y] = point(p.x, p.y), dx = g.pointer.x - x, dy = g.pointer.y - y;
      dir = Math.abs(dx) > Math.abs(dy) ? dx > 0 ? 0 : 2 : dy > 0 ? 1 : 3;
    }
    if (dir >= 0) [dirX, dirY] = steps[dir];
    if (g.time >= tick && dt && (dirX || dirY)) {
      if (maze[p.y + dirY]?.[p.x + dirX] === 0) {
        p.x += dirX; p.y += dirY;
        if (food[p.y][p.x]) {
          if (food[p.y][p.x] === 2) { power = g.time + 6.5; g.beep(332, .16); }
          else if (left % 2 === 0) g.beep(420 + left % 6 * 20, .045, 'triangle', .026);
          food[p.y][p.x] = 0; left--; g.score += 14;
        }
      }
      tick = g.time + .13;
    }
    for (const e of ghosts) {
      if (g.time > e.next) {
        const objective = g.time < power ? e.home : g.random() < .83 ? p : g.pick(living);
        const move = routeStep(maze, e, objective);
        if (move) Object.assign(e, move);
        e.next = g.time + .30 - g.level * .022;
      }
      if (e.x !== p.x || e.y !== p.y || g.time < safe) continue;
      if (g.time < power) { g.score += 160; Object.assign(e, e.home); e.next = g.time + 2.4; }
      else {
        lives--; safe = g.time + 2; dirX = dirY = 0; Object.assign(p, start);
        ghosts.forEach(other => { Object.assign(other, other.home); other.next = g.time + 2.35; });
        g.beep(101, .21);
      }
    }
    g.image('#11132c', '#20173b');
    for (let row = 0; row < rows; row++) for (let col = 0; col < cols; col++) {
      const [x, y] = point(col, row);
      if (maze[row][col]) g.box(x - size / 2 + 1, y - size / 2 + 1, size - 2, size - 2, '#252751', 6, '#424b96');
      else if (food[row][col]) g.dot(x, y, food[row][col] === 2 ? 6 : 2.9, food[row][col] === 2 ? '#f6b4fc' : '#e7b9aa');
    }
    const [px, py] = point(p.x, p.y);
    if (g.time >= safe || Math.floor(g.time * 12) % 2) {
      g.dot(px, py, 12, '#f8d87b', '#ffeaa7');
      const a = Math.atan2(dirY, dirX), jaw = .18 + Math.abs(Math.sin(g.time * 18)) * .37;
      g.poly([[px, py], [px + Math.cos(a - jaw) * 17, py + Math.sin(a - jaw) * 17], [px + Math.cos(a + jaw) * 17, py + Math.sin(a + jaw) * 17]], '#161630');
    }
    for (const e of ghosts) {
      const [x, y] = point(e.x, e.y);
      g.box(x - 11, y - 12, 22, 24, g.time < power ? '#7d79df' : e.tint, 8, '#f9d5ff');
      g.dot(x - 4, y - 2, 2.8, '#1a1531'); g.dot(x + 4, y - 2, 2.8, '#1a1531');
    }
    g.label('Pellets ' + (total - left) + '/' + total, 24, 29);
    g.label('Lives ' + lives + (g.time < power ? '   •   POWER' : ''), W - 25, 29, '#f5d6ad', 19, 'right');
    if (lives <= 0) g.end('The ghosts caught you', 'You collected ' + (total - left) + ' pellets.');
    else if (!left) { g.score += lives * 200; g.end('Maze cleared', 'You collected every pellet.', true); }
  };
}

function centipede(g) {
  const cols = 25, cell = 35, floor = H - 47;
  const p = { x: W / 2, y: floor };
  const mushrooms = Array.from({ length: 32 + g.level * 4 }, () => ({
    x: 45 + cell * Math.floor(g.rand(0, cols)), y: 94 + cell * Math.floor(g.rand(0, 10)), hp: 3,
  })).filter((m, i, a) => a.findIndex(x => distance(x, m) < 12) === i);
  const segments = [], bolts = [];
  const stages = 3 + Math.floor(g.level / 2);
  let wave = 0, spawn = .6, lives = 4, safe = 0, fire = 0;
  return dt => {
    if (!segments.length && g.time > spawn && wave < stages) {
      wave++;
      for (let i = 0; i < 6 + wave * 2; i++) segments.push({ x: -35 - i * 29, y: 69, dx: 1, dy: 1, head: !i });
    }
    const m = g.move();
    p.x = clamp(p.x + m.x * dt * 285, 24, W - 23); p.y = clamp(p.y + m.y * dt * 246, 359, H - 19);
    if (g.pointer.down) { p.x += (clamp(g.pointer.x, 22, W - 22) - p.x) * Math.min(1, dt * 12); p.y += (clamp(g.pointer.y, 359, H - 19) - p.y) * Math.min(1, dt * 12); }
    fire -= dt; safe -= dt;
    if ((g.key('space') || g.pointer.down) && fire <= 0) { fire = .14; bolts.push({ x: p.x, y: p.y - 13 }); g.beep(340, .052, 'triangle', .03); }
    for (const s of segments) {
      const speed = 112 + wave * 22 + g.level * 14;
      const x = s.x + dt * speed * s.dx;
      const wall = s.dx < 0 ? x < 20 : x > W - 20;
      if (wall || mushrooms.some(m => Math.abs(s.y - m.y) < 19 && Math.abs(x - m.x) < 15)) {
        s.dx *= -1; s.y += s.dy * cell;
        if (s.y > H - 38 || s.y < 75) s.dy *= -1;
      } else s.x = x;
      if (safe <= 0 && distance(s, p) < 26) { lives--; safe = 1.2; g.beep(109, .18); }
    }
    for (let i = bolts.length - 1; i >= 0; i--) {
      const b = bolts[i]; b.y -= 595 * dt;
      const s = segments.findIndex(s => distance(s, b) < 18);
      const m = mushrooms.findIndex(m => distance(m, b) < 14);
      if (s >= 0) {
        const [k] = segments.splice(s, 1); g.score += k.head ? 140 : 80; spawn = g.time + 1;
        if (segments[s]) { segments[s].head = true; segments[s].dx *= -1; segments[s].y += 19; }
        g.beep(533, .07);
      } else if (m >= 0 && --mushrooms[m].hp <= 0) { mushrooms.splice(m, 1); g.score += 25; }
      if (s >= 0 || m >= 0 || b.y < 33) bolts.splice(i, 1);
    }
    g.image('#0d1f32', '#241944'); g.grid(35, '#a997ff15');
    for (const m of mushrooms) {
      g.box(m.x - 4, m.y, 8, 12, '#b2a0e4', 3);
      g.dot(m.x, m.y - 5, 11, ['#b37997', '#bc82c1', '#c38ceb'][m.hp - 1], '#ead3f8');
    }
    for (const s of segments) {
      g.dot(s.x, s.y, 12, s.head ? '#8eea8a' : '#5ab68a', '#a2eabe', 2);
      if (s.head) { g.dot(s.x + s.dx * 6, s.y - 4, 2, '#14203b'); g.dot(s.x + s.dx * 6, s.y + 4, 2, '#14203b'); }
    }
    for (const b of bolts) g.line(b.x, b.y, b.x, b.y + 10, '#8deaf7', 3);
    if (safe <= 0 || Math.floor(g.time * 12) % 2) drawShip(g, p.x, p.y, -Math.PI / 2, '#b489fa', .84);
    g.label('Wave ' + wave + '/' + stages, 24, 26); g.label('Lives ' + lives, W - 24, 26, '#e0d0fa', 19, 'right');
    if (lives <= 0) g.end('Garden overrun', 'You reached wave ' + wave + '.');
    else if (dt && wave === stages && !segments.length) { g.score += 450; g.end('Garden clear', 'You defeated all the centipedes.', true); }
  };
}

export const retro = {
  asteroids: mode('← / → turn, ↑ thrust, ↓ brake, Space fires. Or hold the screen to steer and fire.', asteroids, ['left', 'up', 'right'], [['space', 'Fire']]),
  breakout: mode('Move the paddle with your pointer or ← / →. Space or tap serves.', breakout, horizontal, [['space', 'Serve']]),
  missile: mode('Aim and hold the pointer to launch. Or aim with the arrows and hold Space.', missile, directions, [['space', 'Launch']]),
  frog: mode('Arrows / WASD, onscreen arrows, or tap in the direction you want to hop.', frog, directions),
  chaser: mode('Arrows / WASD, onscreen arrows, or tap a direction. Watch for the ghosts.', chaser, directions),
  centipede: mode('Move with arrows / WASD and hold Space to fire. Or drag to move and fire.', centipede, directions, [['space', 'Fire']]),
};
