export const directions = ['left', 'up', 'down', 'right'];
export const horizontal = ['left', 'right'];
export const vertical = ['up', 'down'];

export function mode(hint, create, directions = [], buttons = [], typing = false) {
  return { controls: { hint, directions, buttons, typing }, create };
}
