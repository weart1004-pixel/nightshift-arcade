const $ = selector => document.querySelector(selector);
const topics = {
  general: 'Chat with other Nightshift Arcade players.',
  'looking-for-group': 'Find a teammate or share your game room code.',
  'game-talk': 'Talk games, trade tips, and compare high scores.'
};
const clocks = new Intl.DateTimeFormat(undefined, {month:'short', day:'numeric', hour:'numeric', minute:'2-digit'});
let channel, revision = 0, lastId, pending = false, retry;
const drafts = new Map();
try { $('#nickname').value = localStorage.getItem('nightshift-comms-name') || ''; } catch {}
function menu(open) {
  $('.shell').classList.toggle('open', open);
  $('.menu').setAttribute('aria-expanded', String(open));
}
$('.menu').onclick = () => menu(!$('.shell').classList.contains('open'));
function row(item) {
  const node = document.createElement('article');
  node.className = 'row';
  node.innerHTML = '<span class="avatar" aria-hidden="true"></span><div class="post"><strong></strong><time></time><p></p></div>';
  const avatar = node.querySelector('.avatar');
  avatar.textContent = Array.from(item.nickname)[0].toUpperCase();
  let hue = 0;
  for (const c of item.nickname) hue = (hue * 31 + c.codePointAt(0)) % 360;
  avatar.style.backgroundColor = 'hsl(' + hue + ' 46% 39%)';
  node.querySelector('strong').textContent = item.nickname;
  node.querySelector('time').textContent = clocks.format(item.created);
  node.querySelector('p').textContent = item.message;
  return node;
}
async function refresh(forceBottom = false) {
  const version = ++revision;
  try {
    const result = await fetch('/api/comms?channel=' + channel, {cache:'no-store'});
    if (!result.ok) throw Error();
    const {messages} = await result.json();
    if (version !== revision) return;
    $('.status').textContent = 'Connected';
    const latest = messages.at(-1)?.id ?? 0, feed = $('.feed');
    if (lastId !== latest) {
      const nearBottom = lastId === undefined || feed.scrollHeight - feed.scrollTop - feed.clientHeight < 75;
      lastId = latest;
      $('#messages').replaceChildren(...messages.map(row));
      if (nearBottom || forceBottom) feed.scrollTop = feed.scrollHeight;
    }
  } catch { if (version === revision) $('.status').textContent = 'Reconnecting…'; }
}
function select(name) {
  if (channel) drafts.set(channel, $('#message').value);
  channel = name;
  $('h1').textContent = name;
  $('.intro h2').textContent = 'Welcome to #' + name;
  $('.intro p').textContent = topics[name];
  $('#message').placeholder = 'Message #' + name;
  $('#message').value = drafts.get(name) || '';
  $('#error').textContent = '';
  $('#messages').replaceChildren();
  document.querySelectorAll('[data-channel]').forEach(b => b.setAttribute('aria-current', String(b.dataset.channel === name)));
  lastId = undefined;
  $('.status').textContent = 'Connecting…';
  menu(false);
  refresh(true);
}
document.querySelectorAll('[data-channel]').forEach(b => b.onclick = () => select(b.dataset.channel));
$('form').onsubmit = async event => {
  event.preventDefault();
  const nickname = $('#nickname').value.trim(), message = $('#message').value.trim();
  if (pending || !nickname || !message) return;
  const target = channel, draft = $('#message').value;
  const signature = JSON.stringify([target, nickname, message]);
  if (retry?.signature !== signature) retry = {signature, requestId:crypto.randomUUID()};
  pending = true;
  $('.send').disabled = true;
  $('#error').textContent = '';
  try {
    const result = await fetch('/api/comms', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({channel:target,nickname,message,requestId:retry.requestId})});
    if (!result.ok) throw Error();
    retry = null;
    try { localStorage.setItem('nightshift-comms-name', nickname); } catch {}
    if (channel === target && $('#message').value === draft) $('#message').value = '';
    if (drafts.get(target) === draft) drafts.delete(target);
    if (channel === target) await refresh(true);
  } catch { $('#error').textContent = 'Couldn’t send to #' + target + '. Your draft is saved here. Try again.'; }
  finally { pending = false; $('.send').disabled = false; }
};
select('general');
setInterval(() => { if (!document.hidden) refresh(); }, 3000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
