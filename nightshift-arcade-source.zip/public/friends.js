(() => {
  const el=name=>document.getElementById('friends-'+name);
  const key='nightshift-friends-device-v1';
  const dialog=el('dialog');
  let serial=0,mutating=false,lastLists='';
  function identity(create){
    let token=localStorage.getItem(key);
    if(!token&&create){
      const bytes=crypto.getRandomValues(new Uint8Array(32));
      token=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
      localStorage.setItem(key,token);
    }
    return token;
  }
  function render(data){
    el('setup').hidden=!data.needsProfile;
    el('ready').hidden=!!data.needsProfile;
    if(data.needsProfile){el('open').textContent='Friends';return;}
    const {me,links}=data;
    el('code').textContent=me.code;
    const incoming=links.filter(l=>!l.accepted&&l.sender!==me.code);
    el('open').textContent=incoming.length?'Friends ('+incoming.length+')':'Friends';
    const signature=JSON.stringify([me.code,links]);
    if(lastLists===signature)return;
    lastLists=signature;
    const sections=document.createDocumentFragment();
    for(const [label,items,actions,empty] of [
      ['Requests received',incoming,[['Accept','accept'],['Decline','decline']],'No incoming requests.'],
      ['Your friends',links.filter(l=>l.accepted),[['Remove','remove']],'Your accepted friends will appear here.'],
      ['Requests sent',links.filter(l=>!l.accepted&&l.sender===me.code),[['Cancel','cancel']],'No pending requests.']
    ]){
      const section=document.createElement('section'),title=document.createElement('h3');
      title.textContent=label+' ('+items.length+')';section.append(title);
      if(!items.length){const msg=document.createElement('small');msg.textContent=empty;section.append(msg);}
      for(const item of items){
        const row=document.createElement('div'),name=document.createElement('span'),code=document.createElement('small');
        row.className='friend-row';name.textContent=item.nickname;code.textContent=item.code;name.append(code);row.append(name);
        for(const [text,action] of actions){
          const button=document.createElement('button');button.textContent=text;
          button.setAttribute('aria-label',text+' '+item.nickname);
          button.onclick=()=>change(action,{target:item.code});row.append(button);
        }
        section.append(row);
      }
      sections.append(section);
    }
    el('lists').replaceChildren(sections);
  }
  async function change(action,extra={},quiet=false){
    if(mutating)return;
    const write=action!=='list',version=++serial;
    if(write)mutating=true;
    try{
      const token=identity(write);
      if(!token){render({needsProfile:true});return;}
      const r=await fetch('/api/friends',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},cache:'no-store',body:JSON.stringify({action,...extra})});
      const data=await r.json();if(version!==serial)return;
      if(!r.ok)throw Error(data.error||'Could not update friends.');
      render(data);
      if(!quiet)el('status').textContent=({profile:'Your code is ready to share.',send:'Request sent.',accept:'Friend added.',decline:'Request declined.',cancel:'Request canceled.',remove:'Friend removed.'})[action]||'';
      if(action==='send')el('target').value='';
    }catch(e){if(version===serial&&(!quiet||dialog.open))el('status').textContent=e.name==='SecurityError'?'Allow browser storage to keep your friend profile.':e.message||'Could not connect.';}
    finally{if(write)mutating=false;}
  }
  el('open').onclick=()=>{
    dialog.showModal();el('status').textContent='';
    if(!el('nick').value)el('nick').value=document.getElementById('nickname').value;
    change('list');
  };
  el('close').onclick=()=>dialog.close();
  el('create').onclick=()=>{const nickname=el('nick').value.trim();if(nickname)change('profile',{nickname});else{el('status').textContent='Enter a nickname first.';el('nick').focus();}};
  el('send').onclick=()=>change('send',{target:el('target').value.replace(/[\s-]/g,'').toUpperCase()});
  el('copy').onclick=async()=>{try{await navigator.clipboard.writeText(el('code').textContent);el('status').textContent='Friend code copied.';}catch{el('status').textContent='Share the code shown above.';}};
  for(const [input,button] of [['nick','create'],['target','send']])el(input).onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();el(button).click();}};
  function sync(){if(!document.hidden)change('list',{},true);}
  sync();setInterval(sync,7000);document.addEventListener('visibilitychange',sync);
})();
