const paths = {
  logo: '<path d="M13.6 2.8 5 13.9h6.5l-1 7.3 8.7-11.3h-6.5l.9-7.1Z" fill="currentColor" stroke-width="1.5"/><path d="M4 6v4M2 8h4m15 7v5m-2.5-2.5h5"/>',
  ghost: '<path d="M3 12a9 9 0 0 1 18 0v8l-3-2-3 2-3-2-3 2-3-2-3 2z"/><path d="M9 11v2m6-2v2"/>',
  bolt: '<path d="m13.4 2-9 12h6.7L10 22l9.7-12h-6.8l.5-8z"/>',
  orbit: '<ellipse cx="12" cy="12" rx="10.5" ry="4.6" transform="rotate(-35 12 12)"/><circle cx="12" cy="12" r="2.5" fill="currentColor"/><circle cx="19.2" cy="6.5" r="1.8" fill="currentColor"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.3"/><path d="M12 1v4m0 14v4M1 12h4m14 0h4"/>',
  coins: '<ellipse cx="9" cy="7" rx="6" ry="3.6"/><path d="M3 7v4.5c0 1.9 2.7 3.5 6 3.5h.8M3 11.6v4.2c0 2 2.7 3.6 6 3.6h1"/><ellipse cx="16.5" cy="13" rx="4.5" ry="2.8"/><path d="M12 13v5c0 1.6 2 2.8 4.5 2.8s4.5-1.2 4.5-2.8v-5"/>',
  puzzle: '<path d="M4 8h5V6a2.5 2.5 0 1 1 5 0v2h5v5h-1.2a2.3 2.3 0 0 0 0 4.6H19V21H4v-4.2h1.4a2.3 2.3 0 0 0 0-4.6H4z"/>',
  gamepad: '<path d="M7 7h10c2.5 0 3.6 1.7 4.2 4.4l.8 4c.7 3.2-2.1 4.4-4.2 2.3l-2.2-2.2H8.4l-2.3 2.2C4 19.8 1.2 18.6 2 15.4l.8-4C3.4 8.7 4.5 7 7 7zM7 10v4m-2-2h4"/><path d="M16 11v.01m3 2v.01" stroke-width="3"/>',
  ball: '<circle cx="12" cy="12" r="9.2"/><path d="m12 8 3.8 2.7-1.5 4.4H9.7l-1.5-4.4L12 8V3m3.8 7.7 5-1.5m-6.5 5.9 3 4.7m-7.6-4.7-3 4.7m1.5-9.1-5-1.5"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.4"/><path d="m16 16 4.4 4.4"/>',
  shuffle: '<path d="M3 6h3c4.5 0 6.5 12 11 12h4m-4-4 4 4-4 4M3 18h3c1.2 0 2.2-.9 3.1-2.1M14.2 8.2C15 6.9 16 6 17.5 6H21m-4-4 4 4-4 4"/>',
  heart: '<path d="M20.6 5.8a4.7 4.7 0 0 0-6.7 0L12 7.6l-1.9-1.8a4.7 4.7 0 0 0-6.7 6.7l1.8 1.9 6.8 6.4 6.8-6.4 1.8-1.9a4.7 4.7 0 0 0 0-6.7z"/>',
  arrow: '<path d="M4 12h15m-5-5 5 5-5 5"/>',
  up: '<path d="M12 20V4m-5 5 5-5 5 5"/>',
  down: '<path d="M12 4v16m-5-5 5 5 5-5"/>',
  left: '<path d="M20 12H4m5-5-5 5 5 5"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
  sort: '<path d="M4 6h16M4 12h11M4 18h6"/>',
  play: '<path d="m8 4 12 8-12 8z" fill="currentColor"/>',
  pause: '<path d="M9 5v14m6-14v14" stroke-width="3.2"/>',
  restart: '<path d="M4 11a8.2 8.2 0 1 1 2 6.5M4 4v7h7"/>',
  mute: '<path d="M4 9v6h4l5 4V5L8 9zm13 1 4 4m0-4-4 4"/>',
  volume: '<path d="M4 9v6h4l5 4V5L8 9zm12-.6a5 5 0 0 1 0 7.2m2.5-9.6a8 8 0 0 1 0 12"/>',
};

export const icon = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true">${paths[name] || ''}</svg>`;
export const iconSpan = name => `<span data-icon="${name}" aria-hidden="true">${icon(name)}</span>`;
