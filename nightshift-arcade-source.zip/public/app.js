import { categories, games, gameById, browsingOrder } from './catalog.js';
import { icon, iconSpan } from './icons.js';
import { createScene, newInput, W, H } from './games/engine.js';
import { modes } from './games/index.js';

const element = id => document.getElementById(id);
const search = element('search');
const grid = element('game-grid');
const genreGrid = element('genres');
const sort = element('sort');
const player = element('player');
const canvas = element('canvas');
const overlay = element('game-overlay');
const overlayAction = element('overlay-action');
const controls = element('touch-controls');
const format = new Intl.NumberFormat();

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(`nightshift-${key}`)) ?? fallback; }
  catch { return fallback; }
}
function save(key, value) {
  try { localStorage.setItem(`nightshift-${key}`, JSON.stringify(value)); }
  catch { /* Play is available when browser storage is disabled. */ }
}

const favorites = new Set(load('favorites', []));
const records = load('records', {});
const state = { page: 'discover', category: '', query: '', limit: 12, sort: 'featured' };
let muted = load('muted', true);
let audioContext;
let session;
let returnFocus;

document.querySelectorAll('[data-icon]').forEach(node => { node.innerHTML = icon(node.dataset.icon); });
genreGrid.innerHTML = categories.map(category => `
  <button type="button" class="genre" data-category="${category.id}" style="--genre:${category.color}" aria-pressed="false">
    <span class="genre-icon">${iconSpan(category.icon)}</span>
    <span class="genre-name">${category.name}</span>
    <span class="genre-count">${category.count} games</span>
  </button>`).join('');

const esc = value => String(value).replace(/[&<>"']/g, char => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]
));

function card(game, index) {
  const favorite = favorites.has(game.id);
  const hue = game.level ? ((game.level % 2 ? 1 : -1) * (9 + game.level * 7)) : 0;
  return `<article class="card" style="--card-color:${game.category.color};--hue:${hue}deg">
    <button type="button" class="card-link" aria-label="Play ${esc(game.title)}" data-play="${game.id}">
      <span class="card-art">
        <img src="${game.image}" alt="" ${index < 4 ? '' : 'loading="lazy"'} width="540" height="360" decoding="async">
        <span class="card-play">${iconSpan('play')}</span>
      </span>
      <span class="card-caption">
        <span class="card-title">${esc(game.title)}</span>
        <span class="card-meta"><i></i> ${esc(game.type)} <span aria-hidden="true">·</span> ${game.difficulty}</span>
      </span>
    </button>
    <button type="button" class="favorite" data-favorite="${game.id}" aria-pressed="${favorite}"
      aria-label="${favorite ? 'Remove' : 'Save'} ${esc(game.title)} ${favorite ? 'from' : 'to'} favorites">
      ${iconSpan('heart')}
    </button>
  </article>`;
}

function getVisible() {
  const words = state.query.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
  const list = browsingOrder.filter(game => {
    if (state.page === 'favorites' && !favorites.has(game.id)) return false;
    if (state.category && game.category.id !== state.category) return false;
    const terms = `${game.title} ${game.category.name} ${game.type} ${game.description}`.toLocaleLowerCase();
    return words.every(word => terms.includes(word));
  });
  if (state.sort === 'name') list.sort((a, b) => a.title.localeCompare(b.title));
  if (state.sort === 'played') list.sort((a, b) => (records[b.id]?.played || 0) - (records[a.id]?.played || 0));
  if (state.sort === 'best') list.sort((a, b) => (records[b.id]?.best || 0) - (records[a.id]?.best || 0));
  return list;
}

function renderLibrary() {
  const result = getVisible();
  const category = categories.find(entry => entry.id === state.category);
  const title = state.page === 'favorites' ? 'Favorites' : category ? category.name : state.query.trim() ? 'Search results' : 'All games';
  element('library-title').textContent = title;
  element('game-count').textContent = `${result.length} ${result.length === 1 ? 'game' : 'games'}`;
  element('clear-filter').hidden = !category && !state.query.trim();
  element('empty').hidden = Boolean(result.length);
  element('show-more').hidden = result.length <= state.limit;
  grid.innerHTML = result.slice(0, state.limit).map(card).join('');
  if (!result.length) {
    const noFavorites = state.page === 'favorites' && !state.query.trim();
    element('empty-title').textContent = noFavorites ? 'No favorites yet' : 'No games found';
    element('empty-message').textContent = noFavorites ? 'Tap the heart on a game to save it here.' : 'Try a different title, keyword, or category.';
  }
  document.querySelectorAll('[data-nav]').forEach(node => {
    if (node.dataset.nav === state.page) node.setAttribute('aria-current', 'page');
    else node.removeAttribute('aria-current');
  });
  genreGrid.querySelectorAll('[data-category]').forEach(node =>
    node.setAttribute('aria-pressed', String(node.dataset.category === state.category)));
}

function scrollLibrary() { element('library').scrollIntoView({ block: 'start' }); }

function navigate(page, scroll = true) {
  state.page = page;
  state.category = '';
  state.query = '';
  state.limit = 12;
  search.value = '';
  const hash = `#${page}`;
  if (location.hash !== hash) history.pushState(null, '', hash);
  renderLibrary();
  if (scroll) {
    if (page === 'discover') window.scrollTo({ top: 0, behavior: 'smooth' });
    else if (page === 'packs') element('packs').scrollIntoView({ block: 'start' });
    else scrollLibrary();
  }
}

function readLocation() {
  const page = ['library', 'favorites', 'packs'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'discover';
  navigate(page, Boolean(location.hash));
}
window.addEventListener('popstate', readLocation);
if (location.hash) readLocation();
else renderLibrary();

document.addEventListener('click', event => {
  const nav = event.target.closest('a[href^="#"]');
  if (nav) {
    event.preventDefault();
    navigate(nav.getAttribute('href').slice(1));
    return;
  }
  const play = event.target.closest('[data-play]');
  if (play) {
    openGame(gameById.get(play.dataset.play), play);
    return;
  }
  const heart = event.target.closest('[data-favorite]');
  if (!heart) return;
  const id = heart.dataset.favorite;
  const active = !favorites.has(id);
  if (active) favorites.add(id);
  else favorites.delete(id);
  save('favorites', [...favorites]);
  if (state.page === 'favorites' && !active) {
    renderLibrary();
    (grid.querySelector('button') || element('empty-reset')).focus({ preventScroll: true });
  } else {
    heart.setAttribute('aria-pressed', String(active));
    heart.setAttribute('aria-label', `${active ? 'Remove' : 'Save'} ${gameById.get(id).title} ${active ? 'from' : 'to'} favorites`);
  }
});

genreGrid.addEventListener('click', event => {
  const tile = event.target.closest('[data-category]');
  if (!tile) return;
  state.page = 'library';
  state.category = state.category === tile.dataset.category ? '' : tile.dataset.category;
  state.query = '';
  search.value = '';
  state.limit = 12;
  renderLibrary();
  scrollLibrary();
});

element('all-categories').addEventListener('click', () => navigate('library'));
element('empty-reset').addEventListener('click', () => navigate('library'));
element('clear-filter').addEventListener('click', () => navigate(state.page === 'favorites' ? 'favorites' : 'library'));
element('show-more').addEventListener('click', () => {
  const previous = state.limit;
  state.limit += 24;
  renderLibrary();
  const next = grid.children[previous]?.querySelector('button');
  if (next) next.focus({ preventScroll: true });
});
sort.addEventListener('change', () => {
  state.sort = sort.value;
  state.limit = 12;
  renderLibrary();
});
search.addEventListener('input', () => {
  const shouldScroll = !state.query.trim() && search.value.trim();
  state.query = search.value;
  state.limit = 12;
  if (state.page === 'discover') state.page = 'library';
  renderLibrary();
  if (shouldScroll) scrollLibrary();
});
search.addEventListener('keydown', event => {
  if (event.key === 'Enter') { scrollLibrary(); search.blur(); }
  if (event.key === 'Escape') { search.value = ''; search.dispatchEvent(new Event('input')); search.blur(); }
});
document.addEventListener('keydown', event => {
  if (event.key === '/' && !player.open && !event.ctrlKey && !event.metaKey && !event.altKey && event.target !== search) {
    event.preventDefault();
    search.focus();
  }
  if (player.open && event.key.toLowerCase() === 'p' && session?.status === 'paused' && !session.typing && !event.repeat) {
    event.preventDefault();
    event.stopPropagation();
    startSession();
  }
});
element('random').addEventListener('click', event => {
  const selection = getVisible();
  const choices = selection.length ? selection : games;
  openGame(choices[Math.floor(Math.random() * choices.length)], event.currentTarget);
});

function unlockAudio() {
  if (muted || !window.AudioContext) return;
  try {
    audioContext ??= new AudioContext();
    if (audioContext.state === 'suspended') audioContext.resume().catch(() => {});
  } catch { /* Web Audio is optional. */ }
}
function beep(frequency = 440, length = .09, type = 'sine', volume = .07) {
  if (muted || !audioContext || audioContext.state !== 'running') return;
  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();
  const now = audioContext.currentTime;
  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, now);
  gain.gain.setValueAtTime(.001, now);
  gain.gain.exponentialRampToValueAtTime(volume, now + .015);
  gain.gain.exponentialRampToValueAtTime(.001, now + Math.max(.025, length));
  oscillator.connect(gain).connect(audioContext.destination);
  oscillator.start(now);
  oscillator.stop(now + Math.max(.025, length));
}
function renderAudio() {
  const button = element('audio');
  button.firstElementChild.innerHTML = icon(muted ? 'mute' : 'volume');
  button.setAttribute('aria-label', muted ? 'Turn sound on' : 'Mute sound');
  button.setAttribute('aria-pressed', String(!muted));
}

function gameControls(config, input) {
  controls.replaceChildren();
  const directionMap = { left: '←', right: '→', up: '↑', down: '↓' };
  const buttons = [...(config.directions || []).map(key => [key, directionMap[key], `Move ${key}`]), ...(config.buttons || [])];
  for (const [key, name, accessible = name] of buttons) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = name;
    button.setAttribute('aria-label', accessible);
    button.addEventListener('pointerdown', event => {
      event.preventDefault();
      button.setPointerCapture?.(event.pointerId);
      input.setButton(key, true);
    });
    for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
      button.addEventListener(type, () => input.setButton(key, false));
    }
    button.addEventListener('click', event => {
      if (event.detail === 0) { input.setButton(key, true); input.setButton(key, false); }
    });
    controls.append(button);
  }
}

function openGame(game, trigger) {
  if (!game || player.open) return;
  returnFocus = trigger;
  element('player-title').textContent = game.title;
  element('player-category').textContent = game.type;
  element('player-category').style.color = game.category.color;
  canvas.setAttribute('aria-label', `${game.title} game screen`);
  player.showModal();
  resetSession(game, false);
}

function showOverlay(title, message, callToAction) {
  element('overlay-title').textContent = title;
  element('overlay-message').textContent = message;
  overlayAction.lastElementChild.textContent = callToAction;
  overlay.hidden = false;
  element('pause').firstElementChild.innerHTML = icon('play');
  element('pause').setAttribute('aria-label', 'Resume game');
  overlayAction.focus({ preventScroll: true });
}

function updateScore(score) {
  const integer = Math.max(0, Math.floor(score));
  if (integer === session.displayedScore) return;
  session.displayedScore = integer;
  element('score').textContent = format.format(integer);
}

function saveRun(current) {
  if (!current.started) return;
  const previous = records[current.game.id] || { best: 0 };
  records[current.game.id] = { best: Math.max(previous.best, current.displayedScore), played: Date.now() };
  save('records', records);
  element('best').textContent = format.format(records[current.game.id].best);
}

function fitGameCanvas() {
  const width = canvas.clientWidth;
  if (!width) return;
  const scale = Math.min(2, Math.max(1, width * (window.devicePixelRatio || 1) / W));
  const pixels = Math.round(W * scale), rows = Math.round(H * scale);
  if (canvas.width !== pixels || canvas.height !== rows) {
    canvas.width = pixels;
    canvas.height = rows;
    canvas.getContext('2d').setTransform(pixels / W, 0, 0, rows / H, 0, 0);
  }
}

function resetSession(game, autoStart) {
  stopSession();
  const definition = modes[game.mode];
  const config = definition.controls;
  fitGameCanvas();
  const input = newInput(canvas, config, togglePause);
  const current = { game, input, status: 'ready', typing: config.typing, started: false, displayedScore: -1, frame: 0, last: 0 };
  session = current;
  const scene = createScene(canvas, game, input, beep, (title, message, won) => {
    if (current.status !== 'playing') return;
    updateScore(scene.score);
    current.status = 'ended';
    input.setEnabled(false);
    saveRun(current);
    element('pause').disabled = true;
    showOverlay(title, message, 'Play again');
    beep(won ? 720 : 164, .2, 'triangle');
  });
  current.scene = scene;
  current.tick = definition.create(scene);
  element('control-hint').textContent = config.hint;
  element('pause').title = config.typing ? 'Pause' : 'Pause (P)';
  element('best').textContent = format.format(records[game.id]?.best || 0);
  element('pause').disabled = true;
  updateScore(0);
  renderAudio();
  gameControls(config, input);
  current.tick(0);
  showOverlay(game.title, game.description, 'Start game');
  if (autoStart) startSession();
}

function loop(now) {
  const current = session;
  if (!current || current.status !== 'playing') return;
  const dt = current.last ? Math.min(.035, (now - current.last) / 1000) : 0;
  current.last = now;
  current.scene.time += dt;
  current.tick(dt);
  current.input.clearFrame();
  updateScore(current.scene.score);
  if (current.status === 'playing') current.frame = requestAnimationFrame(loop);
}

function startSession() {
  if (!session) return;
  if (session.status === 'ended') { resetSession(session.game, true); return; }
  if (session.status === 'playing') return;
  fitGameCanvas();
  unlockAudio();
  session.status = 'playing';
  session.started = true;
  session.last = 0;
  overlay.hidden = true;
  element('pause').disabled = false;
  element('pause').firstElementChild.innerHTML = icon('pause');
  element('pause').setAttribute('aria-label', 'Pause game');
  session.input.setEnabled(true);
  canvas.focus({ preventScroll: true });
  session.frame = requestAnimationFrame(loop);
}

function togglePause() {
  if (session?.status === 'paused') { startSession(); return; }
  if (session?.status !== 'playing') return;
  cancelAnimationFrame(session.frame);
  session.status = 'paused';
  session.input.setEnabled(false);
  showOverlay('Paused', 'Resume when you’re ready.', 'Resume game');
}

function stopSession() {
  if (!session) return;
  cancelAnimationFrame(session.frame);
  session.input.dispose();
  saveRun(session);
  session = undefined;
}

overlayAction.addEventListener('click', startSession);
element('pause').addEventListener('click', togglePause);
element('restart').addEventListener('click', () => {
  if (session) resetSession(session.game, true);
});
element('audio').addEventListener('click', () => {
  muted = !muted;
  save('muted', muted);
  unlockAudio();
  renderAudio();
  if (session?.status === 'playing') canvas.focus({ preventScroll: true });
});
element('close-player').addEventListener('click', () => player.close());
player.addEventListener('close', () => {
  stopSession();
  controls.replaceChildren();
  if (state.sort === 'played' || state.sort === 'best') renderLibrary();
  if (returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
  else search.focus({ preventScroll: true });
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden && session?.status === 'playing') togglePause();
});

// Update a live game when fullscreen or device rotation changes its display size.
window.addEventListener('resize', () => {
  if (session?.status === 'playing') fitGameCanvas();
});
