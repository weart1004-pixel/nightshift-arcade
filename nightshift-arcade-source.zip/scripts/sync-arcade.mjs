import { readFile, writeFile } from "node:fs/promises";

const publicDir = new URL("../public/", import.meta.url);
const quizPath = new URL("blooket-live-owner.html", publicDir);
const packPath = new URL("gtag-fnaf-blooket-hd.html", publicDir);
const [quiz, pack, home] = await Promise.all([
  readFile(quizPath, "utf8"),
  readFile(packPath, "utf8"),
  readFile(new URL("index.html", publicDir), "utf8"),
]);

// Embed the whole game so the downloadable three-game pack also works offline.
const marker = /^const embeddedQuizDocument=.*;$/gm;
if (Array.from(pack.matchAll(marker)).length !== 1) {
  throw new Error("The three-game pack must contain one embedded Blooket document.");
}
const literal = JSON.stringify(quiz)
  .replaceAll("<", "\\u003c")
  .replaceAll("\u2028", "\\u2028")
  .replaceAll("\u2029", "\\u2029");
const updatedPack = pack.replace(marker, () => "const embeddedQuizDocument=" + literal + ";");
if (updatedPack !== pack) await writeFile(packPath, updatedPack);

await writeFile(new URL("../app/arcade-home.ts", import.meta.url),
  "export const arcadeHome = " + JSON.stringify(home) + ";\n");
