import {env} from 'cloudflare:workers';

export const dynamic = 'force-dynamic';
const reply = (body: unknown, status=200) => Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
const uuid = /^[a-f0-9-]{36}$/i;
type Call = {host:string,guest:string|null,offer:string,answer:string|null,host_seen:number,guest_seen:number};

export async function POST(req:Request){
  if(req.headers.get('sec-fetch-site')==='cross-site') return reply({error:'Open Nightshift to call.'},403);
  if(!req.headers.get('content-type')?.startsWith('application/json')) return reply({error:'Expected JSON.'},415);
  const raw=await req.text();
  if(raw.length>65536) return reply({error:'Call information too large.'},413);
  let data;
  try {data=JSON.parse(raw);} catch {return reply({error:'Invalid request.'},400);}
  const {action,code,token,sdp}=data||{};
  if(typeof code!=='string'||!/^[A-F0-9]{12}$/.test(code)||typeof token!=='string'||!uuid.test(token)) return reply({error:'Check the call code.'},400);
  const now=Date.now(),expiry=now-90000;
  const db=env.DB;
  if(action==='create'){
    if(typeof sdp!=='string'||!sdp.startsWith('v=0')||!sdp.includes('m=audio')) return reply({error:'Missing audio offer.'},400);
    await db.prepare('DELETE FROM voice_calls WHERE host_seen<? OR (guest IS NOT NULL AND guest_seen<?)').bind(expiry,expiry).run();
    const r=await db.prepare('INSERT OR IGNORE INTO voice_calls(code,host,offer,host_seen) VALUES(?,?,?,?)').bind(code,token,sdp,now).run();
    if(r.meta.changes) return reply({ready:true});
  }
  if(action==='join'){
    await db.prepare('UPDATE voice_calls SET guest=?,guest_seen=? WHERE code=? AND host_seen>=? AND guest IS NULL AND host<>?').bind(token,now,code,expiry,token).run();
  }
  const call=await db.prepare('SELECT * FROM voice_calls WHERE code=?').bind(code).first<Call>();
  if(!call||call.host_seen<expiry||(call.guest&&call.guest_seen<expiry)) return reply({error:'This call ended or the code expired.'},410);
  const host=call.host===token;
  if(!host&&call.guest!==token) return reply({error:'This call is already occupied.'},409);
  if(action==='end'){await db.prepare('DELETE FROM voice_calls WHERE code=? AND (host=? OR guest=?)').bind(code,token,token).run();return reply({ended:true});}
  if(action==='create'&&host) return reply({ready:true});
  if(action==='join'&&!host) return reply({offer:call.offer});
  if(action==='answer'&&!host&&typeof sdp==='string'&&sdp.startsWith('v=0')&&sdp.includes('m=audio')){
    await db.prepare('UPDATE voice_calls SET answer=?,guest_seen=? WHERE code=? AND guest=?').bind(sdp,now,code,token).run();return reply({ready:true});
  }
  if(action==='poll'){
    await db.prepare(host?'UPDATE voice_calls SET host_seen=? WHERE code=? AND host=?':'UPDATE voice_calls SET guest_seen=? WHERE code=? AND guest=?').bind(now,code,token).run();
    return reply({joined:!!call.guest,answer:host?call.answer:null});
  }
  return reply({error:'Unknown call action.'},400);
}
