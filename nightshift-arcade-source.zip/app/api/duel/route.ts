import { env } from 'cloudflare:workers';

export const dynamic = 'force-dynamic';

type Envelope = { n: number; data: { t: string; [key: string]: unknown } };
type Room = { host: string; guest: string | null; open: number; host_seen: number; guest_seen: number; inbox: string; ack: number; packet: string };
const respond = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
const failure = (error: string, status: number) => respond({ error }, status);
const ttl = 90_000;
const bodyLimit = 96_000;
const keyFormat = /^[a-f0-9]{32}$/;
async function digest(value: string){
  const bytes=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)));
  return Array.from(bytes,c=>c.toString(16).padStart(2,'0')).join('');
}
function envelopes(value: unknown): value is Envelope[] {
  return Array.isArray(value) && value.length<=24 && value.every(item=>item&&Number.isSafeInteger(item.n)&&item.n>0&&item.n<1e8&&
    item.data&&['hello','intent'].includes(item.data.t)) && JSON.stringify(value).length<=12500;
}
export async function POST(request: Request){
  if(request.headers.get('sec-fetch-site')==='cross-site')return failure('Open this Nightshift site to use its room codes.',403);
  if(!request.headers.get('content-type')?.startsWith('application/json'))return failure('Expected a JSON request.',415);
  if(Number(request.headers.get('content-length')||0)>bodyLimit)return failure('Room update is too large.',413);
  let msg;
  try {
    const raw=await request.text();
    if(raw.length>bodyLimit)return failure('Room update is too large.',413);
    msg=JSON.parse(raw);
  }catch{return failure('Invalid room request.',400);}
  const db=env.DB;
  if(!db)return failure('Room service is unavailable.',503);
  if(!msg||typeof msg.code!=='string'||!/^\d{7}$/.test(msg.code)||typeof msg.key!=='string'||!keyFormat.test(msg.key))return failure('Invalid room address.',400);
  const code=msg.code,key=await digest(msg.key),now=Date.now();
  const read=db.prepare('SELECT host,guest,open,host_seen,guest_seen,inbox,ack,packet FROM duel_rooms WHERE code=?').bind(code);
  if(msg.op==='create'){
    const result=await db.batch([
      db.prepare('DELETE FROM duel_rooms WHERE host_seen < ?').bind(now-ttl),
      db.prepare('INSERT OR IGNORE INTO duel_rooms(code,host,host_seen) VALUES (?,?,?)').bind(code,key,now),read,
    ]);
    const room=result[2].results[0] as unknown as Room|undefined;
    return room?.host===key?respond({ok:true}):failure('Room code in use.',409);
  }
  if(msg.op==='join'){
    const result=await db.batch([
      db.prepare("UPDATE duel_rooms SET guest=?, guest_seen=?, inbox='[]', ack=0, packet='' WHERE code=? AND host_seen>=? AND open=1 AND (guest IS NULL OR guest_seen<?)").bind(key,now,code,now-ttl,now-ttl),
      read,
    ]);
    const room=result[1].results[0] as unknown as Room|undefined;
    if(!room||room.host_seen<now-ttl)return failure('No live Nightshift room found for that code.',404);
    if(room.guest!==key)return failure('Both duel seats are taken or the match has started.',409);
    return respond({ok:true});
  }
  if(msg.op==='host'){
    const tag=typeof msg.peer==='string'?msg.peer:'';
    if(tag&&!/^[a-f0-9]{64}$/.test(tag))return failure('Invalid player.',400);
    if(!Number.isSafeInteger(msg.ack)||msg.ack<0||msg.ack>=1e8||typeof msg.open!=='boolean')return failure('Invalid host update.',400);
    const packet=msg.packet==null?'':JSON.stringify(msg.packet);
    if(packet.length>76_000)return failure('Snapshot is too large.',413);
    const result=await db.batch([
      db.prepare("UPDATE duel_rooms SET guest=NULL,inbox='[]',ack=0,packet='' WHERE code=? AND host=? AND guest_seen<? AND guest IS NOT NULL").bind(code,key,now-ttl),
      db.prepare("UPDATE duel_rooms SET host_seen=?,open=?,ack=CASE WHEN guest=? THEN MAX(ack,?) ELSE ack END,packet=CASE WHEN guest=? AND ?!='' THEN ? ELSE packet END WHERE code=? AND host=? AND host_seen>=?").bind(now,Number(msg.open),tag,msg.ack,tag,packet,packet,code,key,now-ttl),
      read,
    ]);
    const room=result[2].results[0] as unknown as Room|undefined;
    if(!room||room.host!==key||room.host_seen<now-ttl)return failure('The room has closed.',410);
    return respond({peer:room.guest,items:JSON.parse(room.inbox)});
  }
  if(msg.op==='guest'){
    if(!envelopes(msg.items))return failure('Invalid player actions.',400);
    const result=await db.batch([
      db.prepare('UPDATE duel_rooms SET guest_seen=?,inbox=? WHERE code=? AND guest=? AND host_seen>=?').bind(now,JSON.stringify(msg.items),code,key,now-ttl),read,
    ]);
    const room=result[1].results[0] as unknown as Room|undefined;
    if(!room||room.guest!==key||room.host_seen<now-ttl)return failure('The host closed this room.',410);
    return respond({ack:room.ack,packet:room.packet?JSON.parse(room.packet):null});
  }
  if(msg.op==='close'){
    await db.prepare('DELETE FROM duel_rooms WHERE code=? AND host=?').bind(code,key).run();return respond({ok:true});
  }
  if(msg.op==='leave'){
    await db.prepare("UPDATE duel_rooms SET guest=NULL,guest_seen=0,inbox='[]',ack=0,packet='' WHERE code=? AND guest=?").bind(code,key).run();return respond({ok:true});
  }
  return failure('Unknown room request.',400);
}
