import { env } from 'cloudflare:workers';

export const dynamic = 'force-dynamic';
const channels = new Set(['general', 'looking-for-group', 'game-talk']);
const json = (body: unknown, status = 200) => Response.json(body, {status, headers: {'Cache-Control': 'no-store'}});

export async function GET(request: Request) {
  const channel = new URL(request.url).searchParams.get('channel') || '';
  if (!channels.has(channel)) return json({error: 'Unknown channel.'}, 400);
  const {results} = await env.DB.prepare(
    'SELECT id,nickname,message,created FROM comms_messages WHERE channel=? ORDER BY id DESC LIMIT 100'
  ).bind(channel).all();
  return json({messages: results.reverse()});
}

export async function POST(request: Request) {
  if (request.headers.get('sec-fetch-site') === 'cross-site') return json({error: 'Open Nightshift to send messages.'}, 403);
  if (!request.headers.get('content-type')?.startsWith('application/json')) return json({error: 'Expected JSON.'}, 415);
  if (Number(request.headers.get('content-length')) > 8192) return json({error: 'Message too long.'}, 413);
  let data;
  try {
    const raw = await request.text();
    if (raw.length > 8192) return json({error: 'Message too long.'}, 413);
    data = JSON.parse(raw);
  } catch { return json({error: 'Invalid message.'}, 400); }
  const {channel, nickname, message, requestId} = data ?? {};
  if (!channels.has(channel) || typeof nickname !== 'string' || !nickname.trim() || nickname.length > 24 ||
      typeof message !== 'string' || !message.trim() || message.length > 1000 ||
      typeof requestId !== 'string' || !/^[a-f\d-]{36}$/.test(requestId)) return json({error: 'Check your nickname and message.'}, 400);
  await env.DB.prepare(
    'INSERT INTO comms_messages(request_id,channel,nickname,message,created) VALUES(?,?,?,?,?) ON CONFLICT(request_id) DO NOTHING'
  ).bind(requestId,channel,nickname.trim(),message.trim(),Date.now()).run();
  return json({sent:true});
}
