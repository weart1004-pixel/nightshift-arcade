import {env} from 'cloudflare:workers';

export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(req:Request){
  if(req.headers.get('sec-fetch-site')==='cross-site')return json({error:'Open Nightshift to manage friends.'},403);
  if(!req.headers.get('content-type')?.startsWith('application/json'))return json({error:'Expected JSON.'},415);
  const token=req.headers.get('authorization')?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
  if(!token)return json({error:'Missing friend profile.'},401);
  const raw=await req.text();if(raw.length>1024)return json({error:'Request too large.'},413);
  let body;
  try{body=JSON.parse(raw);}catch{return json({error:'Invalid request.'},400);}
  const {action,target}=body||{};
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token));
  const credential=Array.from(new Uint8Array(digest),n=>n.toString(16).padStart(2,'0')).join('');
  const db=env.DB;
  if(action==='profile'){
    const nickname=typeof body.nickname==='string'?body.nickname.trim():'';
    if(!nickname||nickname.length>24)return json({error:'Enter a nickname of up to 24 characters.'},400);
    const code=crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase();
    await db.prepare('INSERT INTO friend_profiles(code,credential,nickname) VALUES(?,?,?) ON CONFLICT(credential) DO UPDATE SET nickname=excluded.nickname').bind(code,credential,nickname).run();
  }
  const me=await db.prepare('SELECT code,nickname FROM friend_profiles WHERE credential=?').bind(credential).first<{code:string,nickname:string}>();
  if(!me)return json({needsProfile:true});
  if(!['profile','list'].includes(action)){
    if(typeof target!=='string'||!(/^[A-F0-9]{12}$/).test(target))return json({error:'Enter a valid 12-character friend code.'},400);
    if(target===me.code)return json({error:'That’s your own friend code.'},400);
    const pair=[me.code,target].sort().join('-');
    if(action==='send'){
      const res=await db.prepare('INSERT OR IGNORE INTO friend_links(pair,sender,recipient) SELECT ?,?,code FROM friend_profiles WHERE code=?').bind(pair,me.code,target).run();
      if(!res.meta.changes){
        const link=await db.prepare('SELECT sender,accepted FROM friend_links WHERE pair=?').bind(pair).first<{sender:string,accepted:number}>();
        if(!link)return json({error:'No player found with that code.'},404);
        if(link.accepted)return json({error:'Already on your friends list.'},409);
        if(link.sender!==me.code)return json({error:'This player already sent you a request. Choose Accept below.'},409);
      }
    }else{
      const statements:Record<string,string>={
        accept:'UPDATE friend_links SET accepted=1 WHERE pair=? AND recipient=? AND accepted=0',
        decline:'DELETE FROM friend_links WHERE pair=? AND recipient=? AND accepted=0',
        cancel:'DELETE FROM friend_links WHERE pair=? AND sender=? AND accepted=0',
        remove:'DELETE FROM friend_links WHERE pair=? AND (sender=? OR recipient=?) AND accepted=1'
      };
      if(!Object.hasOwn(statements,action))return json({error:'Unknown action.'},400);
      await db.prepare(statements[action]).bind(pair,me.code,...(action==='remove'?[me.code]:[])).run();
    }
  }
  const {results}=await db.prepare(`SELECT p.code,p.nickname,l.accepted,l.sender FROM friend_links l JOIN friend_profiles p
    ON p.code=CASE WHEN l.sender=? THEN l.recipient ELSE l.sender END WHERE l.sender=? OR l.recipient=? ORDER BY p.nickname COLLATE NOCASE,p.code`).bind(me.code,me.code,me.code).all();
  return json({me,links:results});
}
