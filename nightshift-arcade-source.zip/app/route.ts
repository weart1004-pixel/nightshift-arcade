import { arcadeHome } from "./arcade-home";

export function GET() {
  return new Response(arcadeHome, {
    headers: { "Content-Type": "text/html; charset=utf-8" },
  });
}
