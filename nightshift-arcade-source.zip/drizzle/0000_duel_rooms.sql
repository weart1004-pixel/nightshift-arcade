CREATE TABLE `duel_rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`guest` text,
	`open` integer DEFAULT 1 NOT NULL,
	`host_seen` integer NOT NULL,
	`guest_seen` integer DEFAULT 0 NOT NULL,
	`inbox` text DEFAULT '[]' NOT NULL,
	`ack` integer DEFAULT 0 NOT NULL,
	`packet` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `duel_last_host` ON `duel_rooms` (`host_seen`);