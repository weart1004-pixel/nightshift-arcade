CREATE TABLE `comms_messages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`request_id` text NOT NULL,
	`channel` text NOT NULL,
	`nickname` text NOT NULL,
	`message` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `comms_messages_request_id_unique` ON `comms_messages` (`request_id`);--> statement-breakpoint
CREATE INDEX `comms_channel_id` ON `comms_messages` (`channel`,`id`);