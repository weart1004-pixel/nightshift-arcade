CREATE TABLE `voice_calls` (
	`code` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`guest` text,
	`offer` text NOT NULL,
	`answer` text,
	`host_seen` integer NOT NULL,
	`guest_seen` integer DEFAULT 0 NOT NULL
);
