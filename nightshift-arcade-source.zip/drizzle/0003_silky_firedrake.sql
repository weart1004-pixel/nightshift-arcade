CREATE TABLE `friend_links` (
	`pair` text PRIMARY KEY NOT NULL,
	`sender` text NOT NULL,
	`recipient` text NOT NULL,
	`accepted` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `friend_sender` ON `friend_links` (`sender`);--> statement-breakpoint
CREATE INDEX `friend_recipient` ON `friend_links` (`recipient`);--> statement-breakpoint
CREATE TABLE `friend_profiles` (
	`code` text PRIMARY KEY NOT NULL,
	`credential` text NOT NULL,
	`nickname` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `friend_profiles_credential_unique` ON `friend_profiles` (`credential`);